# Nurse cast pack

The only way to draw the nurse-animation cast. Never redraw these characters by hand or from a description:
render them with this pack so every video matches the approved designs.

Characters: `nurse` (lead), `doctor`, `head_nurse`, `friend`, `patient`, `gent` (blonde man in a luxury navy suit; lead of the finance videos).

## Requirements
Python 3 with Pillow, and `rsvg-convert` (`apt install librsvg2-bin`) or `pip install cairosvg`.

## Use
```
cd cast
python3 sprite.py list                                   # characters, views, poses, expressions
python3 sprite.py one  --char nurse --view q --turn -1 --pose wave --expr happy --card --out nurse.png
python3 sprite.py anim --char nurse --pose wave --frames 90 --card --outdir frames/nurse
python3 sprite.py batch spec.json --outdir sprites      # list of {"name":..., "char":..., "view":..., ...}
```
Options: `view` front | q (three-quarter) | side | back; `turn` 1 (turned toward screen-right) or -1;
`pose` down, wave, point, pointUp, hip, handsUp, think, cheer, shrug; `expr` smile, happy, surprise,
worry, smirk, think, stern, nervous, sad, sleepy; `look` -13 (eyes left) .. 13 (eyes right); `blink` 1 open .. 0 closed;
`t` time in seconds (drives the wave, gentle sway and hair motion).

`--card` gives a 600x1000 transparent PNG with the soles centred at (300, 975) at 2.25 m = 1000 px, the same
canvas and scale as the animation kit's character cards, so it can be drawn 1:1 with `ctx.drawImage`.
Without `--card` you get 1080x1920 at one shared scale.

## Choosing the view (from the kit's blocking rules)
Angle between where the actor faces and the direction to the camera: under 35 degrees `front`;
35-80 `q`; 80-120 `side`; over 120 `back`. Use `turn` 1 when the actor faces screen-right, -1 for screen-left.

## Rules
- No lip-sync: the videos are narrated, so mouths hold one expression and change only with emotion.
- Do not edit the designs. If a pose or expression is missing, add it to `chars.py` (POSES / EXPR)
  using the existing parts, render a test sheet with `sheet.py`, and show it to the user first.
- Reference sheets in `reference/` show the approved look for every view, pose and expression.
