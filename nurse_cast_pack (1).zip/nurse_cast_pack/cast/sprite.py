#!/usr/bin/env python3
"""Export cast sprites from the character pack.

Every character is drawn ONLY by this pack (chars.render). Never redraw a character by hand.

Examples
  python3 sprite.py one  --char nurse --view q --turn -1 --pose wave --expr happy --out nurse.png
  python3 sprite.py one  --char doctor --view side --card --out doctor_card.png
  python3 sprite.py anim --char nurse --pose wave --expr smile --frames 90 --outdir frames/nurse --card
  python3 sprite.py batch spec.json --outdir sprites          (spec: list of objects with the same keys + "name")
  python3 sprite.py list

Output
  full  : 1080x1920 RGBA, transparent, same scale for every character and view.
  --card: 600x1000 RGBA, soles centred at (300, 975), real-world scale 2.25 m = 1000 px,
          which matches the animation kit's card canvas, so it can be drawn 1:1 with drawImage.
"""
import argparse, io, json, math, os, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chars  # noqa: E402

CARD_W, CARD_H, CARD_SOLE_Y = 600, 1000, 975
PX_PER_M_FULL = 943.0           # sprite pixels per metre (nurse 1.62 m incl. cap = 1527 px)
CARD_PX_PER_M = 1000 / 2.25
CARD_SCALE = CARD_PX_PER_M / PX_PER_M_FULL

VIEWS = ['front', 'q', 'side', 'back']
NAMES = list(chars.CHARS.keys())


def _rasterize(svg):
    from PIL import Image
    if shutil.which('rsvg-convert'):
        png = subprocess.run(['rsvg-convert'], input=svg.encode(), stdout=subprocess.PIPE, check=True).stdout
        return Image.open(io.BytesIO(png)).convert('RGBA')
    try:
        import cairosvg
        return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert('RGBA')
    except ImportError:
        sys.exit("Need rsvg-convert (apt install librsvg2-bin) or cairosvg (pip install cairosvg) to render sprites.")


def render(char='nurse', view='front', turn=1, pose=None, expr=None, look=0.0, blink=1.0, t=0.0, card=False, bg=None):
    if char not in chars.CHARS:
        raise SystemExit(f"unknown character {char}; choose from {NAMES}")
    img = _rasterize(chars.render(char, view=view, turn=turn, pose=pose, expr=expr, look=look, blink=blink, t=t, bg=bg))
    if not card:
        return img
    from PIL import Image
    a = img.split()[3].point(lambda p: 255 if p > 40 else 0)
    bbox = a.getbbox()
    sole = bbox[3] if bbox else 1750
    w, h = round(img.width * CARD_SCALE), round(img.height * CARD_SCALE)
    small = img.resize((w, h), Image.LANCZOS)
    out = Image.new('RGBA', (CARD_W, CARD_H), (0, 0, 0, 0))
    out.alpha_composite(small, (round(CARD_W / 2 - 540 * CARD_SCALE), round(CARD_SOLE_Y - sole * CARD_SCALE)))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)

    def common(p):
        p.add_argument('--char', default='nurse', choices=NAMES)
        p.add_argument('--view', default='front', choices=VIEWS)
        p.add_argument('--turn', type=int, default=1, choices=[1, -1])
        p.add_argument('--pose', default=None, choices=list(chars.POSES))
        p.add_argument('--expr', default=None, choices=list(chars.EXPR))
        p.add_argument('--look', type=float, default=0.0, help='-13 (left) .. 13 (right)')
        p.add_argument('--card', action='store_true')
    p1 = sub.add_parser('one'); common(p1)
    p1.add_argument('--blink', type=float, default=1.0); p1.add_argument('--t', type=float, default=0.0)
    p1.add_argument('--out', required=True)
    p2 = sub.add_parser('anim'); common(p2)
    p2.add_argument('--frames', type=int, default=90); p2.add_argument('--start', type=float, default=0.0)
    p2.add_argument('--fps', type=int, default=30); p2.add_argument('--blink-at', default='1.2,3.6')
    p2.add_argument('--outdir', required=True)
    p3 = sub.add_parser('batch'); p3.add_argument('spec'); p3.add_argument('--outdir', required=True)
    sub.add_parser('list')
    a = ap.parse_args()

    if a.cmd == 'list':
        print(json.dumps({'characters': NAMES, 'views': VIEWS, 'turn': [1, -1], 'poses': list(chars.POSES),
                          'expressions': list(chars.EXPR), 'default_expr': chars.DEFAULT_EXPR}, indent=1))
        return
    if a.cmd == 'one':
        render(a.char, a.view, a.turn, a.pose, a.expr, a.look, a.blink, a.t, a.card).save(a.out)
        return
    if a.cmd == 'anim':
        os.makedirs(a.outdir, exist_ok=True)
        blinks = [float(x) for x in a.blink_at.split(',') if x]
        for i in range(a.frames):
            t = a.start + i / a.fps
            bl = 1.0
            for b in blinks:
                if abs(t - b) < 0.1:
                    bl = min(bl, abs(t - b) / 0.1)
            render(a.char, a.view, a.turn, a.pose, a.expr, a.look, bl, t, a.card).save(os.path.join(a.outdir, f'f{i:04d}.png'))
        return
    if a.cmd == 'batch':
        os.makedirs(a.outdir, exist_ok=True)
        for item in json.load(open(a.spec)):
            item = dict(item); name = item.pop('name')
            item['char'] = item.pop('char', 'nurse')
            render(**item).save(os.path.join(a.outdir, f'{name}.png'))


if __name__ == '__main__':
    main()
