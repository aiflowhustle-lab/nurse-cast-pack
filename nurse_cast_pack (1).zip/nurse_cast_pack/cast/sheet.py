import sys, subprocess, chars
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageDraw, ImageFont

def png(name, out, **kw):
    svg = chars.render(name, **kw)
    subprocess.run(["rsvg-convert", "-o", out], input=svg.encode(), check=True)

def sheet(cells, cols, out, cw=300, ch=560, crop=(140, 40, 940, 1900)):
    rows = (len(cells) + cols - 1) // cols
    W = Image.new('RGB', (cols * cw, rows * (ch + 26)), '#f6f4f8')
    d = ImageDraw.Draw(W)
    try: font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    except Exception: font = None
    jobs = []
    for i, (label, name, kw) in enumerate(cells):
        jobs.append((i, label, name, kw, f'/tmp/cell_{i}.png'))
    with ThreadPoolExecutor(8) as ex:
        list(ex.map(lambda j: png(j[2], j[4], bg=None, **j[3]), jobs))
    for i, label, name, kw, p in jobs:
        im = Image.open(p).crop(crop)
        im.thumbnail((cw, ch))
        x, y = (i % cols) * cw, (i // cols) * (ch + 26)
        W.paste(im, (x + (cw - im.width) // 2, y + 24), im)
        d.text((x + 6, y + 4), label, fill='#444', font=font)
    W.save(out, quality=92)

if __name__ == '__main__':
    pass
