import math, sys

W = H = 1080

SKIN = "#fff0e6"; SKIN_SH = "#f7cdbd"; SKIN_SH2 = "#eeb3a2"; SKIN_LINE = "#c98774"
HAIR_L = "#fbe3a4"; HAIR = "#f1c472"; HAIR_D = "#d9984a"; HAIR_LINE = "#a8692e"; HAIR_HL = "#fff6d6"
BLOUSE = "#ffffff"; BLOUSE_SH = "#dfe2f0"; CLOTH_LINE = "#6b6378"
NAVY = "#2f3d70"; NAVY_D = "#1f2850"; NAVY_L = "#45558f"
TIE = "#ec5866"; TIE_D = "#c23a4a"; TIE_L = "#ff8a92"
MINT = "#8ddcc9"; MINT_D = "#55b49f"; MINT_L = "#c4f1e6"
LASH = "#2b1822"


def ease(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)


def back_out(x):
    x = max(0.0, min(1.0, x)); c1 = 1.9; c3 = c1 + 1
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


def pt(p, ang, l):
    a = math.radians(ang); return (p[0] + l * math.cos(a), p[1] + l * math.sin(a))


def f(v):
    return f"{v:.1f}"


DEFS = f'''<defs>
<filter id="b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
<filter id="b8" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8"/></filter>
<filter id="b14" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14"/></filter>
<linearGradient id="hairG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="{HAIR_L}"/><stop offset="0.35" stop-color="{HAIR}"/><stop offset="1" stop-color="#e8ae5c"/></linearGradient>
<linearGradient id="hairBackG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#e2a95a"/><stop offset="0.6" stop-color="{HAIR}"/><stop offset="1" stop-color="{HAIR_L}"/></linearGradient>
<radialGradient id="irisG" cx="0.5" cy="0.72" r="0.75">
 <stop offset="0" stop-color="#ffe08a"/><stop offset="0.35" stop-color="#f3a640"/>
 <stop offset="0.75" stop-color="#c8621c"/><stop offset="1" stop-color="#7a2f10"/></radialGradient>
<linearGradient id="irisTop" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#3a1206" stop-opacity="0.95"/><stop offset="0.5" stop-color="#3a1206" stop-opacity="0.15"/>
 <stop offset="0.6" stop-color="#3a1206" stop-opacity="0"/></linearGradient>
<linearGradient id="scleraG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#d9cfe0"/><stop offset="0.35" stop-color="#ffffff"/></linearGradient>
<linearGradient id="blouseG" x1="0" y1="0" x2="1" y2="0">
 <stop offset="0" stop-color="#ffffff"/><stop offset="0.7" stop-color="#f7f8fc"/><stop offset="1" stop-color="#e6e9f4"/></linearGradient>
<linearGradient id="navyG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="{NAVY_L}"/><stop offset="1" stop-color="{NAVY}"/></linearGradient>
<linearGradient id="tieG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="{TIE_L}"/><stop offset="0.5" stop-color="{TIE}"/><stop offset="1" stop-color="{TIE_D}"/></linearGradient>
<linearGradient id="mintG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="{MINT_L}"/><stop offset="1" stop-color="{MINT}"/></linearGradient>
<linearGradient id="skinG" x1="0" y1="0" x2="1" y2="0">
 <stop offset="0" stop-color="{SKIN}"/><stop offset="0.75" stop-color="{SKIN}"/><stop offset="1" stop-color="#fbdccd"/></linearGradient>
</defs>'''


# ---------------------------------------------------------------- hair pieces
def lock(x0, y0, x1, y1, w, bend):
    """tapered hair lock from root (x0,y0) to tip (x1,y1), root width w."""
    dx, dy = x1 - x0, y1 - y0
    L = math.hypot(dx, dy); nx, ny = -dy / L, dx / L
    mx, my = x0 + dx * 0.5 + nx * bend, y0 + dy * 0.5 + ny * bend
    a = (x0 + nx * w / 2, y0 + ny * w / 2); b = (x0 - nx * w / 2, y0 - ny * w / 2)
    return (f"M {f(a[0])} {f(a[1])} Q {f(mx + nx * w * 0.35)} {f(my + ny * w * 0.35)} {f(x1)} {f(y1)} "
            f"Q {f(mx - nx * w * 0.35)} {f(my - ny * w * 0.35)} {f(b[0])} {f(b[1])} Z")


def strands(lines, col=HAIR_D, w=2.0, op=0.55):
    o = []
    for (x0, y0, cx, cy, x1, y1) in lines:
        o.append(f'<path d="M {x0} {y0} Q {cx} {cy} {x1} {y1}" fill="none" stroke="{col}" stroke-width="{w}" '
                 f'stroke-linecap="round" opacity="{op}"/>')
    return "".join(o)


# ---------------------------------------------------------------- eyes
def eye(cx, cy, s, op, look, uid):
    """s=+1 outer corner to the right (viewer-right eye), -1 mirrored."""
    X = lambda dx: f(cx + s * dx)
    Y = lambda dy: f(cy + dy)
    if op < 0.18:
        return (f'<path d="M {X(-36)} {Y(2)} Q {X(0)} {Y(20)} {X(40)} {Y(-2)}" fill="none" stroke="{LASH}" '
                f'stroke-width="6" stroke-linecap="round"/>'
                f'<path d="M {X(38)} {Y(-1)} L {X(50)} {Y(-8)}" stroke="{LASH}" stroke-width="4" stroke-linecap="round"/>')
    shape = (f"M {X(-38)} {Y(-6)} C {X(-26)} {Y(-34)} {X(22)} {Y(-40)} {X(42)} {Y(-18)} "
             f"C {X(42)} {Y(8)} {X(26)} {Y(32)} {X(2)} {Y(34)} C {X(-20)} {Y(32)} {X(-36)} {Y(14)} {X(-38)} {Y(-6)} Z")
    ix, iy = cx + look, cy + 6
    g = [f'<g transform="translate(0,{f(cy - 10)}) scale(1,{op:.3f}) translate(0,{f(-(cy - 10))})">']
    g.append(f'<clipPath id="ec{uid}"><path d="{shape}"/></clipPath>')
    g.append(f'<path d="{shape}" fill="url(#scleraG)"/>')
    g.append(f'<g clip-path="url(#ec{uid})">')
    g.append(f'<ellipse cx="{f(ix)}" cy="{f(iy)}" rx="27" ry="33" fill="url(#irisG)"/>')
    g.append(f'<ellipse cx="{f(ix)}" cy="{f(iy)}" rx="27" ry="33" fill="url(#irisTop)"/>')
    g.append(f'<ellipse cx="{f(ix)}" cy="{f(iy - 1)}" rx="11" ry="16" fill="#2a0c04"/>')
    g.append(f'<ellipse cx="{f(ix)}" cy="{f(iy)}" rx="27" ry="33" fill="none" stroke="#5a2008" stroke-width="2.5"/>')
    # radial iris lines
    for k in range(-3, 4):
        a = math.radians(90 + k * 18)
        g.append(f'<line x1="{f(ix + 13 * math.cos(a))}" y1="{f(iy + 18 * math.sin(a))}" '
                 f'x2="{f(ix + 23 * math.cos(a))}" y2="{f(iy + 29 * math.sin(a))}" stroke="#ffe7a8" '
                 f'stroke-width="1.6" opacity="0.6"/>')
    # lid shadow band
    g.append(f'<path d="M {X(-40)} {Y(-40)} L {X(46)} {Y(-40)} L {X(46)} {Y(-12)} C {X(20)} {Y(-26)} {X(-20)} {Y(-22)} '
             f'{X(-40)} {Y(0)} Z" fill="#5a3a60" opacity="0.18"/>')
    # catch lights
    g.append(f'<ellipse cx="{f(ix - 9 * s)}" cy="{f(iy - 12)}" rx="8.5" ry="10.5" fill="#ffffff"/>')
    g.append(f'<circle cx="{f(ix + 10 * s)}" cy="{f(iy + 14)}" r="3.6" fill="#ffffff"/>')
    g.append(f'<circle cx="{f(ix + 13 * s)}" cy="{f(iy - 14)}" r="2.2" fill="#ffffff" opacity="0.9"/>')
    g.append('</g>')
    # upper lid (thick lash line with outer flick)
    g.append(f'<path d="M {X(-40)} {Y(-2)} C {X(-30)} {Y(-38)} {X(22)} {Y(-46)} {X(46)} {Y(-22)} L {X(56)} {Y(-24)} '
             f'L {X(47)} {Y(-14)} C {X(24)} {Y(-34)} {X(-22)} {Y(-30)} {X(-36)} {Y(-2)} Z" fill="{LASH}"/>')
    g.append(f'<path d="M {X(38)} {Y(-28)} L {X(54)} {Y(-38)} L {X(44)} {Y(-24)} Z" fill="{LASH}"/>')
    g.append(f'<path d="M {X(44)} {Y(-18)} L {X(58)} {Y(-16)} L {X(46)} {Y(-12)} Z" fill="{LASH}"/>')
    g.append(f'<path d="M {X(-36)} {Y(-4)} L {X(-42)} {Y(4)}" stroke="{LASH}" stroke-width="2.5" stroke-linecap="round"/>')
    # lower lash
    g.append(f'<path d="M {X(-22)} {Y(30)} Q {X(4)} {Y(40)} {X(30)} {Y(24)}" fill="none" stroke="#9a5a5c" '
             f'stroke-width="2.2" stroke-linecap="round"/>')
    g.append(f'<path d="M {X(30)} {Y(24)} L {X(38)} {Y(12)}" stroke="#7a3e48" stroke-width="2.6" stroke-linecap="round"/>')
    g.append('</g>')
    # crease (outside scaling so it stays during blink start)
    g.append(f'<path d="M {X(-26)} {Y(-38)} Q {X(10)} {Y(-54)} {X(40)} {Y(-38)}" fill="none" stroke="{SKIN_LINE}" '
             f'stroke-width="2" stroke-linecap="round" opacity="{0.8 * op:.2f}"/>')
    return "".join(g)


def happy_eye(cx, cy, s):
    X = lambda dx: f(cx + s * dx)
    return (f'<path d="M {X(-34)} {f(cy + 10)} Q {X(2)} {f(cy - 26)} {X(38)} {f(cy + 8)}" fill="none" stroke="{LASH}" '
            f'stroke-width="7" stroke-linecap="round"/>'
            f'<path d="M {X(36)} {f(cy + 6)} L {X(48)} {f(cy + 12)}" stroke="{LASH}" stroke-width="4" stroke-linecap="round"/>')


# ---------------------------------------------------------------- limbs
def quad(p0, p1, w0, w1):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]; L = math.hypot(dx, dy) or 1
    nx, ny = -dy / L, dx / L
    pts = [(p0[0] + nx * w0, p0[1] + ny * w0), (p1[0] + nx * w1, p1[1] + ny * w1),
           (p1[0] - nx * w1, p1[1] - ny * w1), (p0[0] - nx * w0, p0[1] - ny * w0)]
    return "M " + " L ".join(f"{f(x)} {f(y)}" for x, y in pts) + " Z"


def limb_layers(parts, fill, line, lw=5):
    """parts: list of ('q', d) or ('c', x, y, r). outline pass then fill pass -> merged silhouette."""
    o = []
    for pass_ in (0, 1):
        for p in parts:
            if p[0] == 'q':
                if pass_ == 0:
                    o.append(f'<path d="{p[1]}" fill="{line}" stroke="{line}" stroke-width="{lw}" stroke-linejoin="round"/>')
                else:
                    o.append(f'<path d="{p[1]}" fill="{fill}"/>')
            else:
                r = p[3] + (lw / 2 if pass_ == 0 else 0)
                o.append(f'<circle cx="{f(p[1])}" cy="{f(p[2])}" r="{f(r)}" fill="{line if pass_ == 0 else fill}"/>')
    return "".join(o)


def finger(L, w):
    h = w / 2
    return (f"M {-h} 2 C {-h} {-L * 0.4} {-h * 0.92} {-L * 0.7} {-h * 0.85} {-L + h} "
            f"Q {-h * 0.8} {-L} 0 {-L} Q {h * 0.8} {-L} {h * 0.85} {-L + h} "
            f"C {h * 0.92} {-L * 0.7} {h} {-L * 0.4} {h} 2 Z")


def hand(x, y, ang, spread, sc=1.15):
    rot = ang + 90
    fingers = [  # base x, base y, length, width, angle
        (-25, -56, 44, 14, -13 - spread),
        (-9, -62, 56, 15.5, -4 - spread * 0.35),
        (7, -63, 60, 16, 3 + spread * 0.35),
        (22, -58, 54, 15.5, 10 + spread),
    ]
    thumb = (30, -16, 48, 18, 48 + spread * 0.8)
    palm = "M -31 2 C -35 -18 -36 -42 -33 -60 Q 0 -70 32 -62 C 36 -44 36 -20 29 2 Q 0 8 -31 2 Z"
    parts = []
    for bx, by, L, w, a in fingers + [thumb]:
        parts.append(f'<path d="{finger(L, w)}" transform="translate({bx},{by}) rotate({a:.2f})"/>')
    parts.append(f'<path d="{palm}"/>')
    shapes = "".join(parts)
    o = [f'<g transform="translate({f(x)},{f(y)}) rotate({rot:.2f}) scale({sc})">']
    o.append(f'<g fill="{SKIN_LINE}" stroke="{SKIN_LINE}" stroke-width="4.5" stroke-linejoin="round">{shapes}</g>')
    o.append(f'<g fill="{SKIN}">{shapes}</g>')
    # finger separation lines
    for bx, by, L, w, a in fingers:
        o.append(f'<g transform="translate({bx},{by}) rotate({a:.2f})">'
                 f'<path d="M {-w * 0.3:.1f} {-L * 0.42:.1f} Q 0 {-L * 0.38:.1f} {w * 0.3:.1f} {-L * 0.42:.1f}" fill="none" '
                 f'stroke="{SKIN_SH2}" stroke-width="1.6" stroke-linecap="round"/>'
                 f'<path d="M {w / 2 - 0.5:.1f} 0 L {w / 2 - 1:.1f} {-L * 0.25:.1f}" stroke="{SKIN_LINE}" stroke-width="2" opacity="0.6"/></g>')
    # palm shading & creases
    o.append(f'<path d="M -31 2 C -35 -18 -36 -42 -33 -60 Q -24 -40 -22 -10 Q -26 0 -31 2 Z" fill="{SKIN_SH}" opacity="0.8"/>')
    o.append(f'<path d="M -22 -30 Q 0 -22 22 -36" fill="none" stroke="{SKIN_SH2}" stroke-width="2" stroke-linecap="round"/>'
             f'<path d="M 18 -8 Q 6 -22 14 -46" fill="none" stroke="{SKIN_SH2}" stroke-width="2" stroke-linecap="round"/>')
    o.append('</g>')
    return "".join(o)


def arm(S, a1, a2, sleeve_only=False):
    L1, L2 = 160, 150
    E = pt(S, a1, L1)
    Wr = pt(E, a2, L2 * 0.80)
    Hd = pt(E, a2, L2 * 0.98)
    CuffA = pt(E, a2, L2 * 0.62)
    parts = [('q', quad(S, E, 46, 38)), ('c', S[0], S[1], 46), ('c', E[0], E[1], 38), ('q', quad(E, CuffA, 38, 36))]
    o = [limb_layers(parts, "url(#blouseG)", CLOTH_LINE, 5)]
    # elbow folds
    o.append(f'<g transform="translate({f(E[0])},{f(E[1])}) rotate({a2:.1f})" fill="none" stroke="{BLOUSE_SH}" stroke-width="3" stroke-linecap="round">'
             f'<path d="M 4 -24 Q 18 -12 14 6"/><path d="M -14 -20 Q 0 -6 -4 14"/></g>')
    o.append(f'<path d="M {f(S[0])} {f(S[1])} L {f(E[0])} {f(E[1])}" stroke="{BLOUSE_SH}" stroke-width="22" '
             f'opacity="0.5" filter="url(#b8)" stroke-linecap="round"/>')
    # cuff
    cuff = [('q', quad(CuffA, Wr, 38, 36))]
    o.append(limb_layers(cuff, "url(#navyG)", NAVY_D, 4))
    m = pt(E, a2, L2 * 0.71)
    o.append(f'<g transform="translate({f(m[0])},{f(m[1])}) rotate({a2 + 90:.1f})">'
             f'<line x1="-36" y1="-4" x2="36" y2="-4" stroke="#fff" stroke-width="3"/>'
             f'<line x1="-36" y1="4" x2="36" y2="4" stroke="#fff" stroke-width="3"/></g>')
    # wrist
    wr = [('q', quad(pt(Wr, a2, -6), Hd, 17, 20))]
    wrist = limb_layers(wr, SKIN, SKIN_LINE, 4)
    return wrist, "".join(o), Hd, Wr


# ---------------------------------------------------------------- frame
def frame_svg(t, still=None):
    raise_k = ease((t - 0.15) / 0.65)
    wave_amp = 17 * ease((t - 0.6) / 0.4)
    wave = wave_amp * math.sin((t - 0.6) * 2 * math.pi * 1.6)
    bob = 4 * math.sin(t * 2 * math.pi * 0.8)
    sway = 1.0 * math.sin(t * 2 * math.pi * 0.4)
    head_tilt = -5 * raise_k + 1.5 * math.sin(t * 2 * math.pi * 0.8 + 0.6)
    blink = 1.0
    for bt in (2.1, 4.6):
        d = abs(t - bt)
        if d < 0.12: blink = min(blink, d / 0.12)
    happy = 0.85 < t < 1.5
    mo = 0.4
    for a, b in ((0.8, 1.35), (3.1, 3.6)):
        if a < t < b: mo = 0.4 + 0.6 * math.sin(math.pi * (t - a) / (b - a))
    a1 = 100 + (204 - 100) * raise_k
    a2 = 95 + (-80 - 95) * raise_k + wave * raise_k
    spread = 5 * raise_k + 2.5 * math.sin(t * 9)
    bk = back_out((t - 0.75) / 0.45) if t > 0.75 else 0.0
    hair_sw = 1.8 * math.sin(t * 2 * math.pi * 0.8 - 0.9)
    look = -5 * raise_k

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', DEFS,
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>']
    o.append(f'<g transform="translate(0,{bob:.2f}) rotate({sway:.2f} 540 1050)">')

    # ---------- back hair ----------
    o.append(f'<g transform="translate(0,18) rotate({head_tilt * 0.6 + hair_sw * 0.6:.2f} 540 560)">')
    back = ("M 404 300 C 360 420 352 560 340 700 C 330 800 318 880 300 960 C 330 950 345 962 362 990 "
            "C 380 960 400 972 420 1000 L 660 1000 C 680 972 700 960 718 990 C 735 962 750 950 780 960 "
            "C 762 880 750 800 740 700 C 728 560 720 420 676 300 Z")
    o.append(f'<path d="{back}" fill="url(#hairBackG)" stroke="{HAIR_LINE}" stroke-width="3" stroke-linejoin="round"/>')
    o.append(strands([(380, 520, 362, 760, 330, 950), (402, 600, 392, 800, 380, 980), (700, 520, 718, 760, 750, 950),
                      (678, 600, 690, 800, 700, 985), (360, 700, 350, 820, 318, 940), (722, 700, 734, 820, 762, 945)],
                     HAIR_D, 2.2, 0.6))
    o.append('</g>')

    # ---------- far arm (resting) ----------
    _, sl2, _, _ = arm((702, 742), 84, 88)
    o.append(sl2)

    # ---------- torso ----------
    torso = ("M 518 682 C 470 690 405 692 372 716 C 340 742 326 810 318 1100 L 762 1100 "
             "C 754 810 740 742 708 716 C 675 692 610 690 562 682 Z")
    o.append(f'<clipPath id="torsoC"><path d="{torso}"/></clipPath>')
    o.append(f'<path d="{torso}" fill="url(#blouseG)" stroke="{CLOTH_LINE}" stroke-width="4.5"/>')
    o.append(f'<g clip-path="url(#torsoC)">'
             f'<path d="M 700 760 C 740 850 745 980 740 1100 L 800 1100 L 800 700 Z" fill="{BLOUSE_SH}" opacity="0.8" filter="url(#b8)"/>'
             f'<path d="M 470 900 C 480 960 470 1030 476 1100" fill="none" stroke="{BLOUSE_SH}" stroke-width="10" filter="url(#b3)"/>'
             f'<path d="M 610 900 C 600 970 612 1030 604 1100" fill="none" stroke="{BLOUSE_SH}" stroke-width="10" filter="url(#b3)"/>'
             f'<path d="M 380 830 C 440 860 460 900 470 940" fill="none" stroke="{BLOUSE_SH}" stroke-width="6" filter="url(#b3)"/>'
             f'</g>')
    # neck
    o.append(f'<path d="M 514 590 L 512 692 Q 540 708 568 692 L 566 590 Z" fill="{SKIN}" stroke="{SKIN_LINE}" stroke-width="3"/>'
             f'<path d="M 514 600 Q 540 660 566 600 L 566 640 Q 540 684 514 640 Z" fill="{SKIN_SH}"/>')
    # sailor collar
    collar = ("M 474 694 L 404 712 C 380 752 394 800 426 816 L 540 912 L 654 816 C 686 800 700 752 676 712 "
              "L 606 694 L 540 822 Z")
    o.append(f'<path d="M 404 720 C 384 760 396 806 430 822 L 540 924 L 650 822 C 684 806 696 760 676 720" '
             f'fill="#000" opacity="0.10" filter="url(#b8)"/>')
    o.append(f'<path d="{collar}" fill="url(#navyG)" stroke="{NAVY_D}" stroke-width="3.5" stroke-linejoin="round"/>')
    for off in (0, 11):
        o.append(f'<path d="M {418 + off * 0.6} {730 + off * 0.2} C {408 + off} {766} {422 + off} {792 - off * 0.3} {444 + off * 0.4} {802 - off * 0.6} '
                 f'L 540 {884 - off * 1.1} L {636 - off * 0.4} {802 - off * 0.6} C {658 - off} {792 - off * 0.3} {672 - off} 766 {662 - off * 0.6} {730 + off * 0.2}" '
                 f'fill="none" stroke="#ffffff" stroke-width="3"/>')
    o.append(f'<path d="M 488 698 L 540 812 L 592 698 Q 540 722 488 698 Z" fill="{BLOUSE}" stroke="{CLOTH_LINE}" stroke-width="2.5"/>'
             f'<path d="M 508 704 Q 540 726 572 704 L 566 724 Q 540 742 514 724 Z" fill="{SKIN}"/>'
             f'<path d="M 500 712 L 540 790 L 580 712" fill="none" stroke="{BLOUSE_SH}" stroke-width="8" filter="url(#b3)"/>')
    # ribbon tie
    o.append('<g transform="translate(540,866)">'
             f'<path d="M -10 2 C -40 -30 -70 -40 -78 -22 C -84 -4 -80 20 -72 34 C -56 34 -34 22 -10 10 Z" fill="url(#tieG)" stroke="{TIE_D}" stroke-width="3" stroke-linejoin="round"/>'
             f'<path d="M 10 2 C 40 -30 70 -40 78 -22 C 84 -4 80 20 72 34 C 56 34 34 22 10 10 Z" fill="url(#tieG)" stroke="{TIE_D}" stroke-width="3" stroke-linejoin="round"/>'
             f'<path d="M -60 -18 Q -40 -4 -18 2 M -64 18 Q -44 10 -20 8 M 60 -18 Q 40 -4 18 2 M 64 18 Q 44 10 20 8" fill="none" stroke="{TIE_D}" stroke-width="2" opacity="0.7"/>'
             f'<path d="M -8 10 C -14 40 -24 70 -34 98 L -18 90 L -8 106 C 0 76 2 40 2 12 Z" fill="url(#tieG)" stroke="{TIE_D}" stroke-width="3" stroke-linejoin="round"/>'
             f'<path d="M 8 10 C 14 40 22 66 30 92 L 14 86 L 4 102 C 0 72 0 40 2 12 Z" fill="url(#tieG)" stroke="{TIE_D}" stroke-width="3" stroke-linejoin="round"/>'
             f'<rect x="-15" y="-16" width="30" height="32" rx="9" fill="url(#tieG)" stroke="{TIE_D}" stroke-width="3"/>'
             f'<path d="M -8 -10 Q 0 -13 8 -10" stroke="#fff" stroke-width="2.5" opacity="0.7" fill="none" stroke-linecap="round"/></g>')

    # ---------- head ----------
    o.append(f'<g transform="translate(0,18) rotate({head_tilt:.2f} 540 620)">')
    face = ("M 420 380 C 418 470 452 545 500 586 C 520 602 532 610 540 612 C 548 610 560 602 580 586 "
            "C 628 545 662 470 660 380 C 660 280 608 222 540 222 C 472 222 420 280 420 380 Z")
    o.append(f'<clipPath id="faceC"><path d="{face}"/></clipPath>')
    o.append(f'<path d="{face}" fill="url(#skinG)" stroke="{SKIN_LINE}" stroke-width="3"/>')
    # bangs cast shadow on forehead
    o.append(f'<g clip-path="url(#faceC)"><path d="M 400 300 L 680 300 L 680 420 C 650 470 636 430 620 446 C 604 420 590 452 568 438 '
             f'C 552 460 540 470 530 450 C 512 436 500 452 490 430 C 476 448 460 430 446 450 C 430 440 420 470 400 440 Z" '
             f'fill="{SKIN_SH}" opacity="0.9"/></g>')
    # blush
    o.append('<ellipse cx="470" cy="520" rx="38" ry="18" fill="#ff8c9e" opacity="0.45" filter="url(#b8)"/>'
             '<ellipse cx="610" cy="520" rx="38" ry="18" fill="#ff8c9e" opacity="0.45" filter="url(#b8)"/>')
    for bx in (452, 592):
        for k in range(3):
            o.append(f'<line x1="{bx + k * 11}" y1="526" x2="{bx + 6 + k * 11}" y2="516" stroke="#f58a9c" stroke-width="2" '
                     f'stroke-linecap="round" opacity="0.8"/>')
    # eyes
    if happy:
        o.append(happy_eye(478, 462, -1)); o.append(happy_eye(602, 462, 1))
    else:
        o.append(eye(478, 462, -1, blink, look, "L"))
        o.append(eye(602, 462, 1, blink, look, "R"))
    # brows
    o.append(f'<path d="M 448 404 Q 476 392 506 400" fill="none" stroke="{HAIR_LINE}" stroke-width="3.2" stroke-linecap="round"/>'
             f'<path d="M 574 400 Q 604 392 632 404" fill="none" stroke="{HAIR_LINE}" stroke-width="3.2" stroke-linecap="round"/>')
    # nose
    o.append(f'<path d="M 546 512 Q 548 522 540 526" fill="none" stroke="{SKIN_SH2}" stroke-width="2.6" stroke-linecap="round"/>')
    # mouth
    d = 6 + 22 * mo; w = 17 + 6 * mo
    mp = (f"M {f(540 - w)} 552 Q 540 557 {f(540 + w)} 552 C {f(540 + w * 0.8)} {f(556 + d * 0.8)} {f(540 + w * 0.35)} {f(553 + d)} 540 {f(553 + d)} "
          f"C {f(540 - w * 0.35)} {f(553 + d)} {f(540 - w * 0.8)} {f(556 + d * 0.8)} {f(540 - w)} 552 Z")
    o.append(f'<clipPath id="mC"><path d="{mp}"/></clipPath>')
    o.append(f'<path d="{mp}" fill="#9c2f45"/>')
    o.append(f'<g clip-path="url(#mC)"><ellipse cx="540" cy="{f(556 + d)}" rx="{f(w * 0.75)}" ry="{f(d * 0.5 + 2)}" fill="#f2899a"/>'
             f'<rect x="{f(540 - w)}" y="550" width="{f(2 * w)}" height="5" fill="#ffffff" opacity="0.9"/></g>')
    o.append(f'<path d="{mp}" fill="none" stroke="#7a2236" stroke-width="2.5" stroke-linejoin="round"/>')
    o.append(f'<path d="M {f(540 - w - 3)} 549 Q {f(540 - w)} 552 {f(540 - w + 2)} 554 M {f(540 + w + 3)} 549 Q {f(540 + w)} 552 {f(540 + w - 2)} 554" '
             f'fill="none" stroke="#b05a60" stroke-width="2" stroke-linecap="round"/>')

    # side locks (frame face, fall in front of shoulders)
    o.append(f'<g transform="rotate({hair_sw * 0.8:.2f} 420 330)">')
    for d_ in (lock(414, 340, 372, 780, 40, -22), lock(424, 372, 404, 700, 24, -10)):
        o.append(f'<path d="{d_}" fill="url(#hairG)" stroke="{HAIR_LINE}" stroke-width="3" stroke-linejoin="round"/>')
    o.append(strands([(410, 400, 396, 560, 380, 750)], HAIR_D, 2, 0.6))
    o.append('</g>')
    o.append(f'<g transform="rotate({hair_sw * 0.8:.2f} 660 330)">')
    for d_ in (lock(666, 340, 708, 780, 40, 22), lock(656, 372, 676, 700, 24, 10)):
        o.append(f'<path d="{d_}" fill="url(#hairG)" stroke="{HAIR_LINE}" stroke-width="3" stroke-linejoin="round"/>')
    o.append(strands([(670, 400, 684, 560, 700, 750)], HAIR_D, 2, 0.6))
    o.append('</g>')

    # crown + bangs
    seq = [(404, 468), ('n', 432, 372), ('t', 450, 430), ('n', 466, 352), ('t', 488, 416), ('n', 504, 344),
           ('t', 528, 440), ('n', 546, 346), ('t', 566, 424), ('n', 584, 350), ('t', 606, 414), ('n', 620, 360),
           ('t', 640, 432), ('n', 652, 372), (676, 468)]
    dd = "M 676 468 C 694 360 660 206 540 204 C 420 206 386 360 404 468 "
    prev = (404, 468)
    for item in seq[1:]:
        if len(item) == 3:
            kind, x, y = item
        else:
            kind, (x, y) = 'e', item
        px, py = prev
        if kind == 't':
            dd += f"C {px + 2} {py + (y - py) * 0.55:.0f} {x - 5} {y - 16} {x} {y} "
        else:
            dd += f"C {px + 5} {py - 16} {x - 2} {y + (py - y) * 0.55:.0f} {x} {y} "
        prev = (x, y)
    dd += "Z"
    o.append(f'<clipPath id="bangC"><path d="{dd}"/></clipPath>')
    o.append(f'<path d="{dd}" fill="url(#hairG)"/>')
    o.append('<g clip-path="url(#bangC)">')
    # angel-ring highlight
    o.append(f'<path d="M 420 300 C 460 250 620 250 662 300 L 664 318 C 650 304 640 326 626 306 C 612 324 598 300 584 316 '
             f'C 568 298 556 320 540 302 C 524 320 512 298 496 316 C 482 300 470 324 456 306 C 444 326 430 304 418 320 Z" '
             f'fill="{HAIR_HL}" opacity="0.85"/>')
    o.append(f'<path d="M 540 204 C 470 210 430 260 420 300 C 470 252 610 252 662 300 C 650 260 610 210 540 204 Z" fill="{HAIR_L}" opacity="0.55"/>')
    # strands converging to parting
    sl = []
    for (x, y) in [(432, 372), (450, 430), (466, 352), (488, 416), (504, 344), (528, 440), (546, 346), (566, 424),
                   (584, 350), (606, 414), (620, 360), (640, 432), (652, 372)]:
        rx_ = 540 + (x - 540) * 0.45; ry_ = 222 + abs(x - 540) * 0.25
        sl.append((f(rx_), f(ry_), f((rx_ + x) / 2 + (x - 540) * 0.12), f((ry_ + y) / 2 - 10), x, y - 6))
    o.append(strands(sl, HAIR_D, 2.0, 0.55))
    o.append(f'<path d="M 404 468 C 400 420 420 380 440 360 L 440 470 Z" fill="{HAIR_D}" opacity="0.35" filter="url(#b8)"/>')
    o.append('</g>')
    o.append(f'<path d="{dd}" fill="none" stroke="{HAIR_LINE}" stroke-width="3" stroke-linejoin="round"/>')
    # a couple of loose strands over bangs
    o.append(f'<path d="M 500 300 Q 512 360 494 428" fill="none" stroke="{HAIR_LINE}" stroke-width="1.8" stroke-linecap="round"/>'
             f'<path d="M 590 300 Q 586 370 602 422" fill="none" stroke="{HAIR_LINE}" stroke-width="1.8" stroke-linecap="round"/>')

    # ribbon bow
    o.append('<g transform="translate(652,276) rotate(26)">'
             f'<path d="M 0 0 C -24 -44 -74 -40 -70 -2 C -66 30 -28 28 0 0 Z" fill="url(#mintG)" stroke="{MINT_D}" stroke-width="3"/>'
             f'<path d="M 0 0 C 24 -44 74 -40 70 -2 C 66 30 28 28 0 0 Z" fill="url(#mintG)" stroke="{MINT_D}" stroke-width="3"/>'
             f'<path d="M -12 -6 Q -40 -18 -58 -6 M 12 -6 Q 40 -18 58 -6" fill="none" stroke="{MINT_D}" stroke-width="2" opacity="0.7"/>'
             f'<path d="M -4 8 C -10 26 -16 40 -22 54 L -8 48 L -2 60 C 2 42 4 24 2 8 Z" fill="url(#mintG)" stroke="{MINT_D}" stroke-width="3" stroke-linejoin="round"/>'
             f'<path d="M 4 8 C 12 24 18 38 26 50 L 12 46 L 6 58 C 4 40 2 24 2 8 Z" fill="url(#mintG)" stroke="{MINT_D}" stroke-width="3" stroke-linejoin="round"/>'
             f'<ellipse cx="0" cy="0" rx="12" ry="13" fill="url(#mintG)" stroke="{MINT_D}" stroke-width="3"/></g>')
    o.append('</g>')  # head

    # ---------- waving arm ----------
    wrist, sleeve, Hd, Wr = arm((380, 742), a1, a2)
    o.append(wrist)
    o.append(hand(Hd[0], Hd[1], a2, spread))
    o.append(sleeve)
    o.append('</g>')

    # ---------- speech bubble ----------
    if bk > 0.001:
        o.append(f'<g transform="translate(870,190) scale({bk * 0.82:.3f})">'
                 f'<path d="M -128 -60 Q -128 -82 -106 -82 L 108 -82 Q 130 -82 130 -60 L 130 48 Q 130 70 108 70 '
                 f'L -24 70 L -78 122 L -60 70 L -106 70 Q -128 70 -128 48 Z" fill="#000" opacity="0.08" '
                 f'transform="translate(6,8)" filter="url(#b3)"/>'
                 f'<path d="M -128 -60 Q -128 -82 -106 -82 L 108 -82 Q 130 -82 130 -60 L 130 48 Q 130 70 108 70 '
                 f'L -24 70 L -78 122 L -60 70 L -106 70 Q -128 70 -128 48 Z" fill="#ffffff" stroke="{LASH}" '
                 f'stroke-width="5" stroke-linejoin="round"/>'
                 f'<text x="0" y="24" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-weight="bold" '
                 f'font-size="84" fill="{TIE}">Hi!</text></g>')
        for (sx, sy, ph, sz) in ((1012, 86, 0.0, 1.0), (716, 92, 1.3, 0.7), (1010, 330, 2.4, 0.6)):
            sc = bk * sz * (0.75 + 0.25 * math.sin(t * 6 + ph))
            o.append(f'<g transform="translate({sx},{sy}) scale({sc:.3f})">'
                     f'<path d="M 0 -26 Q 4 -4 26 0 Q 4 4 0 26 Q -4 4 -26 0 Q -4 -4 0 -26 Z" fill="#ffd25a"/></g>')
    o.append('</svg>')
    return "".join(o)


if __name__ == "__main__":
    sys.stdout.write(frame_svg(float(sys.argv[1])))
