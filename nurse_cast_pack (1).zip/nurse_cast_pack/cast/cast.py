"""Supporting cast built on the nurse's base (same face/eye construction, line weights, shading)."""
import math, sys
import draw2, draw3
from draw2 import pt, f, quad, limb_layers, lock, strands, eye, LASH
from draw3 import hand2, leg_path, _corners

W, H = 1080, 1920
SC, TY = 0.9, 20
CL = 2.6
SQ = '<g transform="translate(540,0) scale(0.9,1) translate(-540,0)">'


def set_skin(C):
    for mod in (draw2, draw3):
        mod.SKIN, mod.SKIN_SH, mod.SKIN_SH2, mod.SKIN_LINE = C['skin']


def defs(C):
    hl, h, hd = C['hair_g']
    i0, i1, i2, i3 = C['iris']
    t0, t1, t2 = C['top_g']
    b0, b1, b2 = C.get('bottom_g', C['top_g'])
    sk = C['skin']
    cg = C.get('coat_g', ('#ffffff', '#f6f7fb', '#dfe3ee'))
    return f'''<defs>
<filter id="b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
<filter id="b8" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8"/></filter>
<filter id="b14" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14"/></filter>
<linearGradient id="hairU" gradientUnits="userSpaceOnUse" x1="0" y1="200" x2="0" y2="{C.get('hair_len', 900)}">
 <stop offset="0" stop-color="{hl}"/><stop offset="0.3" stop-color="{h}"/><stop offset="1" stop-color="{hd}"/></linearGradient>
<radialGradient id="irisG" cx="0.5" cy="0.72" r="0.75">
 <stop offset="0" stop-color="{i0}"/><stop offset="0.35" stop-color="{i1}"/><stop offset="0.75" stop-color="{i2}"/><stop offset="1" stop-color="{i3}"/></radialGradient>
<linearGradient id="irisTop" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#120a10" stop-opacity="0.9"/><stop offset="0.5" stop-color="#120a10" stop-opacity="0.15"/><stop offset="0.6" stop-color="#120a10" stop-opacity="0"/></linearGradient>
<linearGradient id="scleraG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d9cfe0"/><stop offset="0.35" stop-color="#ffffff"/></linearGradient>
<linearGradient id="topG" gradientUnits="userSpaceOnUse" x1="300" y1="0" x2="780" y2="0">
 <stop offset="0" stop-color="{t0}"/><stop offset="0.65" stop-color="{t1}"/><stop offset="1" stop-color="{t2}"/></linearGradient>
<linearGradient id="botG" gradientUnits="userSpaceOnUse" x1="300" y1="0" x2="780" y2="0">
 <stop offset="0" stop-color="{b0}"/><stop offset="0.65" stop-color="{b1}"/><stop offset="1" stop-color="{b2}"/></linearGradient>
<linearGradient id="coatG" gradientUnits="userSpaceOnUse" x1="300" y1="0" x2="780" y2="0">
 <stop offset="0" stop-color="{cg[0]}"/><stop offset="0.6" stop-color="{cg[1]}"/><stop offset="1" stop-color="{cg[2]}"/></linearGradient>
<linearGradient id="skinG" x1="0" y1="0" x2="1" y2="0">
 <stop offset="0" stop-color="{sk[0]}"/><stop offset="0.72" stop-color="{sk[0]}"/><stop offset="1" stop-color="{sk[1]}"/></linearGradient>
<radialGradient id="metal" cx="0.35" cy="0.35" r="0.8"><stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#c9ced9"/><stop offset="1" stop-color="#7d8496"/></radialGradient>
</defs>'''


# ------------------------------------------------------------------ hair styles
def bang_edge(start, end, locks):
    """crown + bangs path: locks = [(notch_x, notch_y, tip_x, tip_y, lean)]"""
    sx, sy = start; ex, ey = end
    d = f"M {ex} {ey} C {ex + 26} 352 672 202 540 200 C 408 202 {sx - 26} 352 {sx} {sy} "
    prev = (sx, sy)
    for (nx, ny, tx, ty, lean) in locks:
        px, py = prev
        d += f"C {px + 4} {py - 26} {nx - 6} {ny + 10} {nx} {ny} "
        d += f"C {nx + 2} {ny + (ty - ny) * 0.5:.0f} {tx - 8 + lean} {ty - 24} {tx} {ty} "
        prev = (tx, ty)
    d += f"C {prev[0] + 6} {prev[1] - 30} {ex - 6} {ey - 30} {ex} {ey} Z"
    return d


def crown_strands(locks, C):
    fl = []
    for (nx, ny, tx, ty, lean) in locks:
        rx = 540 + (tx - 540) * 0.75; ry = 228 + ((tx - 540) / 130) ** 2 * 60
        fl.append((f(rx), f(ry), f((rx + tx) / 2 + lean), f((ry + ty) / 2), f(tx), f(ty - 6)))
        fl.append((f(rx - 8), f(ry + 8), f((rx + tx) / 2 - 6 + lean), f((ry + ty) / 2 + 6), f(tx - 8), f(ty - 30)))
    return strands(fl, C['hair_d'], 1.3, 0.55)


def hair_parts(C):
    """returns (back_svg, front_svg) in head-local coords"""
    st = C['hair']; L = C['hair_line']; HL = C['hair_hl']
    fill = f'fill="url(#hairU)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"'
    back = front = ""
    ring = (f'<path d="M 424 300 C 464 262 616 262 656 300 L 658 318 C 640 306 628 326 612 310 C 598 326 584 304 568 320 '
            f'C 552 302 540 324 524 306 C 508 324 496 302 480 318 C 466 304 452 326 438 310 C 430 322 426 314 422 318 Z" '
            f'fill="{HL}" opacity="0.6" filter="url(#b3)"/>')
    if st == 'bun':
        back = (f'<circle cx="540" cy="214" r="64" {fill}/>'
                + strands([(500, 190, 540, 160, 580, 190), (494, 222, 540, 196, 588, 226), (508, 252, 540, 240, 574, 252)], C['hair_d'], 1.6, 0.6)
                + f'<path d="M 494 268 Q 540 286 586 268" fill="none" stroke="{C["accent"]}" stroke-width="10" stroke-linecap="round"/>')
        locks = [(424, 360, 432, 452, -4), (456, 300, 520, 380, 30), (540, 296, 600, 396, 26), (612, 312, 650, 430, 14)]
        d = bang_edge((400, 470), (680, 470), locks)
        front = (f'<clipPath id="bangC"><path d="{d}"/></clipPath><path d="{d}" fill="url(#hairU)"/>'
                 f'<g clip-path="url(#bangC)">{ring}'
                 + strands([(470, 230, 520, 300, 600, 390), (450, 250, 500, 320, 560, 380), (520, 226, 580, 290, 640, 420),
                            (430, 280, 440, 360, 432, 440), (600, 240, 640, 300, 660, 400)], C['hair_d'], 1.4, 0.6)
                 + f'</g><path d="{d}" fill="none" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>'
                 + f'<path d="{lock(416, 420, 410, 560, 14, -4)}" {fill}/><path d="{lock(664, 420, 670, 560, 14, 4)}" {fill}/>')
    elif st == 'bob':
        back = (f'<path d="M 420 262 C 360 340 346 480 352 600 C 356 650 380 676 420 682 L 660 682 C 700 676 724 650 728 600 '
                f'C 734 480 720 340 660 262 Z" {fill}/>'
                + strands([(380, 420, 370, 540, 390, 660), (700, 420, 710, 540, 690, 660)], C['hair_d'], 1.5, 0.55))
        locks = [(420, 372, 432, 430, -2), (452, 344, 470, 424, -2), (488, 338, 506, 428, 0), (524, 336, 542, 432, 0),
                 (560, 338, 576, 428, 2), (596, 342, 612, 424, 2), (630, 356, 648, 430, 4)]
        d = bang_edge((396, 470), (684, 470), locks)
        front = (f'<path d="{lock(410, 380, 388, 660, 50, -12)}" {fill}/><path d="{lock(670, 380, 692, 660, 50, 12)}" {fill}/>'
                 + strands([(404, 420, 392, 540, 392, 640), (676, 420, 688, 540, 688, 640)], C['hair_d'], 1.4, 0.55)
                 + f'<clipPath id="bangC"><path d="{d}"/></clipPath><path d="{d}" fill="url(#hairU)"/>'
                 f'<g clip-path="url(#bangC)">{ring}{crown_strands(locks, C)}</g>'
                 f'<path d="{d}" fill="none" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>'
                 + f'<path d="M 652 290 l 12 -6 l 2 14 Z" fill="{C["accent"]}" stroke="{L}" stroke-width="1.5"/>')
    elif st == 'short_m':
        back = (f'<path d="M 420 300 C 400 350 402 400 410 440 L 670 440 C 678 400 680 350 660 300 Z" {fill}/>')
        locks = [(424, 340, 426, 436, -2), (452, 300, 500, 370, 22), (520, 292, 570, 378, 24),
                 (590, 300, 630, 392, 16), (650, 340, 662, 440, 6)]
        d = bang_edge((404, 460), (676, 460), locks)
        front = (f'<clipPath id="bangC"><path d="{d}"/></clipPath><path d="{d}" fill="url(#hairU)"/>'
                 f'<g clip-path="url(#bangC)">{ring}{crown_strands(locks, C)}</g>'
                 f'<path d="{d}" fill="none" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>'
                 f'<path d="M 404 400 L 402 476 L 416 470 Z" {fill}/><path d="M 676 400 L 678 476 L 664 470 Z" {fill}/>')
    elif st == 'soft_m':
        back = (f'<path d="M 418 290 C 380 360 376 460 386 540 L 398 612 L 428 588 L 446 630 L 476 600 L 604 600 '
                f'L 634 630 L 652 588 L 682 612 L 694 540 C 704 460 700 360 662 290 Z" {fill}/>'
                + strands([(400, 420, 392, 520, 404, 604), (680, 420, 688, 520, 676, 604)], C['hair_d'], 1.5, 0.55))
        locks = [(414, 372, 430, 454, -6), (446, 340, 472, 440, 6), (486, 330, 514, 448, 10), (526, 326, 558, 454, 12),
                 (568, 332, 596, 442, 10), (608, 342, 630, 432, 8), (642, 362, 656, 452, 6)]
        d = bang_edge((398, 470), (682, 470), locks)
        front = (f'<path d="{lock(416, 380, 404, 566, 48, -10)}" {fill}/><path d="{lock(664, 380, 676, 566, 48, 10)}" {fill}/>'
                 + strands([(412, 420, 404, 500, 406, 556), (668, 420, 676, 500, 674, 556)], C['hair_d'], 1.4, 0.55)
                 + f'<clipPath id="bangC"><path d="{d}"/></clipPath><path d="{d}" fill="url(#hairU)"/>'
                 f'<g clip-path="url(#bangC)">{ring}{crown_strands(locks, C)}</g>'
                 f'<path d="{d}" fill="none" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>'
                 f'<path d="{lock(566, 352, 586, 482, 8, 6)}" {fill}/><path d="{lock(500, 356, 490, 470, 7, -4)}" {fill}/>')
    elif st == 'messy_m':
        back = (f'<path d="M 412 300 L 384 330 L 400 360 L 372 400 L 398 420 L 384 470 L 414 470 C 430 540 470 590 500 600 '
                f'L 580 600 C 610 590 650 540 666 470 L 696 470 L 682 420 L 708 400 L 680 360 L 696 330 L 668 300 Z" {fill}/>')
        locks = [(420, 350, 424, 446, -10), (450, 316, 474, 410, 6), (498, 300, 512, 420, -6), (540, 296, 566, 400, 12),
                 (590, 300, 604, 420, -4), (630, 318, 652, 408, 10), (660, 352, 664, 446, 8)]
        d = bang_edge((400, 466), (680, 466), locks)
        spikes = (f'<path d="M 480 214 Q 452 186 446 158 Q 486 172 506 200 Q 512 168 532 150 Q 536 182 546 204 '
                  f'Q 580 180 618 184 Q 596 204 600 226 Z" {fill}/>')
        front = (spikes + f'<clipPath id="bangC"><path d="{d}"/></clipPath><path d="{d}" fill="url(#hairU)"/>'
                 f'<g clip-path="url(#bangC)">{ring}{crown_strands(locks, C)}</g>'
                 f'<path d="{d}" fill="none" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>')
    return back, front


# ------------------------------------------------------------------ head
FACE_F = ("M 414 392 C 410 462 432 530 478 576 C 502 598 524 608 540 608 C 556 608 578 598 602 576 "
          "C 648 530 670 462 666 392 C 664 290 610 232 540 232 C 470 232 416 290 414 392 Z")
FACE_M = ("M 420 392 C 418 452 424 502 440 536 C 456 568 490 600 514 616 C 526 623 534 626 540 626 "
          "C 546 626 554 623 566 616 C 590 600 624 568 640 536 C 656 502 662 452 660 392 "
          "C 658 290 610 232 540 232 C 470 232 422 290 420 392 Z")


FACE_P = ("M 418 392 C 416 462 434 532 474 578 C 498 602 522 616 540 616 C 558 616 582 602 606 578 "
          "C 646 532 664 462 662 392 C 660 290 610 232 540 232 C 470 232 420 290 418 392 Z")


def ears(C):
    sk, sksh, sksh2, skl = C['skin']
    o = []
    for sgn in (1, -1):
        X = lambda x: f(540 + sgn * (x - 540))
        o.append(f'<path d="M {X(426)} 446 C {X(408)} 432 {X(392)} 446 {X(394)} 474 C {X(396)} 502 {X(408)} 522 {X(430)} 526 Z" '
                 f'fill="{sk}" stroke="{skl}" stroke-width="{CL}" stroke-linejoin="round"/>'
                 f'<path d="M {X(420)} 458 C {X(406)} 454 {X(402)} 470 {X(406)} 486 C {X(410)} 500 {X(416)} 508 {X(424)} 508" '
                 f'fill="none" stroke="{sksh2}" stroke-width="2.4" stroke-linecap="round"/>'
                 f'<path d="M {X(426)} 452 C {X(410)} 448 {X(402)} 462 {X(404)} 480" fill="none" stroke="{sksh}" stroke-width="6" opacity="0.7"/>')
    return "".join(o)


def head(C):
    male = C['male']
    sk, sksh, sksh2, skl = C['skin']
    pretty = C.get('pretty')
    face = FACE_P if pretty else (FACE_M if male else FACE_F)
    back, front = hair_parts(C)
    o = [f'<g transform="translate(0,{48 if male else 30})">']
    if male and not pretty:
        o.append(ears(C))
    o.append(f'<clipPath id="faceC"><path d="{face}"/></clipPath>')
    o.append(f'<path d="{face}" fill="url(#skinG)" stroke="{skl}" stroke-width="{CL}"/>')
    o.append(f'<g clip-path="url(#faceC)"><path d="M 400 300 L 680 300 L 680 450 Q 540 400 400 450 Z" fill="{sksh}" opacity="0.7" filter="url(#b8)"/>'
             f'<path d="M 640 400 C 660 470 640 540 600 590 L 690 610 L 690 380 Z" fill="{sksh}" opacity="0.6" filter="url(#b8)"/></g>')
    if not male:
        o.append('<ellipse cx="466" cy="530" rx="36" ry="16" fill="#ff8c9e" opacity="0.4" filter="url(#b8)"/>'
                 '<ellipse cx="614" cy="530" rx="36" ry="16" fill="#ff8c9e" opacity="0.4" filter="url(#b8)"/>')
    elif pretty:
        o.append('<ellipse cx="468" cy="532" rx="32" ry="13" fill="#ff8c9e" opacity="0.26" filter="url(#b8)"/>'
                 '<ellipse cx="612" cy="532" rx="32" ry="13" fill="#ff8c9e" opacity="0.26" filter="url(#b8)"/>')
    else:
        o.append(f'<g clip-path="url(#faceC)"><path d="M 440 536 C 456 568 490 600 540 626 C 590 600 624 568 640 536 L 640 650 L 440 650 Z" '
                 f'fill="{sksh}" opacity="0.35" filter="url(#b8)"/></g>'
                 f'<path d="M 528 606 Q 540 612 552 606" fill="none" stroke="{sksh2}" stroke-width="2" stroke-linecap="round" opacity="0.7"/>')
        o.append('<ellipse cx="470" cy="534" rx="30" ry="12" fill="#f0a090" opacity="0.18" filter="url(#b8)"/>'
                 '<ellipse cx="610" cy="534" rx="30" ry="12" fill="#f0a090" opacity="0.18" filter="url(#b8)"/>')
    # eyes
    ex, ey = 64, 474
    sy = 0.9 if pretty else (0.74 if male else 1.0)
    sx = 1.02 if pretty else (0.9 if male else 1.08)
    for (cx, s, uid) in ((540 - ex, -1, "L"), (540 + ex, 1, "R")):
        o.append(f'<g transform="translate({cx},{ey}) scale({sx},{sy * (1.08 if not male else 1)}) translate({-cx},{-ey})">')
        o.append(eye(cx, ey, s, 1.0, C.get('look', 0), uid))
        o.append('</g>')
    # brows
    bc = C['hair_d']
    if male:
        bw = 4 if pretty else 6
        o.append(f'<path d="M 442 418 Q 474 404 508 410" fill="none" stroke="{bc}" stroke-width="{bw}" stroke-linecap="round"/>'
                 f'<path d="M 572 410 Q 606 404 638 418" fill="none" stroke="{bc}" stroke-width="{bw}" stroke-linecap="round"/>')
    else:
        tilt = C.get('brow_tilt', 0)
        o.append(f'<path d="M 450 {412 - tilt} Q 476 {402} 504 {408 + tilt}" fill="none" stroke="{bc}" stroke-width="2.8" stroke-linecap="round"/>'
                 f'<path d="M 576 {408 + tilt} Q 604 402 630 {412 - tilt}" fill="none" stroke="{bc}" stroke-width="2.8" stroke-linecap="round"/>')
    if male and not pretty:
        o.append(f'<path d="M 549 522 Q 552 536 551 541 Q 547 547 539 547" fill="none" stroke="{sksh2}" stroke-width="2.4" stroke-linecap="round"/>')
    else:
        o.append(f'<path d="M 544 532 Q 547 540 540 543" fill="none" stroke="{sksh2}" stroke-width="2.4" stroke-linecap="round"/>')
    # mouth
    my = 566 if pretty else (572 if male else 562)
    m = C['mouth']
    if m == 'open':
        d, w = 12, 15
        mp = (f"M {540 - w} {my} Q 540 {my + 4} {540 + w} {my} C {540 + w * 0.8} {my + d * 0.8:.0f} {540 + w * 0.35:.0f} {my + d} 540 {my + d} "
              f"C {540 - w * 0.35:.0f} {my + d} {540 - w * 0.8:.0f} {my + d * 0.8:.0f} {540 - w} {my} Z")
        o.append(f'<path d="{mp}" fill="#a3354b" stroke="#7a2236" stroke-width="2.2" stroke-linejoin="round"/>'
                 f'<ellipse cx="540" cy="{my + d - 3}" rx="8" ry="4" fill="#f2899a"/>')
    elif m == 'smile':
        o.append(f'<path d="M 524 {my} Q 540 {my + 10} 558 {my - 2}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>')
    elif m == 'stern':
        o.append(f'<path d="M 528 {my + 2} Q 540 {my - 1} 552 {my + 2}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>')
    elif m == 'nervous':
        o.append(f'<path d="M 520 {my + 2} Q 528 {my - 4} 536 {my + 2} Q 544 {my + 8} 552 {my + 1} Q 558 {my - 3} 562 {my}" '
                 f'fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>')
    o.append(front)
    if C.get('glasses'):
        gc = C['glasses']
        o.append(f'<g fill="none" stroke="{gc}" stroke-width="4">'
                 f'<rect x="428" y="446" width="98" height="64" rx="16"/><rect x="554" y="446" width="98" height="64" rx="16"/>'
                 f'<path d="M 526 470 Q 540 462 554 470"/><path d="M 428 466 L 414 460 M 652 466 L 666 460"/></g>'
                 f'<path d="M 440 456 L 470 456" stroke="#ffffff" stroke-width="4" opacity="0.8" stroke-linecap="round"/>'
                 f'<path d="M 566 456 L 596 456" stroke="#ffffff" stroke-width="4" opacity="0.8" stroke-linecap="round"/>')
    if C.get('sweat'):
        o.append('<path d="M 690 360 C 676 392 680 410 694 410 C 708 410 712 392 690 360 Z" fill="#bfe4ff" stroke="#6aa6d6" stroke-width="2.5"/>'
                 '<ellipse cx="690" cy="398" rx="4" ry="6" fill="#ffffff"/>')
    o.append('</g>')
    return back, "".join(o)


# ------------------------------------------------------------------ limbs
def arm(C, S, a1, a2, sleeve):
    """sleeve: 'short' | 'long' (coat) ; colors from C"""
    male = C['male']
    L1, L2 = (196, 182) if male else (184, 172)
    w = 1.18 if male else 1.0
    sk, sksh, sksh2, skl = C['skin']
    E = pt(S, a1, L1); M = pt(E, a2, L2 * 0.32); Hd = pt(E, a2, L2 * 0.98)
    skin = [('q', quad(S, E, 31 * w, 21 * w)), ('c', E[0], E[1], 21 * w), ('q', quad(E, M, 21 * w, 23 * w)),
            ('c', M[0], M[1], 23 * w), ('q', quad(M, Hd, 23 * w, 12.5 * w))]
    o = [limb_layers(skin, sk, skl, 3.5)]
    sl = []
    if sleeve == 'short':
        S0 = pt(S, a1, -22); SE = pt(S, a1, L1 * 0.52)
        (c0, c1, c2, c3), (ux, uy) = _corners(S0, SE, 43 * w, 34 * w)
        hc = (SE[0] + ux * 9, SE[1] + uy * 9)
        body = f"M {f(c0[0])} {f(c0[1])} L {f(c1[0])} {f(c1[1])} Q {f(hc[0])} {f(hc[1])} {f(c2[0])} {f(c2[1])} L {f(c3[0])} {f(c3[1])} Z"
        sl.append(f'<path d="{body}" fill="url(#{C["sleeve_fill"]})"/>')
        (d0, _, _, d3), _ = _corners(S, SE, 41 * w, 34 * w)
        sl.append(f'<path d="M {f(d0[0])} {f(d0[1])} L {f(c1[0])} {f(c1[1])} Q {f(hc[0])} {f(hc[1])} {f(c2[0])} {f(c2[1])} '
                  f'L {f(d3[0])} {f(d3[1])}" fill="none" stroke="{C["top_line"]}" stroke-width="3" stroke-linejoin="round"/>')
        tr = pt(S, a1, L1 * 0.47)
        sl.append(f'<g transform="translate({f(tr[0])},{f(tr[1])}) rotate({a1 + 90:.1f})">'
                  f'<path d="M {-34 * w:.0f} 0 Q 0 6 {34 * w:.0f} 0" fill="none" stroke="{C.get("trim", "#ffffff")}" stroke-width="3" opacity="0.9"/></g>')
    else:  # long coat sleeve to the wrist
        Cf = pt(E, a2, L2 * 0.74)
        parts = [('c', S[0], S[1], 33 * w), ('q', quad(S, E, 34 * w, 30 * w)), ('c', E[0], E[1], 30 * w), ('q', quad(E, Cf, 30 * w, 27 * w))]
        cline = C.get('coat_line', '#8a8fa0'); ccr = C.get('coat_crease', '#d6d9e4')
        if C.get('cuffs'):
            Cu = pt(E, a2, L2 * 0.81)
            o.append(limb_layers([('q', quad(Cf, Cu, 25 * w, 23 * w)), ('c', Cu[0], Cu[1], 23 * w)], "#ffffff", "#8a8fa0", 3))
            o.append(f'<g transform="translate({f(Cu[0])},{f(Cu[1])}) rotate({a2 + 90:.1f})"><circle cx="{-12 * w:.0f}" cy="-6" r="5" fill="{C["cuffs"]}" stroke="#8a6a1e" stroke-width="1.6"/></g>')
        sl.append(limb_layers(parts, "url(#coatG)", cline, 3.2))
        sl.append(f'<g transform="translate({f(E[0])},{f(E[1])}) rotate({a2:.1f})" fill="none" stroke="{ccr}" stroke-width="3" stroke-linecap="round">'
                  f'<path d="M 6 -26 Q 20 -12 16 8"/><path d="M -14 -22 Q 0 -6 -6 14"/></g>')
        sl.append(f'<g transform="translate({f(Cf[0])},{f(Cf[1])}) rotate({a2 + 90:.1f})">'
                  f'<path d="M {-30 * w:.0f} -8 L {30 * w:.0f} -8" stroke="{ccr}" stroke-width="3"/>'
                  + ("".join(f'<circle cx="{x}" cy="-18" r="3.4" fill="{C["cuffs"]}"/>' for x in (8, 18, 28)) if C.get('cuffs') else '') + '</g>')
    if C.get('wristband') and a2 > 60:
        wb = pt(E, a2, L2 * 0.78)
        o.append(f'<g transform="translate({f(wb[0])},{f(wb[1])}) rotate({a2 + 90:.1f})">'
                 f'<rect x="-17" y="-6" width="34" height="12" rx="4" fill="#ffffff" stroke="#8aa0c0" stroke-width="2"/></g>')
    return "".join(o), "".join(sl), Hd


def shoe(x, y, flip, rot, color, line, strap, sc=1.0, heel=True):
    hp = (f'<path d="M -20 28 L -18 42 L -5 42 L -3 30 Z" fill="{line}" opacity="0.6"/>' if heel else '')
    st = (f'<path d="M -18 -2 Q 2 -12 22 -10" fill="none" stroke="{strap}" stroke-width="5" stroke-linecap="round"/>' if strap else '')
    return (f'<g transform="translate({f(x)},{f(y)}) scale({flip * sc},{sc}) rotate({rot})">{hp}'
            f'<path d="M -22 -8 C -28 8 -26 24 -16 30 L 34 30 C 54 31 62 20 56 8 C 50 -4 26 -9 -22 -8 Z" fill="{color}" '
            f'stroke="{line}" stroke-width="3" stroke-linejoin="round"/>'
            f'<path d="M -16 30 L 34 30 C 50 30 58 24 58 16" fill="none" stroke="{line}" stroke-width="3" opacity="0.6"/>{st}'
            f'<ellipse cx="34" cy="8" rx="11" ry="4.5" fill="#ffffff" opacity="0.55"/></g>')


# ------------------------------------------------------------------ legs
LEG_F = [60, 51, 38, 35, 39, 18]
LEG_M = [70, 62, 46, 44, 46, 24]
F_STRAIGHT = {'L': [(498, 1040), (494, 1250), (490, 1440), (488, 1500), (488, 1640), (486, 1830)],
              'R': [(582, 1040), (586, 1250), (590, 1440), (592, 1500), (592, 1640), (594, 1830)]}
M_STRAIGHT = {'L': [(486, 1080), (482, 1320), (478, 1530), (476, 1590), (476, 1740), (474, 1960)],
              'R': [(594, 1080), (598, 1320), (602, 1530), (604, 1590), (604, 1740), (606, 1960)]}


def legs(C):
    male = C['male']
    sk, sksh, sksh2, skl = C['skin']
    geo = M_STRAIGHT if male else (draw3.LEGS and {k: v['cl'] for k, v in draw3.LEGS.items()} if C.get('contra') else F_STRAIGHT)
    ws = LEG_M if male else LEG_F
    o = [f'<ellipse cx="540" cy="{2010 if male else 1880}" rx="200" ry="24" fill="#000" opacity="0.09" filter="url(#b14)"/>']
    pants = C.get('pants')
    for key in ('R', 'L'):
        cl = geo[key]
        d = leg_path(cl, ws)
        o.append(f'<path d="{d}" fill="{sk}" stroke="{skl}" stroke-width="3.2" stroke-linejoin="round"/>')
        k = cl[3]
        o.append(f'<clipPath id="lc{key}"><path d="{d}"/></clipPath><g clip-path="url(#lc{key})">'
                 f'<path d="M {k[0] + 34} 1080 L {k[0] + 30} 1900" stroke="{sksh}" stroke-width="22" opacity="0.6" filter="url(#b8)"/></g>')
        if not male:
            o.append(f'<path d="M {k[0] - 12} {k[1] - 4} Q {k[0]} {k[1] + 6} {k[0] + 12} {k[1] - 4}" fill="none" stroke="{sksh2}" stroke-width="2.2" stroke-linecap="round"/>')
        if pants:
            pw = [w_ + (16 if male else 14) for w_ in ws[:-1]] + [ws[-1] + (30 if male else 26)]
            pcl = cl[:-1] + [(cl[-1][0], cl[-1][1] - 14)]
            pd = leg_path(pcl, pw)
            o.append(f'<path d="{pd}" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>')
            o.append(f'<clipPath id="pc{key}"><path d="{pd}"/></clipPath><g clip-path="url(#pc{key})">'
                     f'<path d="M {k[0] + 44} 1080 L {k[0] + 40} 1960" stroke="{C["bottom_g"][2]}" stroke-width="30" opacity="0.6" filter="url(#b8)"/>'
                     f'<path d="M {k[0] - 26} {k[1] - 10} Q {k[0]} {k[1] + 4} {k[0] + 26} {k[1] - 12}" fill="none" stroke="{C["bottom_line"]}" stroke-width="2.4" opacity="0.6"/></g>')
        a = cl[-1]
        sc_ = 1.25 if male else 1.0
        flip = -1 if key == 'L' else 1
        rot = C.get('shoe_rot', {}).get(key, 4)
        o.append(shoe(a[0], a[1] + 6, flip, rot, *C['shoes'], sc=sc_, heel=not male))
    if pants:  # pelvis
        top = 1060 if male else 1000
        o.append(f'<path d="M {388 if male else 410} {top} L {692 if male else 670} {top} L {700 if male else 676} {top + 150} '
                 f'Q 540 {top + 190} {380 if male else 404} {top + 150} Z" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>'
                 f'<path d="M 540 {top + 60} L 540 {top + 176}" stroke="{C["bottom_line"]}" stroke-width="2.5" opacity="0.7"/>')
    return "".join(o)


# ------------------------------------------------------------------ bodies
TORSO_F = ("M 516 690 C 466 694 410 700 384 718 C 358 740 358 790 362 840 C 368 900 412 950 422 985 "
           "L 422 1014 L 658 1014 L 658 985 C 668 950 712 900 718 840 C 722 790 722 740 696 718 C 670 700 614 694 564 690 Z")
TORSO_F_LONG = ("M 516 690 C 466 694 410 700 384 718 C 358 740 358 790 362 840 C 368 900 412 950 418 990 "
                "C 414 1040 402 1090 398 1124 Q 540 1140 682 1124 C 678 1090 666 1040 662 990 "
                "C 668 950 712 900 718 840 C 722 790 722 740 696 718 C 670 700 614 694 564 690 Z")
TORSO_M = ("M 512 712 C 456 716 392 724 364 746 C 336 770 334 824 340 884 C 346 964 380 1014 390 1064 "
           "L 390 1100 L 690 1100 L 690 1064 C 700 1014 734 964 740 884 C 746 824 744 770 716 746 C 688 724 624 716 568 712 Z")
GOWN_M = ("M 512 712 C 456 716 392 724 364 746 C 336 770 334 824 340 884 C 346 984 360 1100 356 1200 "
          "C 352 1320 346 1420 342 1500 Q 540 1524 738 1500 C 734 1420 728 1320 724 1200 C 720 1100 734 984 740 884 "
          "C 746 824 744 770 716 746 C 688 724 624 716 568 712 Z")


def vneck(C, male):
    dy = 18 if male else 0
    sk = C['skin']
    return (f'<path d="M 488 {694 + dy} L 540 {800 + dy} L 592 {694 + dy} Q 540 {712 + dy} 488 {694 + dy} Z" fill="{sk[0]}" stroke="{sk[3]}" stroke-width="2"/>'
            f'<path d="M 478 {690 + dy} L 540 {812 + dy} L 602 {690 + dy}" fill="none" stroke="{C.get("trim", "#ffffff")}" stroke-width="9" stroke-linejoin="round"/>'
            f'<path d="M 472 {688 + dy} L 540 {822 + dy} L 608 {688 + dy}" fill="none" stroke="{C["top_line"]}" stroke-width="2.2" stroke-linejoin="round"/>'
            f'<path d="M 484 {692 + dy} L 540 {802 + dy} L 596 {692 + dy}" fill="none" stroke="{C["top_line"]}" stroke-width="2.2" stroke-linejoin="round"/>')


def neck(C, male):
    sk = C['skin']
    if male:
        return (f'<path d="M 502 620 L 500 728 Q 540 744 580 728 L 578 620 Z" fill="{sk[0]}" stroke="{sk[3]}" stroke-width="{CL}"/>'
                f'<path d="M 502 628 Q 540 690 578 628 L 578 668 Q 540 712 502 668 Z" fill="{sk[1]}"/>'
                f'<path d="M 536 676 Q 540 682 544 676" fill="none" stroke="{sk[3]}" stroke-width="2"/>')
    return (f'<path d="M 514 590 L 512 700 Q 540 716 568 700 L 566 590 Z" fill="{sk[0]}" stroke="{sk[3]}" stroke-width="{CL}"/>'
            f'<path d="M 514 600 Q 540 660 566 600 L 566 640 Q 540 684 514 640 Z" fill="{sk[1]}"/>')


def badge(x, y, hdr):
    return (f'<line x1="{x + 38}" y1="{y - 28}" x2="{x + 38}" y2="{y}" stroke="#9aa0b0" stroke-width="3"/>'
            f'<rect x="{x}" y="{y}" width="76" height="94" rx="8" fill="#ffffff" stroke="#8a8494" stroke-width="2.4"/>'
            f'<rect x="{x}" y="{y}" width="76" height="22" rx="8" fill="{hdr}"/><rect x="{x}" y="{y + 12}" width="76" height="10" fill="{hdr}"/>'
            f'<circle cx="{x + 38}" cy="{y + 48}" r="15" fill="#ffe1d3" stroke="#8a8494" stroke-width="1.6"/>'
            f'<rect x="{x + 13}" y="{y + 72}" width="50" height="5" rx="2" fill="#c3c6d0"/>')


def stethoscope(dy=0):
    return (f'<g transform="translate(0,{dy})">'
            f'<path d="M 470 700 C 440 760 444 820 466 870" fill="none" stroke="#3b4668" stroke-width="11" stroke-linecap="round"/>'
            f'<path d="M 610 700 C 640 760 640 810 616 860 C 604 884 600 904 604 930" fill="none" stroke="#3b4668" stroke-width="11" stroke-linecap="round"/>'
            f'<circle cx="604" cy="948" r="22" fill="url(#metal)" stroke="#6b7284" stroke-width="2.4"/>'
            f'<circle cx="604" cy="948" r="12" fill="none" stroke="#8a91a3" stroke-width="2"/>'
            f'<circle cx="466" cy="876" r="9" fill="url(#metal)" stroke="#6b7284" stroke-width="2"/></g>')


def suit_front(C):
    """Luxury suit front: white shirt, tie, waistcoat, buttoned jacket with satin lapels (male base)."""
    line = C.get('coat_line', '#0d1226'); gold = C.get('cuffs', '#e2b65a')
    vest = C.get('vest', '#2a3458'); tie, tie_d = C.get('tie', ('#f0cf7e', '#c9973c'))
    lap0, lap1 = C.get('lapel', ('#3c4874', '#222b4c'))
    o = [f'<path d="M 466 708 L 614 708 L 540 900 Z" fill="#ffffff"/>']
    # tie (under waistcoat)
    o.append(f'<path d="M 531 768 L 549 768 L 562 900 L 540 924 L 518 900 Z" fill="{tie}" stroke="#8a6a1e" stroke-width="2.2" stroke-linejoin="round"/>'
             + "".join(f'<path d="M 520 {y} L 560 {y - 18}" stroke="{tie_d}" stroke-width="5" opacity="0.7"/>' for y in (800, 830, 860, 890))
             + f'<path d="M 526 742 L 554 742 L 550 772 L 530 772 Z" fill="{tie}" stroke="#8a6a1e" stroke-width="2.2" stroke-linejoin="round"/>')
    # shirt collar wings
    for sgn in (1, -1):
        X = lambda x: 540 + sgn * (x - 540)
        o.append(f'<path d="M {X(498)} 712 L {X(530)} 748 L {X(516)} 782 L {X(486)} 732 Z" fill="#ffffff" stroke="#8a8fa0" stroke-width="2.2" stroke-linejoin="round"/>')
    # waistcoat
    vd = ("M 476 734 L 540 886 L 604 734 C 640 770 652 900 648 1084 L 600 1112 L 540 1098 L 480 1112 L 432 1084 C 428 900 440 770 476 734 Z")
    o.append(f'<path d="{vd}" fill="{vest}" stroke="{line}" stroke-width="2.6" stroke-linejoin="round"/>'
             f'<path d="M 488 760 L 540 886 L 592 760" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.18"/>')
    for yy in (930, 972, 1014):
        o.append(f'<circle cx="540" cy="{yy}" r="6.5" fill="{gold}" stroke="#8a6a1e" stroke-width="1.8"/>')
    # jacket panels (viewer-right panel overlaps)
    for sgn, inner in ((1, 540), (-1, 547)):
        X = lambda x: f(540 + sgn * (x - 540))
        panel = (f"M {X(468)} 718 C {X(440)} 722 {X(392)} 728 {X(364)} 746 C {X(334)} 772 {X(332)} 830 {X(340)} 890 "
                 f"C {X(350)} 950 {X(372)} 990 {X(374)} 1030 C {X(372)} 1090 {X(360)} 1150 {X(356)} 1198 Q {X(430)} 1224 {X(498)} 1214 Q {X(530)} 1204 {X(inner)} 1150 "
                 f"L {X(inner)} 1040 Z")
        cid = f'jp{sgn + 1}'
        o.append(f'<clipPath id="{cid}"><path d="{panel}"/></clipPath>'
                 f'<path d="{panel}" fill="url(#coatG)" stroke="{line}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<g clip-path="url(#{cid})" opacity="0.1">'
                 + "".join(f'<path d="M {x} 700 L {x} 1230" stroke="#ffffff" stroke-width="1.2"/>' for x in range(332, 760, 17))
                 + '</g>')
        lap = (f"M {X(470)} 718 L {X(inner - 2)} 1036 L {X(500)} 946 L {X(452)} 846 L {X(474)} 830 L {X(446)} 806 L {X(456)} 730 Z")
        o.append(f'<path d="{lap}" fill="{lap0 if sgn == 1 else lap1}" stroke="{line}" stroke-width="2.6" stroke-linejoin="round"/>'
                 f'<path d="M {X(462)} 744 L {X(470)} 812" stroke="#ffffff" stroke-width="3" opacity="0.25" stroke-linecap="round"/>')
        # hip pocket flaps
        o.append(f'<path d="M {X(370)} 1112 L {X(456)} 1108 L {X(458)} 1132 Q {X(412)} 1140 {X(372)} 1136 Z" fill="url(#coatG)" stroke="{line}" stroke-width="2.4"/>')
    # breast pocket + gold pocket square (wearer's left = viewer right)
    o.append(f'<path d="M 602 916 L 616 892 L 628 912 L 640 886 L 652 908 L 662 896 L 664 920 Z" fill="{tie}" stroke="#8a6a1e" stroke-width="2" stroke-linejoin="round"/>'
             f'<path d="M 598 918 L 668 914 L 668 926 L 598 930 Z" fill="url(#coatG)" stroke="{line}" stroke-width="2.4"/>')
    # lapel pin: small gold heart (nod to the nurse's cap)
    o.append(f'<path d="M 612 800 c -6 -8 -16 -2 -10 6 l 10 10 l 10 -10 c 6 -8 -4 -14 -10 -6 Z" fill="{gold}" stroke="#8a6a1e" stroke-width="1.6"/>')
    # jacket button + soft side shade
    o.append(f'<circle cx="540" cy="1050" r="9" fill="{lap1}" stroke="{gold}" stroke-width="3"/>'
             f'<path d="M 704 780 C 740 880 744 1060 740 1200" fill="none" stroke="#000" stroke-width="26" opacity="0.18" filter="url(#b8)"/>')
    return "".join(o)


def body(C):
    """everything below the head, in draw order; returns (behind_head, front_of_head)"""
    male = C['male']; o = []; late = []
    outfit = C['outfit']
    tl = C['top_line']
    if male:
        S_L, S_R = (384, 788), (696, 788)
    else:
        S_L, S_R = (382, 744), (704, 744)
    torso = {'gown': GOWN_M}.get(outfit, TORSO_M if male else (TORSO_F_LONG if C.get('pants') else TORSO_F))
    o.append(f'<clipPath id="torsoC"><path d="{torso}"/></clipPath>')
    suit = outfit == 'suit'
    o.append(f'<path d="{torso}" fill="url(#{"coatG" if suit else "topG"})" stroke="{C.get("coat_line", tl) if suit else tl}" stroke-width="{CL + 1}"/>')
    if not suit: o.append(f'<g clip-path="url(#torsoC)"><path d="M 700 760 C 740 850 760 1100 760 1520 L 820 1520 L 820 700 Z" fill="{C["top_g"][2]}" opacity="0.8" filter="url(#b8)"/>'
             f'<path d="M 360 880 C 376 930 400 960 420 990" fill="none" stroke="{C["top_g"][2]}" stroke-width="10" opacity="0.5" filter="url(#b8)"/></g>')
    if outfit == 'gown':
        dots = "".join(f'<path d="M {x} {y - 5} l 5 5 l -5 5 l -5 -5 Z" fill="#8fb4d8" opacity="0.7"/>'
                       for y in range(780, 1520, 46) for x in range(330 + (y // 46 % 2) * 23, 760, 46))
        o.append(f'<g clip-path="url(#torsoC)">{dots}'
                 f'<path d="M 470 1100 C 474 1260 466 1400 470 1520 M 610 1100 C 606 1260 614 1400 610 1520" fill="none" stroke="#8fb4d8" stroke-width="6" opacity="0.6" filter="url(#b3)"/></g>')
        o.append(neck(C, True))
        o.append(f'<path d="M 476 718 Q 540 784 604 718" fill="none" stroke="#ffffff" stroke-width="8"/>'
                 f'<path d="M 470 714 Q 540 794 610 714" fill="none" stroke="{tl}" stroke-width="2.4"/>'
                 f'<path d="M 690 800 q -16 -16 -24 2 q 16 6 24 -2 q 16 -16 24 2 q -16 6 -24 -2 M 690 802 l -10 26 M 690 802 l 8 28" fill="#dceaf8" stroke="{tl}" stroke-width="2.2"/>')
    else:
        o.append(neck(C, male))
        if outfit == 'suit':
            o.append(suit_front(C))
        else:
            o.append(vneck(C, male))
        if outfit == 'pencil':
            sk_ = ("M 420 982 Q 540 996 660 982 C 678 1040 690 1120 686 1200 C 682 1300 676 1400 672 1470 "
                   "L 408 1470 C 404 1400 398 1300 394 1200 C 390 1120 402 1040 420 982 Z")
            o.append(f'<path d="{sk_}" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>'
                     f'<path d="M 540 1400 L 540 1470" stroke="{C["bottom_line"]}" stroke-width="2.6"/>'
                     f'<path d="M 650 1000 C 680 1150 676 1350 668 1470" stroke="{C["bottom_g"][2]}" stroke-width="22" fill="none" opacity="0.7" filter="url(#b8)"/>'
                     f'<path d="M 418 978 Q 540 994 662 978 L 664 1004 Q 540 1020 416 1004 Z" fill="{C["accent"]}" stroke="{C["bottom_line"]}" stroke-width="2.4"/>'
                     f'<rect x="526" y="980" width="28" height="26" rx="4" fill="#d9dce6" stroke="{C["bottom_line"]}" stroke-width="2"/>')
        if outfit == 'coat':
            for sgn in (1, -1):
                X = lambda x: 540 + sgn * (x - 540)
                panel = (f"M {X(512)} 712 C {X(456)} 716 {X(392)} 724 {X(364)} 746 C {X(334)} 772 {X(330)} 830 {X(334)} 890 "
                         f"C {X(338)} 1010 {X(334)} 1250 {X(330)} 1520 L {X(492)} 1520 L {X(492)} 1040 L {X(474)} 880 L {X(500)} 764 Z")
                o.append(f'<path d="{panel}" fill="url(#coatG)" stroke="#8a8fa0" stroke-width="3" stroke-linejoin="round"/>')
                o.append(f'<path d="M {X(506)} 716 L {X(452)} 770 L {X(470)} 870 L {X(488)} 900 L {X(474)} 880 L {X(500)} 764 Z" fill="#eef0f6" stroke="#8a8fa0" stroke-width="2.4" stroke-linejoin="round"/>')
                o.append(f'<path d="M {X(352)} 1200 L {X(450)} 1200 L {X(452)} 1290 Q {X(400)} 1298 {X(354)} 1290 Z" fill="#f6f7fb" stroke="#8a8fa0" stroke-width="2.4"/>')
                o.append(f'<path d="M {X(480)} 1060 L {X(480)} 1500" stroke="#dfe3ee" stroke-width="10" opacity="0.8" filter="url(#b3)"/>')
            o.append('<rect x="392" y="930" width="70" height="56" rx="4" fill="#f6f7fb" stroke="#8a8fa0" stroke-width="2.4"/>'
                     '<rect x="404" y="902" width="8" height="40" rx="3" fill="#2f6fd6"/><rect x="418" y="906" width="8" height="36" rx="3" fill="#3a3a44"/>')
            for yy in (1060, 1180, 1300):
                o.append(f'<circle cx="502" cy="{yy}" r="7" fill="#f2f2f6" stroke="#8a8fa0" stroke-width="2"/>')
            late.append(stethoscope(26) + badge(612, 960, "#3e8f80"))
        if outfit in ('scrub', 'pencil') and not male:
            late.append(badge(402, 834, C['accent']))
        if outfit == 'scrub' and C.get('pants'):
            o.append(f'<path d="M 404 1040 L 470 1040 L 470 1100 Q 437 1110 404 1100 Z" fill="url(#topG)" stroke="{tl}" stroke-width="2.4"/>'
                     f'<path d="M 610 1040 L 676 1040 L 676 1100 Q 643 1110 610 1100 Z" fill="url(#topG)" stroke="{tl}" stroke-width="2.4"/>')
    # arms
    pose = C['pose']
    sleeve = 'long' if outfit in ('coat', 'suit') else 'short'
    sk1, sl1, Hd1 = arm(C, S_L, *pose['L'], sleeve)
    sk2, sl2, Hd2 = arm(C, S_R, *pose['R'], sleeve)
    hs = 1.18 if male else 1.0
    o.append(sk2 + hand2(Hd2[0], Hd2[1], pose['R'][1], -2, 1.02 * hs) + sl2)
    late.append(sk1 + hand2(Hd1[0], Hd1[1], pose['L'][1], 4 if pose['L'][0] > 150 else -2, 1.02 * hs) + sl1)
    return "".join(o), "".join(late)


def render(C):
    set_skin(C)
    male = C['male']
    back, headsvg = head(C)
    bod, late = body(C)
    sq = '' if male else SQ
    sqe = '' if male else '</g>'
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', defs(C),
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
         f'<g transform="translate({540 * (1 - SC):.1f},{TY}) scale({SC})">',
         f'<g transform="rotate({C.get("lean", 0)} 540 1000)">',
         f'<g transform="translate(0,{48 if male else 30})">{back}</g>' if C['hair'] in ('bun', 'bob', 'short_m', 'messy_m') else '',
         sq + legs(C) + sqe,
         sq + bod + sqe,
         headsvg,
         sq + late + sqe,
         '</g></g></svg>']
    return "".join(o)


SKIN_LIGHT = ("#fff0e6", "#f7cdbd", "#eeb3a2", "#c98774")
SKIN_TAN = ("#f6dcc6", "#e6b99c", "#d39c7e", "#a86f52")
DOWN = {'L': (100, 96), 'R': (80, 84)}

CAST = {
    'doctor': dict(
        male=True, pretty=True, skin=("#fdeee3", "#f3cdb8", "#e6ad98", "#c48270"), hair='soft_m',
        hair_g=("#9a6e52", "#6a4632", "#4a2f20"), hair_d="#4a2f20", hair_line="#2c1a10", hair_hl="#d8b08e", hair_len=660,
        iris=("#ffe6a8", "#e0a24a", "#a2601e", "#4e2a0c"),
        outfit='coat', top_g=("#8fd6c8", "#5fb8a8", "#3e8f80"), top_line="#2a6358", sleeve_fill='coatG',
        pants=True, bottom_g=("#7cc9ba", "#5fb8a8", "#3e8f80"), bottom_line="#2a6358",
        shoes=("#5a3a2a", "#2e1c12", None), mouth='open', pose=DOWN, accent="#3e8f80"),
    'head_nurse': dict(
        male=False, skin=SKIN_LIGHT, hair='bun', hair_g=("#7a6478", "#4a3a4c", "#2f2433"), hair_d="#2f2433",
        hair_line="#1e1622", hair_hl="#a894ac", hair_len=600, iris=("#d7e6f5", "#7d9cc2", "#3c5a85", "#22344f"),
        outfit='pencil', top_g=("#6a7cc0", "#3d4f8a", "#2a3866"), top_line="#1c2547", sleeve_fill='topG',
        bottom_g=("#4a5a96", "#33437a", "#222d58"), bottom_line="#1c2547", accent="#5a6db0",
        shoes=("#2a3460", "#141a36", None), mouth='stern', brow_tilt=-5, glasses="#7a3048", pose=DOWN),
    'patient': dict(
        male=True, skin=SKIN_LIGHT, hair='messy_m', hair_g=("#efdcbc", "#d2b48a", "#a8875e"), hair_d="#9a7a52",
        hair_line="#5e4426", hair_hl="#fff3dc", hair_len=640, iris=("#dcefff", "#7fb0dc", "#3f73a8", "#1f3d63"),
        outfit='gown', top_g=("#e4f0fb", "#c8def4", "#9dbfe2"), top_line="#5a7fa8", sleeve_fill='topG',
        shoes=("#e6e8ee", "#9aa0b0", None), mouth='nervous', sweat=True, wristband=True, pose=DOWN),
    'friend': dict(
        male=False, skin=SKIN_LIGHT, hair='bob', hair_g=("#6f7da0", "#3a4560", "#222a40"), hair_d="#222a40",
        hair_line="#141a2a", hair_hl="#aebde2", hair_len=700, iris=("#ffe08a", "#f3a640", "#c8621c", "#7a2f10"),
        outfit='scrub', top_g=("#e6dcfb", "#c9b6f0", "#a48bd6"), top_line="#6f56a8", sleeve_fill='topG',
        pants=True, bottom_g=("#d6c8f6", "#b9a2ea", "#9478cc"), bottom_line="#6f56a8", accent="#a48bd6",
        shoes=("#ffffff", "#8a8494", "#a48bd6"), mouth='open', lean=-2, contra=True,
        shoe_rot={'L': 6, 'R': 30}, pose={'L': (200, -84), 'R': (76, 54)}),
}

if __name__ == "__main__":
    sys.stdout.write(render(CAST[sys.argv[1]]))
