"""Unified character renderer for the nurse-animation cast.

render(name, view='front'|'q'|'side'|'back', turn=+1/-1, pose=..., expr=..., look=0, blink=1, t=0, bg='#ffffff'|None)
returns an SVG string 1080x1920.  turn=+1 means the character turns toward screen-right; -1 is the mirror.
"""
import math, re, sys
import draw2, draw3, cast
from draw2 import pt, f, quad, limb_layers, lock, strands, eye, happy_eye, LASH, ease
from draw3 import hand2, leg_path, _corners, fist
from cast import (bang_edge, crown_strands, FACE_F, FACE_M, FACE_P, ears, shoe, LEG_F, LEG_M, F_STRAIGHT,
                  M_STRAIGHT, TORSO_F, TORSO_F_LONG, TORSO_M, GOWN_M, vneck, neck, badge, stethoscope)

W, H = 1080, 1920
SC, TY = 0.9, 20
CL = 2.6
SQ = '<g transform="translate(540,0) scale(0.9,1) translate(-540,0)">'
SKIN_LIGHT = ("#fff0e6", "#f7cdbd", "#eeb3a2", "#c98774")

# ------------------------------------------------------------------ characters
CHARS = dict(cast.CAST)
CHARS['nurse'] = dict(
    male=False, skin=SKIN_LIGHT, hair='long', hair_g=("#fdeaae", "#f2c96c", "#d9a24c"), hair_d="#cf9840",
    hair_line="#8f5e22", hair_hl="#fff8dc", hair_len=940, iris=("#c9f5d8", "#5fc49a", "#2b8068", "#174a40"),
    outfit='nurse', top_g=("#ffd9e3", "#f8bccd", "#de8ba5"), top_line="#a8546f", sleeve_fill='topG',
    accent="#de8ba5", mouth='open', lean=-2, cap=True)
CHARS['gent'] = dict(
    male=True, pretty=True, skin=SKIN_LIGHT, hair='soft_m', hair_g=("#fdeaae", "#f2c96c", "#d9a24c"), hair_d="#cf9840",
    hair_line="#8f5e22", hair_hl="#fff8dc", hair_len=660, iris=("#c9f5d8", "#5fc49a", "#2b8068", "#174a40"),
    outfit='suit', top_g=("#ffffff", "#f4f5f9", "#d9dce6"), top_line="#8a8fa0", sleeve_fill='coatG',
    coat_g=("#3a4670", "#252f52", "#161d38"), coat_line="#0d1226", coat_crease="#4a5682",
    vest="#2a3458", lapel=("#46538a", "#2c375e"), tie=("#f0cf7e", "#c9973c"), cuffs="#e2b65a",
    pants=True, bottom_g=("#2e3960", "#222b4c", "#151b33"), bottom_line="#0d1226",
    shoes=("#1d1d26", "#07070c", None), mouth='open', pose={'L': (100, 96), 'R': (80, 84)}, accent="#e2b65a")
DEFAULT_EXPR = {'gent': 'smile', 'nurse': 'smile', 'doctor': 'smile', 'head_nurse': 'stern', 'friend': 'smile', 'patient': 'nervous'}

# ------------------------------------------------------------------ expressions
# eyes: open | happy | closed ; op = lid opening ; es = eye scale ; brow: (raise, inner_up, left_extra)
EXPR = {
    'smile':    dict(eyes='open', op=1.0, es=1.0, brow=(0, 0, 0), mouth=None),
    'happy':    dict(eyes='happy', brow=(-4, 0, 0), mouth='big'),
    'surprise': dict(eyes='open', op=1.0, es=1.2, brow=(-18, 0, 0), mouth='o'),
    'worry':    dict(eyes='open', op=1.0, es=1.0, brow=(-6, 12, 0), mouth='wavy', lid=(0.14, -8)),
    'smirk':    dict(eyes='open', op=1.0, es=1.0, brow=(0, 0, -10), mouth='smirk', lid=(0.4, 0)),
    'think':    dict(eyes='open', op=1.0, es=1.0, brow=(-3, 0, -11), mouth='flat', look=10, lid=(0.16, 0)),
    'stern':    dict(eyes='open', op=1.0, es=1.0, brow=(4, -10, 0), mouth='stern', lid=(0.36, 10)),
    'nervous':  dict(eyes='open', op=1.0, es=1.06, brow=(-6, 11, 0), mouth='wavy', sweat=True),
    'sad':      dict(eyes='open', op=1.0, es=1.0, brow=(-4, 13, 0), mouth='frown', lid=(0.3, -10)),
    'sleepy':   dict(eyes='closed', brow=(2, 0, 0), mouth='flat'),
}

# ------------------------------------------------------------------ poses  (a1, a2) per arm, hand type
POSES = {
    'down':    dict(L=(104, 86, 'open'), R=(76, 94, 'open')),
    'wave':    dict(L=(200, -84, 'open', 'wave'), R=(76, 54, 'open')),
    'point':   dict(L=(186, 178, 'point'), R=(80, 84, 'open')),
    'pointUp': dict(L=(196, -70, 'point'), R=(80, 84, 'open')),
    'hip':     dict(L=(104, 86, 'open'), R=('ik', (716, 1010), -1, 'fist')),
    'handsUp': dict(L=(84, -70, 'open'), R=(96, -110, 'open')),
    'think':   dict(L=(104, 86, 'open'), R=('ik', (586, 712), -1, 'point')),
    'cheer':   dict(L=(206, -96, 'fist'), R=(-26, -84, 'fist')),
    'shrug':   dict(L=(118, 196, 'open'), R=(62, -16, 'open')),
}


def ik(S, T, L1, L2, bend):
    dx, dy = T[0] - S[0], T[1] - S[1]
    d = min(math.hypot(dx, dy), L1 + L2 - 1)
    base = math.degrees(math.atan2(dy, dx))
    c = (L1 * L1 + d * d - L2 * L2) / (2 * L1 * d)
    a = math.degrees(math.acos(max(-1, min(1, c))))
    a1 = base + bend * a
    E = pt(S, a1, L1)
    a2 = math.degrees(math.atan2(T[1] - E[1], T[0] - E[0]))
    return a1, a2


# ------------------------------------------------------------------ 3/4 turn warp
NUM = r'-?\d+(?:\.\d+)?'


def sphere(phi, R, cx=540, ramp=None, falloff=0.5):
    def fn(x, y=None):
        u = (x - cx) / R
        if u <= -1 or u >= 1:
            return x
        th = math.asin(u)
        g = max(math.cos(th), 0.0) ** falloff
        dx = (R * math.sin(th + phi) - R * math.sin(th)) * g
        if ramp and y is not None:
            dx *= max(0.0, min(1.0, (y - ramp[0]) / (ramp[1] - ramp[0])))
        return x + dx
    return fn


def warp_path(d, fn):
    toks = re.findall(r'[A-Za-z]|' + NUM, d)
    out, cmd, buf = [], None, []
    for tk in toks:
        if tk.isalpha():
            cmd = tk; out.append(tk); buf = []
            continue
        v = float(tk)
        if cmd in 'MLCQTS':
            buf.append(v)
            if len(buf) == 2:
                out.append(f(fn(buf[0], buf[1]))); out.append(f(buf[1])); buf = []
        elif cmd == 'H':
            out.append(f(fn(v)))
        else:
            out.append(tk)
    return " ".join(out)


def warp_svg(s, fn):
    s = re.sub(r' d="([^"]*)"', lambda m: f' d="{warp_path(m.group(1), fn)}"', s)
    s = re.sub(r' (cx|x|x1|x2)="(' + NUM + ')"', lambda m: f' {m.group(1)}="{f(fn(float(m.group(2))))}"', s)

    def tr(m):
        full = m.group(0)
        if 'translate(-' in full:
            return full
        return re.sub(r'translate\((' + NUM + ')', lambda k: f'translate({f(fn(float(k.group(1))))}', full, count=1)
    s = re.sub(r'transform="[^"]*"', tr, s)
    return s


# ------------------------------------------------------------------ defs
def defs(C):
    base = cast.defs(C)
    hl, h, hd = C['hair_g']
    t0, t1, t2 = C['top_g']
    extra = (f'<linearGradient id="hairG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{hl}"/>'
             f'<stop offset="0.4" stop-color="{h}"/><stop offset="1" stop-color="{hd}"/></linearGradient>'
             f'<linearGradient id="scrubG" gradientUnits="userSpaceOnUse" x1="300" y1="0" x2="780" y2="0">'
             f'<stop offset="0" stop-color="{t0}"/><stop offset="0.65" stop-color="{t1}"/><stop offset="1" stop-color="{t2}"/></linearGradient>'
             '<linearGradient id="capG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#e9e8f2"/></linearGradient>')
    return base.replace('</defs>', extra + '</defs>')


def set_skin(C):
    for mod in (draw2, draw3, cast):
        if hasattr(mod, 'SKIN'):
            mod.SKIN, mod.SKIN_SH, mod.SKIN_SH2, mod.SKIN_LINE = C['skin']


# ------------------------------------------------------------------ hair (front)
NURSE_BANGS = draw3.BANGS


def hair_front(C):
    """(back_svg, sidelocks_svg, bangs_svg) for front/3-4 views, head-local coords."""
    if C['hair'] != 'long':
        back, front = cast.hair_parts(C)
        return back, "", front
    L = C['hair_line']; HL = C['hair_hl']; HD = C['hair_d']
    back = ("M 420 260 C 350 380 334 540 326 670 C 318 770 302 840 280 896 C 312 884 336 896 356 916 "
            "C 380 896 404 906 426 922 L 654 922 C 676 906 700 896 724 916 C 744 896 768 884 800 896 "
            "C 778 840 762 770 754 670 C 746 540 730 380 660 260 Z")
    b = [f'<path d="{back}" fill="url(#hairU)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>']
    ls = []
    for i in range(14):
        xx = 360 + i * 26; side = -1 if xx < 540 else 1
        ls.append((xx + side * 6, 560, xx + side * 4, 740, xx + side * 10, 900))
    b.append(strands(ls, HD, 1.6, 0.5))
    b.append(strands([(330, 700, 306, 800, 288, 890), (750, 700, 774, 800, 792, 890),
                      (352, 760, 340, 840, 336, 910), (728, 760, 740, 840, 744, 910)], HD, 1.5, 0.6))
    b.append('<ellipse cx="540" cy="640" rx="110" ry="90" fill="#8a5a1c" opacity="0.45" filter="url(#b14)"/>')
    side = []
    for d_ in (lock(426, 384, 366, 770, 44, -30), lock(426, 380, 412, 690, 22, -8)):
        side.append(f'<path d="{d_}" fill="url(#hairU)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>')
    side.append(strands([(412, 400, 400, 560, 388, 740), (420, 420, 410, 560, 400, 700)], HD, 1.4, 0.6))
    for d_ in (lock(654, 384, 714, 770, 44, 30), lock(654, 380, 668, 690, 22, 8)):
        side.append(f'<path d="{d_}" fill="url(#hairU)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>')
    side.append(strands([(668, 400, 680, 560, 692, 740), (660, 420, 670, 560, 680, 700)], HD, 1.4, 0.6))
    dd = bang_edge((394, 470), (686, 470), NURSE_BANGS)
    fr = [f'<clipPath id="bangC"><path d="{dd}"/></clipPath><path d="{dd}" fill="url(#hairG)"/><g clip-path="url(#bangC)">',
          f'<path d="M 420 312 C 460 268 620 268 662 312 L 664 330 C 650 318 640 336 626 320 C 612 336 598 314 584 328 '
          f'C 568 312 556 332 540 316 C 524 332 512 312 496 328 C 482 314 470 336 456 320 C 444 336 430 318 418 332 Z" '
          f'fill="{HL}" opacity="0.55" filter="url(#b3)"/>']
    fl = []
    for (nx_, ny_, tx, ty, lean) in NURSE_BANGS:
        rx_ = 540 + (tx - 540) * 0.75; ry_ = 230 + ((tx - 540) / 130) ** 2 * 60
        fl.append((f(rx_), f(ry_), f((rx_ + tx) / 2 + lean), f((ry_ + ty) / 2), f(tx), f(ty - 6)))
        fl.append((f(rx_ - 8), f(ry_ + 8), f((rx_ + tx) / 2 - 6 + lean), f((ry_ + ty) / 2 + 6), f(tx - 8), f(ty - 30)))
        fl.append((f(rx_ + 8), f(ry_ + 8), f((rx_ + tx) / 2 + 8 + lean), f((ry_ + ty) / 2 + 6), f(tx + 8), f(ty - 34)))
    fr.append(strands(fl, HD, 1.3, 0.55))
    fr.append(f'<path d="M 400 470 C 396 420 416 380 436 360 L 436 474 Z" fill="{HD}" opacity="0.35" filter="url(#b8)"/>'
              f'<path d="M 680 470 C 684 420 664 380 644 360 L 644 474 Z" fill="{HD}" opacity="0.35" filter="url(#b8)"/></g>')
    fr.append(f'<path d="{dd}" fill="none" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>')
    for d_ in (lock(498, 360, 486, 492, 9, -6), lock(588, 356, 604, 486, 8, 6), lock(548, 350, 544, 470, 6, 3)):
        fr.append(f'<path d="{d_}" fill="url(#hairG)" stroke="{L}" stroke-width="1.8" stroke-linejoin="round"/>')
    return "".join(b), "".join(side), "".join(fr)


def nurse_cap(back=False):
    o = ['<g transform="translate(540,252) rotate(-4) scale(1.05)">',
         '<path d="M -96 14 L -78 -42 Q 0 -58 78 -42 L 96 14 Q 0 0 -96 14 Z" fill="url(#capG)" stroke="#8a8494" stroke-width="2.6" stroke-linejoin="round"/>',
         '<path d="M -78 -42 Q 0 -58 78 -42 L 70 -24 Q 0 -38 -70 -24 Z" fill="#ffffff" stroke="#8a8494" stroke-width="2" stroke-linejoin="round"/>',
         '<path d="M -90 8 Q 0 -6 90 8" fill="none" stroke="#de8ba5" stroke-width="6"/>']
    if not back:
        o.append('<path d="M 0 -14 C -4 -24 -18 -22 -16 -12 C -14 -4 -4 2 0 6 C 4 2 14 -4 16 -12 C 18 -22 4 -24 0 -14 Z" fill="#de8ba5"/>')
    o.append('<path d="M -60 -6 L -54 -36" stroke="#d8d6e2" stroke-width="2"/><path d="M 60 -6 L 54 -36" stroke="#d8d6e2" stroke-width="2"/></g>')
    return "".join(o)


# ------------------------------------------------------------------ face (front / 3-4)
def mouth_svg(shape, my):
    if shape in ('open', 'big'):
        d, w = (10, 14) if shape == 'open' else (22, 19)
        mp = (f"M {540 - w} {my} Q 540 {my + 4} {540 + w} {my} C {540 + w * 0.8} {my + d * 0.8:.0f} {540 + w * 0.35:.0f} {my + d} 540 {my + d} "
              f"C {540 - w * 0.35:.0f} {my + d} {540 - w * 0.8:.0f} {my + d * 0.8:.0f} {540 - w} {my} Z")
        return (f'<path d="{mp}" fill="#a3354b" stroke="#7a2236" stroke-width="2.2" stroke-linejoin="round"/>'
                f'<ellipse cx="540" cy="{my + d - 3 - (2 if shape == "big" else 0)}" rx="{8 if shape == "open" else 11}" ry="{4 if shape == "open" else 6}" fill="#f2899a"/>')
    if shape == 'smile':
        return f'<path d="M 524 {my} Q 540 {my + 10} 558 {my - 2}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>'
    if shape == 'stern':
        return f'<path d="M 528 {my + 2} Q 540 {my - 1} 552 {my + 2}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>'
    if shape == 'wavy':
        return (f'<path d="M 520 {my + 2} Q 528 {my - 4} 536 {my + 2} Q 544 {my + 8} 552 {my + 1} Q 558 {my - 3} 562 {my}" '
                f'fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>')
    if shape == 'o':
        return (f'<ellipse cx="540" cy="{my + 8}" rx="8" ry="10" fill="#a3354b" stroke="#7a2236" stroke-width="2.2"/>'
                f'<ellipse cx="540" cy="{my + 13}" rx="4.5" ry="3" fill="#f2899a"/>')
    if shape == 'smirk':
        return f'<path d="M 526 {my + 3} Q 544 {my + 7} 558 {my - 6}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>'
    if shape == 'flat':
        return f'<path d="M 530 {my + 3} L 552 {my + 2}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>'
    if shape == 'frown':
        return f'<path d="M 527 {my + 7} Q 540 {my - 2} 553 {my + 7}" fill="none" stroke="#8a3a44" stroke-width="3" stroke-linecap="round"/>'
    return ''


def sweat_svg(x=690, y=360):
    return (f'<path d="M {x} {y} C {x - 14} {y + 32} {x - 10} {y + 50} {x + 4} {y + 50} C {x + 18} {y + 50} {x + 22} {y + 32} {x} {y} Z" '
            f'fill="#bfe4ff" stroke="#6aa6d6" stroke-width="2.5"/><ellipse cx="{x}" cy="{y + 38}" rx="4" ry="6" fill="#ffffff"/>')


def eyelid(cx, cy, s, L, slant, sk):
    xi, xo = cx - s * 42, cx + s * 50
    yt = cy - 42 + 58 * L
    yi, yo = yt + max(slant, 0) * 1.0 + min(slant, 0) * -0.2, yt - max(slant, 0) * 0.3 - min(slant, 0) * 1.0
    top = min(yi, yo) - 6
    ylim = cy - 50
    return (f'<path d="M {f(xi)} {ylim} Q {cx} {ylim - 8} {f(xo)} {ylim} L {f(xo)} {f(yo)} Q {cx} {f(top)} {f(xi)} {f(yi)} Z" fill="{sk}"/>'
            f'<path d="M {f(xi)} {f(yi)} Q {cx} {f(top)} {f(xo)} {f(yo)}" fill="none" stroke="{LASH}" stroke-width="7" stroke-linecap="round"/>'
            f'<path d="M {f(xo)} {f(yo)} L {f(xo + s * 10)} {f(yo - 6)}" stroke="{LASH}" stroke-width="4" stroke-linecap="round"/>')


def face_features(C, E, look, blink):
    male = C['male']; pretty = C.get('pretty')
    sk, sksh, sksh2, skl = C['skin']
    o = []
    # blush
    if not male:
        op = 0.42 if C['hair'] == 'long' else 0.4
        o.append(f'<ellipse cx="466" cy="530" rx="36" ry="16" fill="#ff8c9e" opacity="{op}" filter="url(#b8)"/>'
                 f'<ellipse cx="614" cy="530" rx="36" ry="16" fill="#ff8c9e" opacity="{op}" filter="url(#b8)"/>')
    elif pretty:
        o.append('<ellipse cx="468" cy="532" rx="32" ry="13" fill="#ff8c9e" opacity="0.26" filter="url(#b8)"/>'
                 '<ellipse cx="612" cy="532" rx="32" ry="13" fill="#ff8c9e" opacity="0.26" filter="url(#b8)"/>')
    else:
        o.append('<ellipse cx="470" cy="534" rx="30" ry="12" fill="#f0a090" opacity="0.18" filter="url(#b8)"/>'
                 '<ellipse cx="610" cy="534" rx="30" ry="12" fill="#f0a090" opacity="0.18" filter="url(#b8)"/>')
    # eyes
    ex, ey = 64, 474
    sy = 0.9 if pretty else (0.74 if male else 1.0)
    sx = 1.02 if pretty else (0.9 if male else 1.08)
    syy = sy * (1.08 if not male else 1)
    es = E.get('es', 1.0)
    lk = look + E.get('look', 0)
    for (cx, s, uid) in ((540 - ex, -1, "L"), (540 + ex, 1, "R")):
        o.append(f'<g transform="translate({cx},{ey}) scale({sx * es:.3f},{syy * es:.3f}) translate({-cx},{-ey})">')
        if E['eyes'] == 'happy':
            o.append(happy_eye(cx, ey, s))
        elif E['eyes'] == 'closed' or blink < 0.18:
            o.append(eye(cx, ey, s, 0.0, 0, uid))
        else:
            o.append(eye(cx, ey, s, max(0.2, E.get('op', 1.0) * blink), lk, uid))
            if E.get('lid') and blink > 0.6:
                o.append(eyelid(cx, ey, s, *E['lid'], sk))
        o.append('</g>')
    feats = "".join(o); o = []
    # brows
    bc = C['hair_d']
    raise_, inner, lextra = E['brow']
    bt = C.get('brow_tilt', 0)
    if male:
        bw = 4 if pretty else 6; yl, yi = 418, 410
        xs = (442, 474, 508, 572, 606, 638)
    else:
        bw = 2.8 if C['hair'] != 'long' else 2.6; yl, yi = 412, 408
        xs = (450, 476, 504, 576, 604, 630)
    lo = yl + raise_ - bt + lextra; li = yi + raise_ + bt - inner + lextra
    ro = yl + raise_ - bt; ri = yi + raise_ + bt - inner
    o.append(f'<path d="M {xs[0]} {lo} Q {xs[1]} {min(lo, li) - 8} {xs[2]} {li}" fill="none" stroke="{bc}" stroke-width="{bw}" stroke-linecap="round"/>'
             f'<path d="M {xs[3]} {ri} Q {xs[4]} {min(ro, ri) - 8} {xs[5]} {ro}" fill="none" stroke="{bc}" stroke-width="{bw}" stroke-linecap="round"/>')
    brows = "".join(o); o = [feats]
    # nose
    if male and not pretty:
        o.append(f'<path d="M 549 522 Q 552 536 551 541 Q 547 547 539 547" fill="none" stroke="{sksh2}" stroke-width="2.4" stroke-linecap="round"/>')
    else:
        o.append(f'<path d="M 544 530 Q 546 536 540 539" fill="none" stroke="{sksh2}" stroke-width="2.4" stroke-linecap="round"/>')
    # mouth
    my = 566 if pretty else (572 if male else 562)
    shape = E.get('mouth') or C['mouth']
    o.append(mouth_svg(shape, my))
    return "".join(o), brows


def head_front(C, E, look, blink, turn_phi):
    """returns (back_hair, head) svg in head-local coords."""
    male = C['male']; pretty = C.get('pretty')
    sk, sksh, sksh2, skl = C['skin']
    face = FACE_P if pretty else (FACE_M if male else FACE_F)
    back, sidelocks, bangs = hair_front(C)
    hw = sphere(turn_phi, 160) if turn_phi else None
    fw = sphere(turn_phi, 160, ramp=(420, 600)) if turn_phi else None
    W_ = (lambda s: warp_svg(s, hw)) if hw else (lambda s: s)
    face_d = warp_path(face, fw) if fw else face
    o = []
    if male and not pretty:
        o.append(W_(ears(C)))
    o.append(f'<clipPath id="faceC"><path d="{face_d}"/></clipPath>')
    o.append(f'<path d="{face_d}" fill="url(#skinG)" stroke="{skl}" stroke-width="{CL}"/>')
    tips = [(tx, ty) for (_, _, tx, ty, _) in (NURSE_BANGS if C['hair'] == 'long' else [])]
    if tips:
        sh = "M 400 300 L 680 300 L 680 " + f"{tips[-1][1] + 18:.0f} " + "".join(f"L {bx:.0f} {by + 16:.0f} " for bx, by in reversed(tips)) + f"L 400 {tips[0][1] + 18:.0f} Z"
        shade = f'<path d="{sh}" fill="{sksh}" opacity="0.85" filter="url(#b3)"/>'
    else:
        shade = f'<path d="M 400 300 L 680 300 L 680 450 Q 540 400 400 450 Z" fill="{sksh}" opacity="0.7" filter="url(#b8)"/>'
    side_shade = f'<path d="M 640 400 C 660 470 640 540 600 590 L 690 610 L 690 380 Z" fill="{sksh}" opacity="0.6" filter="url(#b8)"/>'
    if turn_phi:  # far cheek in shadow
        side_shade = f'<path d="M 630 380 C 666 470 650 560 600 610 L 700 620 L 700 360 Z" fill="{sksh}" opacity="0.75" filter="url(#b8)"/>'
    o.append(f'<g clip-path="url(#faceC)">{W_(shade)}{side_shade}</g>')
    if male and not pretty:
        o.append(f'<g clip-path="url(#faceC)"><path d="M 440 536 C 456 568 490 600 540 626 C 590 600 624 568 640 536 L 640 650 L 440 650 Z" '
                 f'fill="{sksh}" opacity="0.35" filter="url(#b8)"/></g>'
                 + W_(f'<path d="M 528 606 Q 540 612 552 606" fill="none" stroke="{sksh2}" stroke-width="2" stroke-linecap="round" opacity="0.7"/>'))
    feats, brows = face_features(C, E, look, blink)
    o.append(W_(feats))
    o.append(W_(sidelocks))
    o.append(W_(bangs))
    o.append(f'<g opacity="0.72">{W_(brows)}</g>')
    if C.get('glasses'):
        gc = C['glasses']
        o.append(W_(f'<g fill="none" stroke="{gc}" stroke-width="4">'
                    f'<path d="M 444 446 L 510 446 C 520 446 526 452 526 462 L 526 494 C 526 504 520 510 510 510 L 444 510 C 434 510 428 504 428 494 L 428 462 C 428 452 434 446 444 446 Z"/>'
                    f'<path d="M 570 446 L 636 446 C 646 446 652 452 652 462 L 652 494 C 652 504 646 510 636 510 L 570 510 C 560 510 554 504 554 494 L 554 462 C 554 452 560 446 570 446 Z"/>'
                    f'<path d="M 526 470 Q 540 462 554 470"/><path d="M 428 466 L 414 460 M 652 466 L 666 460"/></g>'
                    f'<path d="M 440 456 L 470 456" stroke="#ffffff" stroke-width="4" opacity="0.8" stroke-linecap="round"/>'
                    f'<path d="M 566 456 L 596 456" stroke="#ffffff" stroke-width="4" opacity="0.8" stroke-linecap="round"/>'))
    if C.get('cap'):
        o.append(W_(nurse_cap()))
    if E.get('sweat'):
        o.append(sweat_svg())
    return back, "".join(o)


# ------------------------------------------------------------------ arms & hands
def point_hand(x, y, ang, sc=1.0, skin=SKIN_LIGHT):
    sk, sksh, sksh2, skl = skin
    rot = ang + 90
    fist_body = "M -24 4 C -30 -14 -28 -40 -14 -48 L 18 -48 C 30 -42 32 -16 26 4 Q 0 12 -24 4 Z"
    index = draw3.finger2(58, 16)
    thumb = draw3.finger2(32, 17)
    sh = (f'<path d="{fist_body}"/><path d="{index}" transform="translate(12,-46) rotate(4)"/>'
          f'<path d="{thumb}" transform="translate(22,-18) rotate(62)"/>')
    return (f'<g transform="translate({f(x)},{f(y)}) rotate({rot:.2f}) translate(0,8) scale({sc})">'
            f'<g fill="{skl}" stroke="{skl}" stroke-width="4" stroke-linejoin="round">{sh}</g><g fill="{sk}">{sh}</g>'
            f'<path d="M -20 -40 Q -8 -36 4 -40 M -22 -28 Q -10 -24 2 -28 M -20 -16 Q -8 -12 4 -16" fill="none" stroke="{sksh2}" stroke-width="2" stroke-linecap="round"/>'
            f'<ellipse cx="12" cy="-98" rx="5" ry="4.5" fill="#ffb3bd" opacity="0.55"/></g>')


def hand_side(x, y, ang, sc, skin):
    sk, sksh, sksh2, skl = skin
    rot = ang - 90
    body = ("M -15 -6 C -20 14 -20 40 -12 60 C -6 74 8 78 16 68 C 22 56 20 30 16 8 C 14 0 12 -6 10 -8 Z")
    thumb = "M 12 6 C 22 12 26 26 22 38 C 18 44 12 40 12 32 Z"
    return (f'<g transform="translate({f(x)},{f(y)}) rotate({rot:.2f}) scale({sc})">'
            f'<path d="{body}" fill="{sk}" stroke="{skl}" stroke-width="3.5" stroke-linejoin="round"/>'
            f'<path d="{thumb}" fill="{sk}" stroke="{skl}" stroke-width="3" stroke-linejoin="round"/>'
            f'<path d="M -8 40 Q 0 44 8 40 M -6 52 Q 2 56 10 52" fill="none" stroke="{sksh2}" stroke-width="1.8" stroke-linecap="round"/>'
            f'<ellipse cx="6" cy="66" rx="5" ry="4" fill="#ffb3bd" opacity="0.5"/></g>')


def hand_back(x, y, ang, sc, skin):
    sk, sksh, sksh2, skl = skin
    rot = ang + 90
    F = [(-20, -44, 34, 15, -12), (-7, -48, 44, 16, -4), (7, -48, 47, 16.5, 3), (20, -44, 41, 16, 11)]
    TH = (24, -22, 34, 17, 46)
    palm = "M -26 0 C -32 -14 -33 -38 -28 -50 Q -14 -58 0 -58 Q 16 -58 28 -51 C 33 -38 32 -14 24 0 Q 0 8 -26 0 Z"
    shapes = [f'<path d="{draw3.finger2(L, w)}" transform="translate({bx},{by}) rotate({a})"/>' for bx, by, L, w, a in F + [TH]]
    shapes.append(f'<path d="{palm}"/>')
    sh = "".join(shapes)
    o = [f'<g transform="translate({f(x)},{f(y)}) rotate({rot:.2f}) translate(0,8) scale({-sc},{sc})">',
         f'<g fill="{skl}" stroke="{skl}" stroke-width="4" stroke-linejoin="round">{sh}</g><g fill="{sk}">{sh}</g>']
    for bx, by, L, w, a in F:
        o.append(f'<g transform="translate({bx},{by}) rotate({a})"><path d="M {-w * 0.28:.1f} {-L + w * 0.9:.1f} Q 0 {-L + w * 0.2:.1f} {w * 0.28:.1f} {-L + w * 0.9:.1f}" '
                 f'fill="#fff6f2" stroke="{sksh2}" stroke-width="1.2"/><path d="M -4 -2 Q 0 -6 4 -2" fill="none" stroke="{sksh2}" stroke-width="1.6"/></g>')
    o.append(f'<path d="M -16 -20 L -6 -44 M 0 -20 L 2 -46 M 14 -20 L 12 -44" stroke="{sksh}" stroke-width="2" opacity="0.6"/></g>')
    return "".join(o)


def resolve_arm(spec, S, male):
    L1, L2 = (196, 182) if male else (184, 172)
    if spec[0] == 'ik':
        _, T, bend, hand_t = spec[:4]
        a1, a2 = ik(S, T, L1, L2 * 0.98, bend)
        return a1, a2, hand_t, None
    a1, a2, hand_t = spec[:3]
    return a1, a2, hand_t, (spec[3] if len(spec) > 3 else None)


def draw_arm(C, S, spec, t, sleeve, handmode='front'):
    male = C['male']
    a1, a2, hand_t, anim = resolve_arm(spec, S, male)
    if anim == 'wave':
        a2 = a2 + 17 * math.sin(t * 2 * math.pi * 1.7)
    sk_, sl_, Hd = cast.arm(C, S, a1, a2, sleeve)
    hs = (1.18 if male else 1.0) * 1.02
    if handmode == 'side' and hand_t == 'open':
        hd = hand_side(Hd[0], Hd[1], a2, hs, C['skin'])
    elif handmode == 'back' and hand_t == 'open':
        hd = hand_back(Hd[0], Hd[1], a2, hs, C['skin'])
    elif hand_t == 'open':
        hd = hand2(Hd[0], Hd[1], a2, 4 + 2.5 * math.sin(t * 9) if anim == 'wave' else -2, hs)
    elif hand_t == 'fist':
        hd = fist(Hd[0], Hd[1], a2, 0.95 * hs)
    else:
        hd = point_hand(Hd[0], Hd[1], a2, 0.95 * hs, C['skin'])
    return sk_ + hd + sl_


# ------------------------------------------------------------------ body (front / 3-4)
def nurse_body_front(C, t, bw):
    sk, sksh, sksh2, skl = C['skin']
    SCRUB, SCRUB_D, SCRUB_LINE = C['top_g'][1], C['top_g'][2], C['top_line']
    torso = ("M 518 692 C 470 698 418 706 388 724 C 356 744 344 802 348 856 C 354 906 382 936 402 952 "
             "C 412 976 418 1014 420 1052 L 420 1084 L 660 1084 L 660 1052 C 662 1014 668 976 682 948 "
             "C 698 936 726 906 732 856 C 736 802 724 744 692 724 C 662 706 610 698 562 692 Z")
    o = [f'<clipPath id="torsoC"><path d="{torso}"/></clipPath>',
         f'<path d="{torso}" fill="url(#scrubG)" stroke="{SCRUB_LINE}" stroke-width="{CL + 1}"/>']
    inner = (f'<path d="M 386 922 Q 446 960 514 930" fill="none" stroke="{SCRUB_D}" stroke-width="14" opacity="0.65" filter="url(#b8)"/>'
             f'<path d="M 566 930 Q 634 960 694 922" fill="none" stroke="{SCRUB_D}" stroke-width="14" opacity="0.65" filter="url(#b8)"/>'
             f'<ellipse cx="448" cy="856" rx="50" ry="38" fill="#ffffff" opacity="0.42" filter="url(#b14)"/>'
             f'<ellipse cx="628" cy="850" rx="40" ry="30" fill="#ffffff" opacity="0.2" filter="url(#b14)"/>'
             f'<path d="M 452 934 C 460 980 462 1020 458 1080" fill="none" stroke="{SCRUB_D}" stroke-width="2.2" opacity="0.7"/>'
             f'<path d="M 628 934 C 620 980 618 1020 622 1080" fill="none" stroke="{SCRUB_D}" stroke-width="2.2" opacity="0.7"/>')
    o.append(f'<g clip-path="url(#torsoC)">{bw(inner)}'
             f'<path d="M 700 760 C 740 850 745 980 740 1100 L 800 1100 L 800 700 Z" fill="{SCRUB_D}" opacity="0.7" filter="url(#b8)"/>'
             f'<path d="M 428 1018 Q 540 1044 652 1018" fill="none" stroke="{SCRUB_D}" stroke-width="10" filter="url(#b8)" opacity="0.8"/>'
             f'<path d="M 356 870 C 372 940 402 1000 420 1044" fill="none" stroke="{SCRUB_D}" stroke-width="10" filter="url(#b8)" opacity="0.6"/></g>')
    o.append('<g transform="translate(0,66) rotate(3 540 990)">' + draw3.skirt(t) + '</g>')
    return "".join(o)


def nurse_chest_front(C, bw):
    sk, sksh, sksh2, skl = C['skin']
    SCRUB, SCRUB_D, SCRUB_LINE = C['top_g'][1], C['top_g'][2], C['top_line']
    o = [f'<g transform="translate({16 if getattr(bw, "turned", False) else 0},0)"><path d="M 518 584 L 516 702 Q 540 716 564 702 L 562 584 Z" fill="{sk}" stroke="{skl}" stroke-width="{CL}"/>'
         f'<path d="M 514 600 Q 540 660 566 600 L 566 640 Q 540 684 514 640 Z" fill="{sksh}"/></g>']
    v = (f'<path d="M 488 694 L 540 800 L 592 694 Q 540 712 488 694 Z" fill="{sk}" stroke="{skl}" stroke-width="2"/>'
         f'<path d="M 500 698 L 540 760 L 580 698" fill="none" stroke="{sksh}" stroke-width="8" filter="url(#b3)"/>'
         f'<path d="M 496 712 Q 512 718 530 714 M 584 712 Q 568 718 550 714" fill="none" stroke="{sksh2}" stroke-width="2.2" stroke-linecap="round"/>'
         f'<path d="M 538 722 Q 540 730 542 722" fill="none" stroke="{sksh2}" stroke-width="1.8" stroke-linecap="round" opacity="0.7"/>'
         f'<path d="M 478 690 L 540 812 L 602 690" fill="none" stroke="#ffffff" stroke-width="9" stroke-linejoin="round"/>'
         f'<path d="M 472 688 L 540 822 L 608 688" fill="none" stroke="{SCRUB_LINE}" stroke-width="2.2" stroke-linejoin="round"/>'
         f'<path d="M 484 692 L 540 802 L 596 692" fill="none" stroke="{SCRUB_LINE}" stroke-width="2.2" stroke-linejoin="round"/>'
         '<g transform="translate(0,-44)">'
         f'<path d="M 600 900 L 690 896 L 692 980 Q 646 990 602 982 Z" fill="{SCRUB}" stroke="{SCRUB_LINE}" stroke-width="2.4"/>'
         f'<path d="M 600 912 L 690 908" stroke="{SCRUB_LINE}" stroke-width="1.6" stroke-dasharray="5 4"/>'
         f'<rect x="618" y="862" width="9" height="46" rx="4" fill="#4a7bd6" stroke="#2c4f92" stroke-width="2"/>'
         f'<rect x="634" y="868" width="9" height="40" rx="4" fill="#f2f2f2" stroke="#8a8494" stroke-width="2"/>'
         f'<line x1="440" y1="850" x2="440" y2="880" stroke="#9aa0b0" stroke-width="3"/>'
         f'<rect x="402" y="878" width="78" height="96" rx="8" fill="#ffffff" stroke="#8a8494" stroke-width="2.4"/>'
         f'<rect x="402" y="878" width="78" height="22" rx="8" fill="{SCRUB_D}"/><rect x="402" y="890" width="78" height="10" fill="{SCRUB_D}"/>'
         f'<circle cx="441" cy="928" r="16" fill="#ffe1d3" stroke="#8a8494" stroke-width="1.6"/>'
         f'<rect x="416" y="952" width="50" height="5" rx="2" fill="#c3c6d0"/><rect x="422" y="962" width="38" height="4" rx="2" fill="#d6d8e0"/></g>'
         '<g transform="translate(0,700) scale(1,0.86) translate(0,-700)">'
         f'<path d="M 470 700 C 440 760 444 840 470 900" fill="none" stroke="#3b4668" stroke-width="11" stroke-linecap="round"/>'
         f'<path d="M 610 700 C 640 760 640 820 612 880 C 600 906 596 930 600 960" fill="none" stroke="#3b4668" stroke-width="11" stroke-linecap="round"/>'
         f'<circle cx="600" cy="978" r="22" fill="url(#metal)" stroke="#6b7284" stroke-width="2.4"/>'
         f'<circle cx="600" cy="978" r="12" fill="none" stroke="#8a91a3" stroke-width="2"/>'
         f'<circle cx="470" cy="906" r="9" fill="url(#metal)" stroke="#6b7284" stroke-width="2"/></g>')
    o.append(bw(v))
    return "".join(o)


def cast_body_front(C, bw):
    """cast.body() minus arms, with features warped by bw."""
    saved = C['pose']
    C2 = dict(C); C2['pose'] = {'L': (100, 96), 'R': (80, 84)}
    o, late = cast.body(C2)
    # strip the arms cast.body appended (last element of o and the arm part of late) by rebuilding without them
    return o, late


# ------------------------------------------------------------------ main render
def render(name, view='front', turn=1, pose=None, expr=None, look=0, blink=1.0, t=0.0, bg='#ffffff', hair_sway=True):
    C = dict(CHARS[name]); C['_name'] = name
    set_skin(C)
    expr = expr or DEFAULT_EXPR[name]
    E = EXPR[expr]
    pose = pose or ('wave' if name in ('nurse', 'friend') else 'down')
    P = POSES[pose]
    if view in ('side', 'back'):
        import views
        body = views.render_view(C, view, P, E, t, look, blink)
    else:
        body = front_body(C, P, E, t, look, blink, 0.6 if view == 'q' else 0.0)
    mir = '<g transform="translate(1080,0) scale(-1,1)">' if turn < 0 and view in ('q', 'side') else '<g>'
    bgr = f'<rect width="{W}" height="{H}" fill="{bg}"/>' if bg else ''
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">{defs(C)}{bgr}'
            f'{mir}<g transform="translate({540 * (1 - SC):.1f},{TY}) scale({SC})">{body}</g></g></svg>')


def front_body(C, P, E, t, look, blink, phi):
    male = C['male']; nurse = C['hair'] == 'long'
    sq, sqe = ('', '') if male else (SQ, '</g>')
    bob = 4 * math.sin(t * 2 * math.pi * 0.8)
    sway = 1.0 * math.sin(t * 2 * math.pi * 0.4)
    hair_sw = 1.8 * math.sin(t * 2 * math.pi * 0.8 - 0.9)
    lean = C.get('lean', 0)
    hy = 48 if male else 30
    tilt = (-4 if P['L'][0] in (200, 196, 206) else 0) + 1.2 * math.sin(t * 2 * math.pi * 0.8 + 0.6) + phi * 6
    bw = (lambda s: warp_svg(s, sphere(phi * 0.75, 220, falloff=3))) if phi else (lambda s: s)
    bw.turned = bool(phi)
    back, headsvg = head_front(C, E, look, blink, phi)
    S_L, S_R = ((384, 788), (696, 788)) if male else ((382, 744), (704, 744))
    if phi:
        S_R = (S_R[0] - 14, S_R[1])
    sleeve = 'long' if C['outfit'] in ('coat', 'suit') else 'short'
    armL = draw_arm(C, S_L, P['L'], t, sleeve)
    armR = draw_arm(C, S_R, P['R'], t, sleeve)
    o = []
    turnbody = (f'<g transform="translate({540 + 16 * (phi > 0)},0) scale({1 - 0.16 * (phi > 0)},1) translate(-540,0)">', '</g>')
    o.append(turnbody[0])
    # legs
    if nurse:
        o.append(SQ + draw3.legs() + '</g>')
    o.append(f'<g transform="translate(0,{bob:.2f}) rotate({sway + lean:.2f} 540 1000)">')
    bh = f'translate(540,0) scale({1 - 0.14 * (phi > 0)},1) translate(-540,0)'
    o.append(f'<g transform="translate({30 * (phi > 0)},{hy}) rotate({tilt * 0.6 + hair_sw * 0.6:.2f} 540 560) {bh}">{back}</g>')
    if not nurse:
        o.append(sq + cast.legs(C) + sqe)
    # body
    o.append(sq)
    r_front = P['R'][0] == 'ik' or (P['R'][1] < 0)
    if nurse:
        o.append(nurse_body_front(C, t, bw))
        if not r_front: o.append(armR)
        o.append(nurse_chest_front(C, bw))
        late = ''
    else:
        C2 = dict(C); C2['pose'] = {'L': (100, 96), 'R': (80, 84)}
        bod, late = body_no_arms(C2)
        o.append(bw(bod))
        if not r_front: o.append(armR)
        late = bw(late)
    o.append(sqe)
    # head
    unturn = f'translate(540,0) scale({1 / (1 - 0.16 * (phi > 0)):.4f},1) translate({-540 - 16 * (phi > 0)},0)'
    o.append(f'<g transform="{unturn}"><g transform="translate({14 * phi:.1f},{hy}) rotate({tilt:.2f} 540 620)">{headsvg}</g></g>')
    o.append(sq + late + armL + (armR if r_front else '') + sqe)
    o.append('</g>')
    o.append(turnbody[1])
    return "".join(o)


def body_no_arms(C):
    """cast.body without arms."""
    real_arm = cast.arm
    cast.arm = lambda *a, **k: ("", "", (0, 0))
    real_hand = cast.hand2
    cast.hand2 = lambda *a, **k: ""
    try:
        return cast.body(C)
    finally:
        cast.arm = real_arm; cast.hand2 = real_hand


if __name__ == "__main__":
    a = sys.argv[1:]
    kw = {}
    for item in a[1:]:
        k, v = item.split('=')
        kw[k] = float(v) if k in ('turn', 'look', 'blink', 't') else v
    sys.stdout.write(render(a[0], **kw))
