import math, sys, random
from draw2 import (ease, back_out, pt, f, quad, limb_layers, hand, lock, strands, eye, happy_eye,
                   SKIN, SKIN_SH, SKIN_SH2, SKIN_LINE, LASH)

W, H = 1080, 1920
SC = 0.95
HAIR_L = "#fdeaae"; HAIR = "#f2c96c"; HAIR_D = "#cf9840"; HAIR_LINE = "#8f5e22"; HAIR_HL = "#fff8dc"
SCRUB = "#f8bccd"; SCRUB_L = "#ffd9e3"; SCRUB_D = "#de8ba5"; SCRUB_LINE = "#a8546f"
WHITE_LINE = "#8a8494"
TUBE = "#3b4668"; TUBE_L = "#5f6c96"
CL = 2.6  # line weight

DEFS = f'''<defs>
<filter id="b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
<filter id="b14" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14"/></filter>
<filter id="b8" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8"/></filter>
<linearGradient id="hairG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="{HAIR_L}"/><stop offset="0.4" stop-color="{HAIR}"/><stop offset="1" stop-color="#dba550"/></linearGradient>
<linearGradient id="hairU" gradientUnits="userSpaceOnUse" x1="0" y1="220" x2="0" y2="940">
 <stop offset="0" stop-color="{HAIR_L}"/><stop offset="0.3" stop-color="{HAIR}"/><stop offset="1" stop-color="#d9a24c"/></linearGradient>
<linearGradient id="hairBackG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="{HAIR_D}"/><stop offset="0.5" stop-color="{HAIR}"/><stop offset="1" stop-color="{HAIR_L}"/></linearGradient>
<radialGradient id="irisG" cx="0.5" cy="0.72" r="0.75">
 <stop offset="0" stop-color="#c9f5d8"/><stop offset="0.35" stop-color="#5fc49a"/>
 <stop offset="0.75" stop-color="#2b8068"/><stop offset="1" stop-color="#174a40"/></radialGradient>
<linearGradient id="irisTop" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#0c2a24" stop-opacity="0.95"/><stop offset="0.5" stop-color="#0c2a24" stop-opacity="0.15"/>
 <stop offset="0.6" stop-color="#0c2a24" stop-opacity="0"/></linearGradient>
<linearGradient id="scleraG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#d9cfe0"/><stop offset="0.35" stop-color="#ffffff"/></linearGradient>
<linearGradient id="scrubG" gradientUnits="userSpaceOnUse" x1="300" y1="0" x2="780" y2="0">
 <stop offset="0" stop-color="{SCRUB_L}"/><stop offset="0.65" stop-color="{SCRUB}"/><stop offset="1" stop-color="{SCRUB_D}"/></linearGradient>
<linearGradient id="skinG" x1="0" y1="0" x2="1" y2="0">
 <stop offset="0" stop-color="{SKIN}"/><stop offset="0.72" stop-color="{SKIN}"/><stop offset="1" stop-color="#fbdccd"/></linearGradient>
<linearGradient id="capG" x1="0" y1="0" x2="0" y2="1">
 <stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#e9e8f2"/></linearGradient>
<radialGradient id="metal" cx="0.35" cy="0.35" r="0.8">
 <stop offset="0" stop-color="#ffffff"/><stop offset="0.5" stop-color="#c9ced9"/><stop offset="1" stop-color="#7d8496"/></radialGradient>
</defs>'''

rng = random.Random(7)
BANG_TIPS = []
x = 418
while x < 664:
    BANG_TIPS.append((x, 436 + rng.uniform(-10, 12) + (10 if abs(x - 540) > 90 else 0)))
    x += rng.uniform(20, 28)
BANGS = [  # notch x,y -> tip x,y, lean
    (414, 380, 428, 456, -8), (446, 350, 466, 436, -6), (486, 340, 506, 450, -3),
    (522, 336, 540, 462, 0), (560, 338, 576, 446, 4), (596, 344, 614, 432, 6), (632, 360, 652, 452, 9)]
BANG_TIPS = [(tx, ty) for (_, _, tx, ty, _) in BANGS]
STRAND_SEED = [(rng.uniform(-1, 1), rng.uniform(0.85, 1.0)) for _ in range(80)]


def finger2(L, w):
    h = w / 2
    return (f"M {-h:.1f} 4 C {-h:.1f} {-L*0.45:.1f} {-h*0.9:.1f} {-L*0.75:.1f} {-h*0.82:.1f} {-L+h:.1f} "
            f"C {-h*0.8:.1f} {-L-1:.1f} {h*0.8:.1f} {-L-1:.1f} {h*0.82:.1f} {-L+h:.1f} "
            f"C {h*0.9:.1f} {-L*0.75:.1f} {h:.1f} {-L*0.45:.1f} {h:.1f} 4 Z")


def hand2(x, y, ang, spread, sc=1.02):
    rot = ang + 90
    F = [(-20, -44, 34, 15, -12 - spread), (-7, -48, 44, 16, -4 - spread * 0.4),
         (7, -48, 47, 16.5, 3 + spread * 0.3), (20, -44, 41, 16, 11 + spread)]
    TH = (24, -22, 34, 17, 46 + spread * 0.7)
    palm = "M -26 0 C -32 -14 -33 -38 -28 -50 Q -14 -58 0 -58 Q 16 -58 28 -51 C 33 -38 32 -14 24 0 Q 0 8 -26 0 Z"
    shapes = []
    for bx, by, L, w, a in F + [TH]:
        shapes.append(f'<path d="{finger2(L, w)}" transform="translate({bx},{by}) rotate({a:.2f})"/>')
    shapes.append(f'<path d="{palm}"/>')
    sh = "".join(shapes)
    o = [f'<g transform="translate({f(x)},{f(y)}) rotate({rot:.2f}) translate(0,8) scale({sc})">']
    o.append(f'<g fill="{SKIN_LINE}" stroke="{SKIN_LINE}" stroke-width="4" stroke-linejoin="round">{sh}</g>')
    o.append(f'<g fill="{SKIN}">{sh}</g>')
    # soft pink fingertips + palm blush (no wrinkles)
    for bx, by, L, w, a in F + [TH]:
        o.append(f'<g transform="translate({bx},{by}) rotate({a:.2f})">'
                 f'<ellipse cx="0" cy="{-L + w * 0.55:.1f}" rx="{w * 0.32:.1f}" ry="{w * 0.3:.1f}" fill="#ffb3bd" opacity="0.55"/></g>')
    for (bx, by, L, w, a) in F[:3]:
        o.append(f'<g transform="translate({bx},{by}) rotate({a:.2f})"><path d="M {w/2:.1f} -8 L {w/2:.1f} {-L*0.25:.1f}" stroke="{SKIN_SH2}" stroke-width="1.5" stroke-linecap="round" opacity="0.8"/></g>')
    o.append('<ellipse cx="0" cy="-26" rx="14" ry="10" fill="#ffb3bd" opacity="0.18"/>')
    o.append(f'<path d="M -26 0 C -32 -14 -33 -38 -28 -50 Q -22 -32 -20 -6 Q -22 0 -26 0 Z" fill="{SKIN_SH}" opacity="0.6"/>')
    o.append('</g>')
    return "".join(o)


def fist(x, y, ang, sc=1.0):
    rot = ang - 90
    o = [f'<g transform="translate({f(x)},{f(y)}) rotate({rot:.2f}) scale({sc})">']
    body = "M -24 -6 C -28 18 -22 40 -4 46 C 14 50 28 40 30 22 C 32 6 26 -6 20 -8 Z"
    o.append(f'<path d="{body}" fill="{SKIN}" stroke="{SKIN_LINE}" stroke-width="3.5" stroke-linejoin="round"/>')
    for k in range(3):
        yy = 14 + k * 10
        o.append(f'<path d="M -24 {yy} Q -12 {yy + 4} -2 {yy + 1}" fill="none" stroke="{SKIN_LINE}" stroke-width="2" stroke-linecap="round"/>')
    o.append(f'<path d="M 6 -2 C 14 6 16 18 10 26" fill="none" stroke="{SKIN_LINE}" stroke-width="2.4" stroke-linecap="round"/>')
    o.append('</g>')
    return "".join(o)


def _corners(p0, p1, w0, w1):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]; L = math.hypot(dx, dy) or 1
    nx, ny = -dy / L, dx / L
    return ((p0[0] + nx * w0, p0[1] + ny * w0), (p1[0] + nx * w1, p1[1] + ny * w1),
            (p1[0] - nx * w1, p1[1] - ny * w1), (p0[0] - nx * w0, p0[1] - ny * w0)), (dx / L, dy / L)


def arm(S, a1, a2, L2=172, L1=184):
    E = pt(S, a1, L1)
    M = pt(E, a2, L2 * 0.32)
    Hd = pt(E, a2, L2 * 0.98)
    Wr = pt(E, a2, L2 * 0.80)
    skin = [('q', quad(S, E, 31, 21)), ('c', E[0], E[1], 21), ('q', quad(E, M, 21, 23)),
            ('c', M[0], M[1], 23), ('q', quad(M, Hd, 23, 12))]
    o = [limb_layers(skin, SKIN, SKIN_LINE, 3.5)]
    o.append(f'<path d="M {f(E[0])} {f(E[1])} L {f(Wr[0])} {f(Wr[1])}" stroke="{SKIN_SH}" stroke-width="9" '
             f'opacity="0.55" filter="url(#b3)"/>')
    # elbow crease
    o.append(f'<g transform="translate({f(E[0])},{f(E[1])}) rotate({a2:.1f})">'
             f'<path d="M -2 -14 Q 6 -10 8 -4" fill="none" stroke="{SKIN_LINE}" stroke-width="2" stroke-linecap="round" opacity="0.7"/></g>')
    # tapered sleeve: no balloon cap, open hem
    S0 = pt(S, a1, -22)
    SE = pt(S, a1, L1 * 0.52)
    (c0, c1, c2, c3), (ux, uy) = _corners(S0, SE, 43, 34)
    hem_c = (SE[0] + ux * 9, SE[1] + uy * 9)
    body = (f"M {f(c0[0])} {f(c0[1])} L {f(c1[0])} {f(c1[1])} Q {f(hem_c[0])} {f(hem_c[1])} {f(c2[0])} {f(c2[1])} "
            f"L {f(c3[0])} {f(c3[1])} Z")
    sl = [f'<path d="{body}" fill="url(#scrubG)"/>']
    (d0, _, _, d3), _ = _corners(S, SE, 41, 34)
    sl.append(f'<path d="M {f(d0[0])} {f(d0[1])} L {f(c1[0])} {f(c1[1])} Q {f(hem_c[0])} {f(hem_c[1])} {f(c2[0])} {f(c2[1])} '
              f'L {f(d3[0])} {f(d3[1])}" fill="none" stroke="{SCRUB_LINE}" stroke-width="3" stroke-linejoin="round"/>')
    # inner opening + trim + fold
    tr = pt(S, a1, L1 * 0.47)
    sl.append(f'<g transform="translate({f(tr[0])},{f(tr[1])}) rotate({a1 + 90:.1f})">'
              f'<path d="M -34 0 Q 0 6 34 0" fill="none" stroke="#ffffff" stroke-width="3" opacity="0.9"/>'
              f'<path d="M 14 -60 Q 8 -36 18 -18" fill="none" stroke="{SCRUB_D}" stroke-width="2.4" stroke-linecap="round"/>'
              f'<path d="M -16 -50 Q -10 -30 -18 -14" fill="none" stroke="{SCRUB_D}" stroke-width="2" stroke-linecap="round" opacity="0.8"/></g>')
    return "".join(o), "".join(sl), Hd


PANT = "#e7899f"; PANT_D = "#c9667f"


def smooth(pts):
    """Catmull-Rom through pts -> cubic path segments (no initial M)."""
    d = ""
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i > 0 else pts[i]
        p1, p2 = pts[i], pts[i + 1]
        p3 = pts[i + 2] if i + 2 < len(pts) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d += f"C {f(c1[0])} {f(c1[1])} {f(c2[0])} {f(c2[1])} {f(p2[0])} {f(p2[1])} "
    return d


def leg_path(cl, ws):
    left, right = [], []
    for i, (p, w) in enumerate(zip(cl, ws)):
        q0 = cl[max(i - 1, 0)]; q1 = cl[min(i + 1, len(cl) - 1)]
        dx, dy = q1[0] - q0[0], q1[1] - q0[1]; L = math.hypot(dx, dy) or 1
        nx, ny = -dy / L, dx / L
        left.append((p[0] - nx * w, p[1] - ny * w)); right.append((p[0] + nx * w, p[1] + ny * w))
    end = cl[-1]; prev = cl[-2]
    dx, dy = end[0] - prev[0], end[1] - prev[1]; L = math.hypot(dx, dy)
    tip = (end[0] + dx / L * ws[-1] * 1.1, end[1] + dy / L * ws[-1] * 1.1)
    d = f"M {f(left[0][0])} {f(left[0][1])} " + smooth(left)
    d += f"Q {f(tip[0])} {f(tip[1])} {f(right[-1][0])} {f(right[-1][1])} " + smooth(right[::-1]) + "Z"
    return d


def shoe2(x, y, flip, rot):
    return (f'<g transform="translate({f(x)},{f(y)}) scale({flip},1) rotate({rot})">'
            f'<path d="M -20 28 L -18 42 L -5 42 L -3 30 Z" fill="#e2e0ea" stroke="{WHITE_LINE}" stroke-width="2.5" stroke-linejoin="round"/>'
            f'<path d="M -22 -8 C -28 8 -26 24 -16 30 L 34 30 C 54 31 62 20 56 8 C 50 -4 26 -9 -22 -8 Z" fill="#ffffff" '
            f'stroke="{WHITE_LINE}" stroke-width="3" stroke-linejoin="round"/>'
            f'<path d="M -16 30 L 34 30 C 50 30 58 24 58 16" fill="none" stroke="#c9c6d4" stroke-width="3"/>'
            f'<path d="M -18 -2 Q 2 -12 22 -10" fill="none" stroke="{SCRUB_D}" stroke-width="5" stroke-linecap="round"/>'
            f'<circle cx="22" cy="-10" r="5" fill="{SCRUB_D}"/>'
            f'<ellipse cx="34" cy="10" rx="12" ry="5" fill="#ffffff" opacity="0.9"/>'
            f'<path d="M 30 18 Q 44 20 52 12" fill="none" stroke="#e6e4ee" stroke-width="3"/></g>')


LEGS = {
    'L': dict(cl=[(500, 1040), (497, 1250), (494, 1415), (492, 1468), (492, 1580), (490, 1762)], sock=1522,
              shoe=(490, 1768, -1, 6)),
    'R': dict(cl=[(590, 1050), (582, 1262), (574, 1418), (572, 1470), (584, 1582), (608, 1748)], sock=1528,
              shoe=(610, 1752, 1, 30)),
}
LEG_W = [60, 51, 38, 35, 39, 18]
YS = 1.1
def _ys(y): return 1040 + (y - 1040) * YS
for _g in LEGS.values():
    _g['cl'] = [(x, _ys(y)) for x, y in _g['cl']]
    _g['sock'] = round(_ys(_g['sock']))
    _sx, _sy, _fl, _rt = _g['shoe']; _g['shoe'] = (_sx, _ys(_sy) + 40, _fl, _rt)
    _g['cl'] = [(x, y + 40) for x, y in _g['cl']]
    _g['sock'] += 40


def legs():
    o = ['<ellipse cx="545" cy="1924" rx="180" ry="22" fill="#000" opacity="0.09" filter="url(#b14)"/>']
    for key in ('R', 'L'):  # weight leg in front
        g = LEGS[key]
        d = leg_path(g['cl'], LEG_W)
        o.append(f'<path d="{d}" fill="{SKIN}" stroke="{SKIN_LINE}" stroke-width="3.2" stroke-linejoin="round"/>')
        k = g['cl'][3]
        o.append(f'<clipPath id="lc{key}"><path d="{d}"/></clipPath><g clip-path="url(#lc{key})">'
                 f'<path d="M {k[0] + 34} 1080 C {k[0] + 40} 1300 {k[0] + 34} 1420 {k[0] + 30} 1500" fill="none" stroke="{SKIN_SH}" stroke-width="22" opacity="0.7" filter="url(#b8)"/>'
                 f'<ellipse cx="{k[0]}" cy="{k[1] + 4}" rx="20" ry="12" fill="#ffb6bf" opacity="0.35" filter="url(#b3)"/>'
                 f'<rect x="300" y="{g["sock"]}" width="500" height="400" fill="#ffffff"/>'
                 f'<path d="M {k[0] + 30} {g["sock"] + 20} C {k[0] + 40} 1720 {k[0] + 30} 1780 {k[0] + 22} 1840" fill="none" stroke="#e6e4ee" stroke-width="12" filter="url(#b8)"/>'
                 f'</g>')
        o.append(f'<path d="{d}" fill="none" stroke="{SKIN_LINE}" stroke-width="3.2" stroke-linejoin="round"/>')
        o.append(f'<clipPath id="sk{key}"><rect x="300" y="{g["sock"]}" width="500" height="400"/></clipPath><path d="{d}" fill="none" stroke="{WHITE_LINE}" stroke-width="3.4" clip-path="url(#sk{key})"/>')
        # sock outline over the lower leg + top band
        o.append(f'<g clip-path="url(#lc{key})"><rect x="300" y="{g["sock"]}" width="500" height="400" fill="none"/></g>')
        sx = g['cl'][3][0] + (g['cl'][4][0] - g['cl'][3][0]) * 0.5
        o.append(f'<path d="M {sx - 42:.0f} {g["sock"]} Q {sx:.0f} {g["sock"] + 10} {sx + 42:.0f} {g["sock"]}" fill="none" stroke="{WHITE_LINE}" stroke-width="3"/>'
                 f'<path d="M {sx - 40:.0f} {g["sock"] + 12} Q {sx:.0f} {g["sock"] + 22} {sx + 40:.0f} {g["sock"] + 12}" fill="none" stroke="#d9d7e2" stroke-width="2.5"/>')
        # knee line
        o.append(f'<path d="M {k[0] - 12} {k[1] - 4} Q {k[0]} {k[1] + 6} {k[0] + 12} {k[1] - 4}" fill="none" stroke="{SKIN_SH2}" stroke-width="2.2" stroke-linecap="round"/>')
        sx_, sy_, fl, rot = g['shoe']
        o.append(shoe2(sx_, sy_, fl, rot))
    return "".join(o)


def skirt(t):
    sw = 6 * math.sin(t * 2 * math.pi * 0.8 - 1.2)
    hem = [(312, 1318), (352, 1342), (394, 1324), (440, 1348), (488, 1330), (540, 1352), (592, 1330), (640, 1348),
           (686, 1324), (728, 1342), (768, 1318)]
    hem = [(x + sw * (x - 540) / 230, y) for x, y in hem]
    d = "M 420 982 Q 540 996 660 982 C 700 1030 744 1150 " + f"{hem[-1][0]:.0f} {hem[-1][1]} "
    for i in range(len(hem) - 1, 0, -1):
        (x0, y0), (x1, y1) = hem[i], hem[i - 1]
        d += f"Q {(x0 + x1) / 2:.0f} {max(y0, y1) + 9:.0f} {x1:.0f} {y1} "
    d += "C 336 1150 380 1030 420 982 Z"
    o = [f'<clipPath id="skC"><path d="{d}"/></clipPath>']
    o.append(f'<path d="{d}" fill="url(#scrubG)" stroke="{SCRUB_LINE}" stroke-width="{CL + 1}" stroke-linejoin="round"/>')
    o.append('<g clip-path="url(#skC)">')
    for (hx, hy) in hem[1:-1]:
        tx = 540 + (hx - 540) * 0.4
        o.append(f'<path d="M {tx:.0f} 1006 Q {(tx + hx) / 2:.0f} 1160 {hx:.0f} {hy}" fill="none" stroke="{SCRUB_D}" stroke-width="2.5" opacity="0.8"/>')
    for (hx, hy) in hem[1:-1:2]:
        o.append(f'<path d="M {540 + (hx - 540) * 0.4:.0f} 1020 L {hx:.0f} {hy}" stroke="{SCRUB_D}" stroke-width="20" opacity="0.32" filter="url(#b8)"/>')
    o.append(f'<path d="M 690 1010 C 730 1120 760 1240 790 1360 L 830 1360 L 830 990 Z" fill="{SCRUB_D}" opacity="0.6" filter="url(#b8)"/>')
    o.append('<path d="M 420 1000 Q 540 1030 660 1000" fill="none" stroke="#c9667f" stroke-width="12" opacity="0.35" filter="url(#b8)"/>')
    o.append('</g>')
    o.append(f'<path d="M 418 978 Q 540 994 662 978 L 666 1006 Q 540 1024 414 1006 Z" fill="#ffffff" stroke="{SCRUB_LINE}" stroke-width="2.6"/>')
    return "".join(o)


def frame_svg(t, clip=None):
    raise_k = ease((t - 0.15) / 0.65)
    wave_amp = 17 * ease((t - 0.6) / 0.4)
    wave = wave_amp * math.sin((t - 0.6) * 2 * math.pi * 1.6)
    bob = 4 * math.sin(t * 2 * math.pi * 0.8)
    sway = 1.0 * math.sin(t * 2 * math.pi * 0.4)
    head_tilt = -5 * raise_k + 1.5 * math.sin(t * 2 * math.pi * 0.8 + 0.6)
    blink = 1.0
    for bt in (2.1, 4.6):
        d = abs(t - bt)
        if d < 0.12: blink = min(blink, d / 0.12)
    happy = 0.85 < t < 1.5
    mo = 0.35
    for a, b in ((0.8, 1.35), (3.1, 3.6)):
        if a < t < b: mo = 0.35 + 0.65 * math.sin(math.pi * (t - a) / (b - a))
    a1 = 100 + (200 - 100) * raise_k
    a2 = 95 + (-84 - 95) * raise_k + wave * raise_k
    spread = 5 * raise_k + 2.5 * math.sin(t * 9)
    bk = back_out((t - 0.75) / 0.45) if t > 0.75 else 0.0
    hair_sw = 1.8 * math.sin(t * 2 * math.pi * 0.8 - 0.9)
    look = -4 * raise_k
    if clip == 'wave3':
        raise_k = ease(t / 0.4)
        wave = 17 * ease((t - 0.15) / 0.3) * math.sin((t - 0.15) * 2 * math.pi * 1.7)
        a1 = 100 + (200 - 100) * raise_k
        a2 = 95 + (-84 - 95) * raise_k + wave * raise_k
        spread = 5 * raise_k + 2.5 * math.sin(t * 9)
        mo, happy, bk = 0.35, False, 0.0
        # eye contact: centre -> left -> right -> centre
        look = (-13 * ease((t - 0.5) / 0.25) + 26 * ease((t - 1.25) / 0.3) - 13 * ease((t - 2.0) / 0.25))
        head_tilt = -4 * raise_k + look * 0.18 + 1.2 * math.sin(t * 2 * math.pi * 0.8 + 0.6)
        blink = 1.0
        d = abs(t - 2.5)
        if d < 0.1: blink = d / 0.1

    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', DEFS,
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>']
    o.append(f'<g transform="translate({540 * (1 - SC):.1f},20) scale({SC})">')
    o.append('<g transform="translate(540,0) scale(0.9,1) translate(-540,0)">' + legs() + '</g>')
    o.append(f'<g transform="translate(0,{bob:.2f}) rotate({sway - 2:.2f} 540 1000)">')

    # ---------- back hair ----------
    o.append(f'<g transform="translate(0,30) rotate({head_tilt * 0.6 + hair_sw * 0.6:.2f} 540 560)">')
    back = ("M 420 260 C 350 380 334 540 326 670 C 318 770 302 840 280 896 C 312 884 336 896 356 916 "
            "C 380 896 404 906 426 922 L 654 922 C 676 906 700 896 724 916 C 744 896 768 884 800 896 "
            "C 778 840 762 770 754 670 C 746 540 730 380 660 260 Z")
    o.append(f'<path d="{back}" fill="url(#hairU)" stroke="{HAIR_LINE}" stroke-width="{CL}" stroke-linejoin="round"/>')
    ls = []
    for i in range(14):
        xx = 360 + i * 26
        side = -1 if xx < 540 else 1
        ls.append((xx + side * 6, 560, xx + side * 4, 740, xx + side * 10, 900))
    o.append(strands(ls, HAIR_D, 1.6, 0.5))
    o.append(strands([(330, 700, 306, 800, 288, 890), (750, 700, 774, 800, 792, 890),
                      (352, 760, 340, 840, 336, 910), (728, 760, 740, 840, 744, 910)], HAIR_D, 1.5, 0.6))
    o.append('<ellipse cx="540" cy="640" rx="110" ry="90" fill="#8a5a1c" opacity="0.45" filter="url(#b14)"/>')
    o.append('</g>')

    # ---------- far arm ----------

    o.append('<g transform="translate(540,0) scale(0.9,1) translate(-540,0)">')
    # ---------- torso (scrub top) ----------
    torso = ("M 518 692 C 470 698 418 706 388 724 C 356 744 344 802 348 856 C 354 906 382 936 402 952 "
             "C 412 976 418 1014 420 1052 L 420 1084 L 660 1084 L 660 1052 C 662 1014 668 976 682 948 "
             "C 698 936 726 906 732 856 C 736 802 724 744 692 724 C 662 706 610 698 562 692 Z")
    o.append(f'<clipPath id="torsoC"><path d="{torso}"/></clipPath>')
    o.append(f'<path d="{torso}" fill="url(#scrubG)" stroke="{SCRUB_LINE}" stroke-width="{CL + 1}"/>')
    o.append(f'<g clip-path="url(#torsoC)">'
             f'<path d="M 386 922 Q 446 960 514 930" fill="none" stroke="{SCRUB_D}" stroke-width="14" opacity="0.65" filter="url(#b8)"/>'
             f'<path d="M 566 930 Q 634 960 694 922" fill="none" stroke="{SCRUB_D}" stroke-width="14" opacity="0.65" filter="url(#b8)"/>'
             f'<ellipse cx="448" cy="856" rx="50" ry="38" fill="#ffffff" opacity="0.42" filter="url(#b14)"/>'
             f'<ellipse cx="628" cy="850" rx="40" ry="30" fill="#ffffff" opacity="0.2" filter="url(#b14)"/>'
             f'<path d="M 452 934 C 460 980 462 1020 458 1080" fill="none" stroke="{SCRUB_D}" stroke-width="2.2" opacity="0.7"/>'
             f'<path d="M 628 934 C 620 980 618 1020 622 1080" fill="none" stroke="{SCRUB_D}" stroke-width="2.2" opacity="0.7"/>'
             f'</g>')
    o.append(f'<g clip-path="url(#torsoC)">'
             f'<path d="M 700 760 C 740 850 745 980 740 1100 L 800 1100 L 800 700 Z" fill="{SCRUB_D}" opacity="0.7" filter="url(#b8)"/>'
             f'<path d="M 428 1018 Q 540 1044 652 1018" fill="none" stroke="{SCRUB_D}" stroke-width="10" filter="url(#b8)" opacity="0.8"/>'
             f'<path d="M 470 1060 C 476 1110 468 1160 472 1200" fill="none" stroke="{SCRUB_D}" stroke-width="5" filter="url(#b3)" opacity="0.5"/>'
             f'<path d="M 612 1060 C 606 1110 614 1160 608 1200" fill="none" stroke="{SCRUB_D}" stroke-width="5" filter="url(#b3)" opacity="0.5"/>'
             f'<path d="M 356 870 C 372 940 402 1000 420 1044" fill="none" stroke="{SCRUB_D}" stroke-width="10" filter="url(#b8)" opacity="0.6"/>'
             f'</g>'
             '')
    o.append('<g transform="translate(0,66) rotate(3 540 990)">' + skirt(t) + '</g>')
    oa2 = 52 + 3 * math.sin(t * 2 * math.pi * 0.8)
    sk2, sl2, Hd2 = arm((704, 744), 76, oa2)
    o.append(sk2); o.append(hand2(Hd2[0], Hd2[1], oa2, -2)); o.append(sl2)
    # neck
    o.append(f'<path d="M 518 584 L 516 702 Q 540 716 564 702 L 562 584 Z" fill="{SKIN}" stroke="{SKIN_LINE}" stroke-width="{CL}"/>'
             f'<path d="M 514 600 Q 540 660 566 600 L 566 640 Q 540 684 514 640 Z" fill="{SKIN_SH}"/>')
    # V neck with inner white undershirt edge & trim
    o.append(f'<path d="M 488 694 L 540 800 L 592 694 Q 540 712 488 694 Z" fill="{SKIN}" stroke="{SKIN_LINE}" stroke-width="2"/>'
             f'<path d="M 500 698 L 540 760 L 580 698" fill="none" stroke="{SKIN_SH}" stroke-width="8" filter="url(#b3)"/>'
             f'<path d="M 496 712 Q 512 718 530 714 M 584 712 Q 568 718 550 714" fill="none" stroke="{SKIN_SH2}" stroke-width="2.2" stroke-linecap="round"/>'
             f'<path d="M 538 722 Q 540 730 542 722" fill="none" stroke="{SKIN_SH2}" stroke-width="1.8" stroke-linecap="round" opacity="0.7"/>')
    o.append(f'<path d="M 478 690 L 540 812 L 602 690" fill="none" stroke="#ffffff" stroke-width="9" stroke-linejoin="round"/>'
             f'<path d="M 472 688 L 540 822 L 608 688" fill="none" stroke="{SCRUB_LINE}" stroke-width="2.2" stroke-linejoin="round"/>'
             f'<path d="M 484 692 L 540 802 L 596 692" fill="none" stroke="{SCRUB_LINE}" stroke-width="2.2" stroke-linejoin="round"/>')
    o.append('<g transform="translate(0,-44)">')
    # chest pocket with pens (viewer-right)
    o.append(f'<path d="M 600 900 L 690 896 L 692 980 Q 646 990 602 982 Z" fill="{SCRUB}" stroke="{SCRUB_LINE}" stroke-width="2.4"/>'
             f'<path d="M 600 912 L 690 908" stroke="{SCRUB_LINE}" stroke-width="1.6" stroke-dasharray="5 4"/>'
             f'<rect x="618" y="862" width="9" height="46" rx="4" fill="#4a7bd6" stroke="#2c4f92" stroke-width="2"/>'
             f'<rect x="634" y="868" width="9" height="40" rx="4" fill="#f2f2f2" stroke="{WHITE_LINE}" stroke-width="2"/>'
             f'<path d="M 638 868 L 638 896" stroke="#b9b9c4" stroke-width="2"/>')
    # ID badge (viewer-left)
    o.append(f'<line x1="440" y1="850" x2="440" y2="880" stroke="#9aa0b0" stroke-width="3"/>'
             f'<rect x="402" y="878" width="78" height="96" rx="8" fill="#ffffff" stroke="{WHITE_LINE}" stroke-width="2.4"/>'
             f'<rect x="402" y="878" width="78" height="22" rx="8" fill="{SCRUB_D}"/>'
             f'<rect x="402" y="890" width="78" height="10" fill="{SCRUB_D}"/>'
             f'<circle cx="441" cy="928" r="16" fill="#ffe1d3" stroke="{WHITE_LINE}" stroke-width="1.6"/>'
             f'<rect x="416" y="952" width="50" height="5" rx="2" fill="#c3c6d0"/>'
             f'<rect x="422" y="962" width="38" height="4" rx="2" fill="#d6d8e0"/>')
    o.append('</g>')
    o.append('<g transform="translate(0,700) scale(1,0.86) translate(0,-700)">')
    # stethoscope around neck
    o.append(f'<path d="M 470 700 C 440 760 444 840 470 900" fill="none" stroke="{TUBE}" stroke-width="11" stroke-linecap="round"/>'
             f'<path d="M 470 700 C 440 760 444 840 470 900" fill="none" stroke="{TUBE_L}" stroke-width="3" stroke-linecap="round" opacity="0.7" transform="translate(-2,-1)"/>'
             f'<path d="M 610 700 C 640 760 640 820 612 880 C 600 906 596 930 600 960" fill="none" stroke="{TUBE}" stroke-width="11" stroke-linecap="round"/>'
             f'<path d="M 610 700 C 640 760 640 820 612 880" fill="none" stroke="{TUBE_L}" stroke-width="3" stroke-linecap="round" opacity="0.7" transform="translate(-2,-1)"/>'
             f'<circle cx="600" cy="978" r="22" fill="url(#metal)" stroke="#6b7284" stroke-width="2.4"/>'
             f'<circle cx="600" cy="978" r="12" fill="none" stroke="#8a91a3" stroke-width="2"/>'
             f'<circle cx="470" cy="906" r="9" fill="url(#metal)" stroke="#6b7284" stroke-width="2"/>')
    o.append('</g>')

    o.append('</g>')
    # ---------- head ----------
    o.append(f'<g transform="translate(0,30) rotate({head_tilt:.2f} 540 620)">')
    face = ("M 414 392 C 410 462 432 530 478 576 C 502 598 524 608 540 608 C 556 608 578 598 602 576 "
            "C 648 530 670 462 666 392 C 664 290 610 232 540 232 C 470 232 416 290 414 392 Z")
    o.append(f'<clipPath id="faceC"><path d="{face}"/></clipPath>')
    o.append(f'<path d="{face}" fill="url(#skinG)" stroke="{SKIN_LINE}" stroke-width="{CL}"/>')
    # bang shadow on forehead
    sh = "M 400 300 L 680 300 L 680 " + f"{BANG_TIPS[-1][1] + 18:.0f} "
    for (bx, by) in reversed(BANG_TIPS):
        sh += f"L {bx:.0f} {by + 16:.0f} "
    sh += f"L 400 {BANG_TIPS[0][1] + 18:.0f} Z"
    o.append(f'<g clip-path="url(#faceC)"><path d="{sh}" fill="{SKIN_SH}" opacity="0.85" filter="url(#b3)"/>'
             f'<path d="M 640 400 C 660 470 640 540 600 580 L 680 600 L 690 380 Z" fill="{SKIN_SH}" opacity="0.6" filter="url(#b8)"/></g>')
    # blush
    o.append('<ellipse cx="466" cy="530" rx="36" ry="16" fill="#ff8c9e" opacity="0.42" filter="url(#b8)"/>'
             '<ellipse cx="614" cy="530" rx="36" ry="16" fill="#ff8c9e" opacity="0.42" filter="url(#b8)"/>')
    # eyes (larger, set lower, wider)
    ex, ey = 64, 474
    for (cx, s, uid) in ((540 - ex, -1, "L"), (540 + ex, 1, "R")):
        o.append(f'<g transform="translate({cx},{ey}) scale(1.08) translate({-cx},{-ey})">')
        o.append(happy_eye(cx, ey, s) if happy else eye(cx, ey, s, blink, look, uid))
        o.append('</g>')
    # brows (thin, peek through bangs)
    o.append(f'<path d="M 450 412 Q 476 402 504 408" fill="none" stroke="{HAIR_D}" stroke-width="2.6" stroke-linecap="round"/>'
             f'<path d="M 576 408 Q 604 402 630 412" fill="none" stroke="{HAIR_D}" stroke-width="2.6" stroke-linecap="round"/>')
    # nose
    o.append(f'<path d="M 544 530 Q 546 536 540 539" fill="none" stroke="{SKIN_SH2}" stroke-width="2.2" stroke-linecap="round"/>')
    # small mouth
    d = 4 + 18 * mo; w = 12 + 6 * mo
    mp = (f"M {f(540 - w)} 562 Q 540 566 {f(540 + w)} 562 C {f(540 + w * 0.8)} {f(565 + d * 0.8)} {f(540 + w * 0.35)} {f(563 + d)} 540 {f(563 + d)} "
          f"C {f(540 - w * 0.35)} {f(563 + d)} {f(540 - w * 0.8)} {f(565 + d * 0.8)} {f(540 - w)} 562 Z")
    o.append(f'<clipPath id="mC"><path d="{mp}"/></clipPath>')
    o.append(f'<path d="{mp}" fill="#a3354b"/>')
    o.append(f'<g clip-path="url(#mC)"><ellipse cx="540" cy="{f(566 + d)}" rx="{f(w * 0.75)}" ry="{f(d * 0.5 + 2)}" fill="#f2899a"/></g>')
    o.append(f'<path d="{mp}" fill="none" stroke="#7a2236" stroke-width="2.2" stroke-linejoin="round"/>')

    # side locks
    o.append(f'<g transform="rotate({hair_sw * 0.8:.2f} 420 330)">')
    for d_ in (lock(426, 384, 366, 770, 44, -30), lock(426, 380, 412, 690, 22, -8)):
        o.append(f'<path d="{d_}" fill="url(#hairU)" stroke="{HAIR_LINE}" stroke-width="{CL}" stroke-linejoin="round"/>')
    o.append(strands([(412, 400, 400, 560, 388, 740), (420, 420, 410, 560, 400, 700)], HAIR_D, 1.4, 0.6))
    o.append('</g>')
    o.append(f'<g transform="rotate({hair_sw * 0.8:.2f} 660 330)">')
    for d_ in (lock(654, 384, 714, 770, 44, 30), lock(654, 380, 668, 690, 22, 8)):
        o.append(f'<path d="{d_}" fill="url(#hairU)" stroke="{HAIR_LINE}" stroke-width="{CL}" stroke-linejoin="round"/>')
    o.append(strands([(668, 400, 680, 560, 692, 740), (660, 420, 670, 560, 680, 700)], HAIR_D, 1.4, 0.6))
    o.append('</g>')

    # crown + fine-strand bangs
    dd = "M 686 470 C 712 352 672 202 540 200 C 408 202 368 352 394 470 "
    prev = (394, 470)
    for (nx_, ny_, tx, ty, lean) in BANGS:
        px, py = prev
        dd += f"C {px + 4:.0f} {py - 26:.0f} {nx_ - 6:.0f} {ny_ + 10:.0f} {nx_} {ny_} "
        dd += f"C {nx_ + 2:.0f} {ny_ + (ty - ny_) * 0.5:.0f} {tx - 8 + lean:.0f} {ty - 24:.0f} {tx} {ty} "
        prev = (tx, ty)
    dd += f"C {prev[0] + 6:.0f} {prev[1] - 30:.0f} 680 {440:.0f} 686 470 Z"
    o.append(f'<clipPath id="bangC"><path d="{dd}"/></clipPath>')
    o.append(f'<path d="{dd}" fill="url(#hairG)"/>')
    o.append('<g clip-path="url(#bangC)">')
    o.append(f'<path d="M 420 312 C 460 268 620 268 662 312 L 664 330 C 650 318 640 336 626 320 C 612 336 598 314 584 328 '
             f'C 568 312 556 332 540 316 C 524 332 512 312 496 328 C 482 314 470 336 456 320 C 444 336 430 318 418 332 Z" '
             f'fill="{HAIR_HL}" opacity="0.55" filter="url(#b3)"/>')
    # many fine strands
    fl = []
    for i, (nx_, ny_, tx, ty, lean) in enumerate(BANGS):
        rx_ = 540 + (tx - 540) * 0.75; ry_ = 230 + ((tx - 540) / 130) ** 2 * 60
        fl.append((f(rx_), f(ry_), f((rx_ + tx) / 2 + lean), f((ry_ + ty) / 2), f(tx), f(ty - 6)))
        fl.append((f(rx_ - 8), f(ry_ + 8), f((rx_ + tx) / 2 - 6 + lean), f((ry_ + ty) / 2 + 6), f(tx - 8), f(ty - 30)))
        fl.append((f(rx_ + 8), f(ry_ + 8), f((rx_ + tx) / 2 + 8 + lean), f((ry_ + ty) / 2 + 6), f(tx + 8), f(ty - 34)))
    o.append(strands(fl, HAIR_D, 1.3, 0.55))
    o.append(f'<path d="M 400 470 C 396 420 416 380 436 360 L 436 474 Z" fill="{HAIR_D}" opacity="0.35" filter="url(#b8)"/>'
             f'<path d="M 680 470 C 684 420 664 380 644 360 L 644 474 Z" fill="{HAIR_D}" opacity="0.35" filter="url(#b8)"/>')
    o.append('</g>')
    o.append(f'<path d="{dd}" fill="none" stroke="{HAIR_LINE}" stroke-width="{CL}" stroke-linejoin="round"/>')
    # thin strands crossing over the eyes
    for d_ in (lock(498, 360, 486, 492, 9, -6), lock(588, 356, 604, 486, 8, 6), lock(548, 350, 544, 470, 6, 3)):
        o.append(f'<path d="{d_}" fill="url(#hairG)" stroke="{HAIR_LINE}" stroke-width="1.8" stroke-linejoin="round"/>')
    # nurse cap
    o.append('<g transform="translate(540,252) rotate(-4) scale(1.05)">'
             f'<path d="M -96 14 L -78 -42 Q 0 -58 78 -42 L 96 14 Q 0 0 -96 14 Z" fill="url(#capG)" stroke="{WHITE_LINE}" stroke-width="2.6" stroke-linejoin="round"/>'
             f'<path d="M -78 -42 Q 0 -58 78 -42 L 70 -24 Q 0 -38 -70 -24 Z" fill="#ffffff" stroke="{WHITE_LINE}" stroke-width="2" stroke-linejoin="round"/>'
             f'<path d="M -90 8 Q 0 -6 90 8" fill="none" stroke="{SCRUB_D}" stroke-width="6"/>'
             f'<path d="M 0 -14 C -4 -24 -18 -22 -16 -12 C -14 -4 -4 2 0 6 C 4 2 14 -4 16 -12 C 18 -22 4 -24 0 -14 Z" fill="{SCRUB_D}"/>'
             f'<path d="M -60 -6 L -54 -36" stroke="#d8d6e2" stroke-width="2"/><path d="M 60 -6 L 54 -36" stroke="#d8d6e2" stroke-width="2"/>'
             '</g>')
    o.append('</g>')  # head

    o.append('<g transform="translate(540,0) scale(0.9,1) translate(-540,0)">')
    # ---------- waving arm ----------
    sk, sl, Hd = arm((382, 744), a1, a2)
    o.append(sk)
    o.append(hand2(Hd[0], Hd[1], a2, spread))
    o.append(sl)
    o.append('</g>')
    o.append('</g>')
    o.append('</g>')  # global scale
    # ---------- speech bubble ----------
    if bk > 0.001:
        o.append(f'<g transform="translate(830,290) scale({bk * 0.72:.3f})">'
                 f'<path d="M -128 -60 Q -128 -82 -106 -82 L 108 -82 Q 130 -82 130 -60 L 130 48 Q 130 70 108 70 '
                 f'L -24 70 L -78 122 L -60 70 L -106 70 Q -128 70 -128 48 Z" fill="#ffffff" stroke="{LASH}" '
                 f'stroke-width="5" stroke-linejoin="round"/>'
                 f'<text x="0" y="24" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-weight="bold" '
                 f'font-size="84" fill="{SCRUB_LINE}">Hi!</text></g>')
        for (sx, sy, ph, sz) in ((990, 140, 0.0, 0.9), (690, 160, 1.3, 0.6), (1000, 380, 2.4, 0.55)):
            sc = bk * sz * (0.75 + 0.25 * math.sin(t * 6 + ph))
            o.append(f'<g transform="translate({sx},{sy}) scale({sc:.3f})">'
                     f'<path d="M 0 -26 Q 4 -4 26 0 Q 4 4 0 26 Q -4 4 -26 0 Q -4 -4 0 -26 Z" fill="#ffd25a"/></g>')
    o.append('</svg>')
    return "".join(o)


if __name__ == "__main__":
    sys.stdout.write(frame_svg(float(sys.argv[1])))
