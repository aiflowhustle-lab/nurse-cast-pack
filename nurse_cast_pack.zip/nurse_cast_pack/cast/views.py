"""Back and side (profile) views for the cast.  Side view faces screen-right; chars.render mirrors for turn=-1."""
import math
import draw3, cast
from draw2 import pt, f, quad, limb_layers, lock, strands
from draw3 import hand2, leg_path, fist

CL = 2.6
SQ = '<g transform="translate(540,0) scale(0.9,1) translate(-540,0)">'


def _mirror_spec(spec):
    if spec[0] == 'ik':
        _, T, bend = spec[:3]
        return ('ik', (1080 - T[0], T[1]), -bend) + tuple(spec[3:])
    a1, a2 = spec[:2]
    return (180 - a1, 180 - a2) + tuple(spec[2:])


# ================================================================== BACK VIEW
def hair_back(C):
    st = C['hair']; L = C['hair_line']; HD = C['hair_d']; HL = C['hair_hl']
    fill = f'fill="url(#hairU)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"'
    o = []
    if st == 'long':
        d = ("M 540 200 C 650 200 704 300 700 420 C 716 520 752 600 754 670 C 762 770 778 840 800 896 "
             "C 768 884 744 896 724 916 C 700 896 676 906 654 922 L 426 922 C 404 906 380 896 356 916 "
             "C 336 896 312 884 280 896 C 302 840 318 770 326 670 C 328 600 364 520 380 420 C 376 300 430 200 540 200 Z")
        o.append(f'<path d="{d}" {fill}/>')
        ls = []
        for i in range(17):
            x = 330 + i * 26
            ls.append((540 + (x - 540) * 0.12, 250, 540 + (x - 540) * 0.7, 520, x + (x - 540) * 0.1, 900))
        o.append(strands(ls, HD, 1.6, 0.55))
        o.append(f'<path d="M 420 330 Q 540 280 660 330" fill="none" stroke="{HL}" stroke-width="14" opacity="0.55" filter="url(#b3)" stroke-linecap="round"/>')
        o.append(f'<circle cx="540" cy="252" r="6" fill="{HD}" opacity="0.6"/>')
    elif st == 'bun':
        d = ("M 540 204 C 640 204 690 290 686 400 C 684 470 660 530 620 560 Q 540 574 460 560 "
             "C 420 530 396 470 394 400 C 390 290 440 204 540 204 Z")
        o.append(f'<path d="{d}" {fill}/>')
        o.append(strands([(420, 470, 470, 330, 540, 230), (660, 470, 610, 330, 540, 230), (470, 540, 500, 380, 540, 236),
                          (610, 540, 580, 380, 540, 236), (540, 556, 540, 400, 540, 240)], HD, 1.6, 0.6))
        o.append(f'<circle cx="540" cy="226" r="62" {fill}/>'
                 + strands([(500, 200, 540, 170, 580, 200), (494, 232, 540, 206, 588, 236), (506, 260, 540, 248, 576, 260)], HD, 1.6, 0.6)
                 + f'<path d="M 488 276 Q 540 296 592 276" fill="none" stroke="{C.get("accent", "#5a6db0")}" stroke-width="10" stroke-linecap="round"/>')
        o.append(f'<path d="M 470 556 L 474 584 M 520 566 L 520 590 M 560 566 L 560 590 M 610 556 L 606 584" stroke="{L}" stroke-width="2.4" stroke-linecap="round"/>')
    elif st == 'bob':
        d = ("M 540 204 C 650 204 712 300 724 420 C 734 520 728 620 700 676 Q 540 700 380 676 "
             "C 352 620 346 520 356 420 C 368 300 430 204 540 204 Z")
        o.append(f'<path d="{d}" {fill}/>')
        ls = [(540 + (x - 540) * 0.1, 250, 540 + (x - 540) * 0.75, 460, x, 670) for x in range(380, 704, 26)]
        o.append(strands(ls, HD, 1.5, 0.55))
        o.append(f'<path d="M 420 330 Q 540 284 660 330" fill="none" stroke="{HL}" stroke-width="14" opacity="0.5" filter="url(#b3)" stroke-linecap="round"/>')
        o.append(f'<path d="M 650 300 l 14 -4 l 0 16 Z" fill="{C.get("accent", "#a48bd6")}"/>')
    elif st == 'soft_m':
        d = ("M 540 206 C 646 206 700 290 696 400 C 694 480 686 560 676 612 L 650 590 L 630 628 L 604 600 L 580 630 "
             "L 560 604 L 540 632 L 520 604 L 500 630 L 476 600 L 450 628 L 430 590 L 404 612 C 394 560 386 480 384 400 "
             "C 380 290 434 206 540 206 Z")
        o.append(f'<path d="{d}" {fill}/>')
        ls = [(540 + (x - 540) * 0.1, 250, 540 + (x - 540) * 0.8, 440, x, 610) for x in range(410, 680, 28)]
        o.append(strands(ls, HD, 1.5, 0.55))
        o.append(f'<path d="M 424 330 Q 540 290 656 330" fill="none" stroke="{HL}" stroke-width="12" opacity="0.5" filter="url(#b3)" stroke-linecap="round"/>')
    elif st == 'messy_m':
        pts = []
        for i in range(25):
            a = math.radians(180 + i * 7.5 + 7.5 / 2 - 7.5 / 2)
            r = 150 if i % 2 == 0 else 128
            pts.append((540 + r * math.cos(a) * 1.0, 400 + r * math.sin(a) * 1.25))
        d = "M " + " L ".join(f"{f(x)} {f(y)}" for x, y in pts)
        d += " L 680 460 L 660 520 L 620 560 L 600 540 L 580 572 L 560 548 L 540 576 L 520 548 L 500 572 L 480 540 L 460 560 L 420 520 L 400 460 Z"
        o.append(f'<path d="{d}" {fill}/>')
        ls = [(540, 300, 540 + (x - 540) * 0.6, 420, x, 540) for x in range(440, 650, 30)]
        o.append(strands(ls, HD, 1.5, 0.55))
    return "".join(o)


def ears_back(C):
    sk, sksh, sksh2, skl = C['skin']
    o = []
    for sgn in (1, -1):
        X = lambda x: f(540 + sgn * (x - 540))
        o.append(f'<path d="M {X(410)} 446 C {X(392)} 436 {X(380)} 452 {X(384)} 478 C {X(388)} 504 {X(400)} 520 {X(416)} 522 Z" '
                 f'fill="{sksh}" stroke="{skl}" stroke-width="{CL}" stroke-linejoin="round"/>')
    return "".join(o)


def legs_back(C):
    male = C['male']; nurse = C['outfit'] == 'nurse'
    sk, sksh, sksh2, skl = C['skin']
    o = []
    if nurse:
        geo = {k: [(1080 - x, y) for x, y in v['cl']] for k, v in draw3.LEGS.items()}
        socks = {k: v['sock'] for k, v in draw3.LEGS.items()}
        ws = draw3.LEG_W
    else:
        geo = cast.M_STRAIGHT if male else cast.F_STRAIGHT
        geo = {k: [(1080 - x, y) for x, y in v] for k, v in geo.items()}
        socks = None
        ws = cast.LEG_M if male else cast.LEG_F
    sy = max(v[-1][1] for v in geo.values())
    o.append(f'<ellipse cx="540" cy="{sy + 50}" rx="190" ry="22" fill="#000" opacity="0.09" filter="url(#b14)"/>')
    for key in ('L', 'R'):
        cl = geo[key]
        d = leg_path(cl, ws)
        k = cl[3]
        o.append(f'<path d="{d}" fill="{sk}" stroke="{skl}" stroke-width="3.2" stroke-linejoin="round"/>')
        o.append(f'<clipPath id="lb{key}"><path d="{d}"/></clipPath><g clip-path="url(#lb{key})">'
                 f'<path d="M {k[0] - 30} 1080 L {k[0] - 26} 1900" stroke="{sksh}" stroke-width="22" opacity="0.55" filter="url(#b8)"/>'
                 f'<ellipse cx="{k[0]}" cy="{k[1] + 120}" rx="26" ry="60" fill="{sksh}" opacity="0.35" filter="url(#b8)"/>')
        if socks:
            o.append(f'<rect x="300" y="{socks[key]}" width="500" height="500" fill="#ffffff"/>')
        o.append('</g>')
        if socks:
            o.append(f'<clipPath id="ls{key}"><rect x="300" y="{socks[key]}" width="500" height="500"/></clipPath>'
                     f'<path d="{d}" fill="none" stroke="#8a8494" stroke-width="3.4" clip-path="url(#ls{key})"/>')
            sx = cl[3][0] + (cl[4][0] - cl[3][0]) * 0.5
            o.append(f'<path d="M {sx - 40:.0f} {socks[key]} Q {sx:.0f} {socks[key] + 10} {sx + 40:.0f} {socks[key]}" fill="none" stroke="#8a8494" stroke-width="3"/>')
        if not male:
            o.append(f'<path d="M {k[0] - 14} {k[1] + 2} Q {k[0] - 4} {k[1] - 6} {k[0]} {k[1] + 2} Q {k[0] + 4} {k[1] - 6} {k[0] + 14} {k[1] + 2}" '
                     f'fill="none" stroke="{sksh2}" stroke-width="2" stroke-linecap="round"/>')
        if C.get('pants'):
            pw = [w_ + (16 if male else 14) for w_ in ws[:-1]] + [ws[-1] + (30 if male else 26)]
            pcl = cl[:-1] + [(cl[-1][0], cl[-1][1] - 14)]
            pd = leg_path(pcl, pw)
            o.append(f'<path d="{pd}" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>')
            o.append(f'<path d="M {k[0] - 20} {k[1] + 10} Q {k[0]} {k[1] + 22} {k[0] + 20} {k[1] + 8}" fill="none" stroke="{C["bottom_line"]}" stroke-width="2.2" opacity="0.6"/>')
        # heel view shoe
        a = cl[-1]
        if nurse:
            col, line, strap = "#ffffff", "#8a8494", "#de8ba5"
        else:
            col, line, strap = C['shoes'][0], C['shoes'][1], C['shoes'][2]
        s_ = 1.25 if male else 1.0
        o.append(f'<g transform="translate({f(a[0])},{f(a[1] + 6)}) scale({s_})">'
                 f'<path d="M -26 -8 C -32 12 -28 30 -2 34 C 24 32 32 14 26 -8 Q 0 -2 -26 -8 Z" fill="{col}" stroke="{line}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M -22 26 Q 0 34 22 26 L 18 40 L -18 40 Z" fill="{line}" opacity="0.55"/>'
                 + (f'<path d="M -24 -2 Q 0 6 24 -2" fill="none" stroke="{strap}" stroke-width="5"/>' if strap else '') + '</g>')
    if C.get('pants'):
        top = 1060 if male else 1000
        o.append(f'<path d="M {388 if male else 410} {top} L {692 if male else 670} {top} L {700 if male else 676} {top + 150} '
                 f'Q 540 {top + 196} {380 if male else 404} {top + 150} Z" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>'
                 f'<path d="M 540 {top + 10} L 540 {top + 186}" stroke="{C["bottom_line"]}" stroke-width="2.5" opacity="0.7"/>'
                 f'<path d="M {440 if male else 450} {top + 40} L {500 if male else 500} {top + 40} L {498 if male else 498} {top + 96} Q {470} {top + 104} {442 if male else 452} {top + 96} Z" fill="none" stroke="{C["bottom_line"]}" stroke-width="2" opacity="0.6"/>'
                 f'<path d="M {640 if male else 630} {top + 40} L {580} {top + 40} L {582} {top + 96} Q {610} {top + 104} {638 if male else 628} {top + 96} Z" fill="none" stroke="{C["bottom_line"]}" stroke-width="2" opacity="0.6"/>')
    return "".join(o)


def torso_back(C, t):
    male = C['male']; outfit = C['outfit']
    tl = C['top_line']; td = C['top_g'][2]
    o = []
    if outfit == 'nurse':
        torso = ("M 518 692 C 470 698 418 706 388 724 C 356 744 348 802 352 856 C 356 906 386 936 404 960 "
                 "C 414 990 418 1020 420 1052 L 420 1084 L 660 1084 L 660 1052 C 662 1020 666 990 676 960 "
                 "C 694 936 724 906 728 856 C 732 802 724 744 692 724 C 662 706 610 698 562 692 Z")
        o.append(f'<path d="{torso}" fill="url(#scrubG)" stroke="{tl}" stroke-width="{CL + 1}"/>')
        o.append(f'<clipPath id="tb"><path d="{torso}"/></clipPath><g clip-path="url(#tb)">'
                 f'<path d="M 440 780 Q 470 840 470 900 M 640 780 Q 610 840 610 900" fill="none" stroke="{td}" stroke-width="14" opacity="0.45" filter="url(#b8)"/>'
                 f'<path d="M 540 700 L 540 1084" stroke="{td}" stroke-width="2.2" opacity="0.6"/>'
                 f'<path d="M 428 1018 Q 540 1044 652 1018" fill="none" stroke="{td}" stroke-width="10" filter="url(#b8)" opacity="0.7"/></g>')
        o.append('<g transform="translate(0,66) rotate(-3 540 990)">' + draw3.skirt(t) + '</g>')
        # back bow on the waistband
        o.append('<g transform="translate(540,1062)">'
                 f'<path d="M 0 0 C -14 -22 -50 -24 -50 -2 C -50 18 -16 16 0 0 Z" fill="#ffffff" stroke="{tl}" stroke-width="2.6"/>'
                 f'<path d="M 0 0 C 14 -22 50 -24 50 -2 C 50 18 16 16 0 0 Z" fill="#ffffff" stroke="{tl}" stroke-width="2.6"/>'
                 f'<path d="M -4 6 L -18 44 L 0 36 Z M 4 6 L 18 44 L 0 36 Z" fill="#ffffff" stroke="{tl}" stroke-width="2.4" stroke-linejoin="round"/>'
                 f'<ellipse cx="0" cy="0" rx="9" ry="10" fill="#ffffff" stroke="{tl}" stroke-width="2.6"/></g>')
        return "".join(o)
    if outfit == 'suit_f':
        sk_ = ("M 420 982 Q 540 996 660 982 C 678 1040 690 1120 686 1200 C 682 1300 676 1400 672 1470 "
               "L 408 1470 C 404 1400 398 1300 394 1200 C 390 1120 402 1040 420 982 Z")
        bl = C["bottom_line"]; jl = C['coat_line']
        o.append(f'<path d="{sk_}" fill="url(#botG)" stroke="{bl}" stroke-width="3.4" stroke-linejoin="round"/>'
                 f'<path d="M 540 1100 L 540 1470" stroke="{bl}" stroke-width="2.2" opacity="0.7"/>'
                 f'<path d="M 540 1360 L 540 1470" stroke="{bl}" stroke-width="3"/>')
        jk = ("M 516 690 C 466 694 410 700 384 718 C 358 740 358 790 362 840 C 368 896 404 934 412 968 "
              "C 408 1020 398 1062 396 1094 Q 540 1112 684 1094 C 682 1062 672 1020 668 968 "
              "C 676 934 712 896 718 840 C 722 790 722 740 696 718 C 670 700 614 694 564 690 Z")
        o.append(f'<path d="{jk}" fill="url(#coatG)" stroke="{jl}" stroke-width="{CL + 1}"/>'
                 f'<clipPath id="tbf"><path d="{jk}"/></clipPath><g clip-path="url(#tbf)">'
                 + "".join(f'<path d="M {x} 680 L {x} 1120" stroke="#ffffff" stroke-width="1.2" opacity="0.1"/>' for x in range(356, 730, 16))
                 + f'<path d="M 440 780 Q 470 840 470 900 M 640 780 Q 610 840 610 900" fill="none" stroke="#0b1022" stroke-width="14" opacity="0.5" filter="url(#b8)"/></g>'
                 f'<path d="M 540 700 L 540 1104" stroke="{jl}" stroke-width="2.4"/>'
                 f'<path d="M 476 698 Q 540 728 604 698 L 610 722 Q 540 756 470 722 Z" fill="{C["lapel"][1]}" stroke="{jl}" stroke-width="2.4"/>')
        return "".join(o)
    torso = {'gown': cast.GOWN_M}.get(outfit, cast.TORSO_M if male else (cast.TORSO_F_LONG if C.get('pants') else cast.TORSO_F))
    if outfit == 'coat':
        torso = ("M 512 712 C 456 716 392 724 364 746 C 334 772 330 830 334 890 C 338 1010 334 1250 330 1520 "
                 "L 750 1520 C 746 1250 742 1010 746 890 C 750 830 746 772 716 746 C 688 724 624 716 568 712 Z")
        fillv = "url(#coatG)"; tl = "#8a8fa0"; td = "#dfe3ee"
    elif outfit == 'suit':
        torso = ("M 512 712 C 456 716 392 724 364 746 C 334 772 332 830 340 890 C 350 950 372 990 374 1030 "
                 "C 372 1090 360 1150 356 1204 Q 540 1222 724 1204 C 720 1150 708 1090 706 1030 C 708 990 730 950 740 890 "
                 "C 748 830 746 772 716 746 C 688 724 624 716 568 712 Z")
        fillv = "url(#coatG)"; tl = C['coat_line']; td = "#0b1022"
    else:
        fillv = "url(#topG)"
    o.append(f'<path d="{torso}" fill="{fillv}" stroke="{tl}" stroke-width="{CL + 1}"/>')
    o.append(f'<clipPath id="tb"><path d="{torso}"/></clipPath><g clip-path="url(#tb)">'
             f'<path d="M 440 800 Q 470 860 470 920 M 640 800 Q 610 860 610 920" fill="none" stroke="{td}" stroke-width="14" opacity="0.5" filter="url(#b8)"/>')
    if outfit == 'gown':
        dots = "".join(f'<path d="M {x} {y - 5} l 5 5 l -5 5 l -5 -5 Z" fill="#8fb4d8" opacity="0.7"/>'
                       for y in range(780, 1520, 46) for x in range(330 + (y // 46 % 2) * 23, 760, 46))
        o.append(dots)
    o.append('</g>')
    if outfit == 'gown':
        o.append(f'<path d="M 540 724 L 548 1500" stroke="{tl}" stroke-width="2.6"/>'
                 f'<path d="M 536 726 C 532 900 540 1200 536 1500" fill="none" stroke="#9dbfe2" stroke-width="8" opacity="0.6"/>')
        for yy in (820, 1010):
            o.append(f'<path d="M 542 {yy} q -16 -16 -26 2 q 16 8 26 -2 q 16 -16 26 2 q -16 8 -26 -2 M 542 {yy + 2} l -10 26 M 542 {yy + 2} l 8 28" fill="#dceaf8" stroke="{tl}" stroke-width="2.2"/>')
    elif outfit == 'coat':
        o.append(f'<path d="M 540 1300 L 540 1520" stroke="{tl}" stroke-width="2.6"/>'
                 f'<path d="M 470 1060 L 610 1060 L 610 1090 L 470 1090 Z" fill="#f6f7fb" stroke="{tl}" stroke-width="2.4"/>'
                 f'<circle cx="482" cy="1075" r="6" fill="#f2f2f6" stroke="{tl}" stroke-width="2"/><circle cx="598" cy="1075" r="6" fill="#f2f2f6" stroke="{tl}" stroke-width="2"/>'
                 f'<path d="M 478 718 Q 540 752 602 718 L 610 744 Q 540 776 470 744 Z" fill="#f2f3f8" stroke="{tl}" stroke-width="2.4"/>')
    elif outfit == 'suit':
        o.append(f'<path d="M 540 740 L 540 1214" stroke="{tl}" stroke-width="2.6"/>'
                 f'<path d="M 540 1120 L 552 1126 L 552 1214" fill="none" stroke="{tl}" stroke-width="2.4"/>'
                 f'<path d="M 484 714 Q 540 732 596 714 L 600 728 Q 540 746 480 728 Z" fill="#ffffff" stroke="#8a8fa0" stroke-width="2"/>'
                 f'<path d="M 470 724 Q 540 760 610 724 L 616 750 Q 540 784 464 750 Z" fill="{C["lapel"][1]}" stroke="{tl}" stroke-width="2.4"/>')
    else:
        o.append(f'<path d="M 540 {720 if male else 700} L 540 {1100 if male else 1010}" stroke="{td}" stroke-width="2.2" opacity="0.6"/>')
    if outfit == 'pencil':
        sk_ = ("M 420 982 Q 540 996 660 982 C 678 1040 690 1120 686 1200 C 682 1300 676 1400 672 1470 "
               "L 408 1470 C 404 1400 398 1300 394 1200 C 390 1120 402 1040 420 982 Z")
        o.append(f'<path d="{sk_}" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>'
                 f'<path d="M 540 1006 L 540 1470" stroke="{C["bottom_line"]}" stroke-width="2.2" opacity="0.7"/>'
                 f'<path d="M 540 1360 L 540 1470" stroke="{C["bottom_line"]}" stroke-width="3"/>'
                 f'<path d="M 418 978 Q 540 994 662 978 L 664 1004 Q 540 1020 416 1004 Z" fill="{C["accent"]}" stroke="{C["bottom_line"]}" stroke-width="2.4"/>')
    return "".join(o)


def neck_back(C):
    sk, sksh, sksh2, skl = C['skin']
    if C['male']:
        return (f'<path d="M 498 610 C 496 670 488 712 470 730 Q 540 748 610 730 C 592 712 584 670 582 610 Z" fill="{sk}" stroke="{skl}" stroke-width="{CL}"/>'
                f'<path d="M 540 640 L 540 720" stroke="{sksh2}" stroke-width="2.4" opacity="0.6"/>')
    return (f'<path d="M 510 600 C 508 650 500 690 486 706 Q 540 720 594 706 C 580 690 572 650 570 600 Z" fill="{sk}" stroke="{skl}" stroke-width="{CL}"/>'
            f'<path d="M 540 620 L 540 700" stroke="{sksh2}" stroke-width="2" opacity="0.5"/>')


def back_view(C, P, E, t):
    male = C['male']; nurse = C['outfit'] == 'nurse'
    sq, sqe = ('', '') if male else (SQ, '</g>')
    hy = 48 if male else 30
    bob = 4 * math.sin(t * 2 * math.pi * 0.8)
    sway = 1.0 * math.sin(t * 2 * math.pi * 0.4)
    import chars
    S_L, S_R = ((384, 788), (696, 788)) if male else ((382, 744), (704, 744))
    sleeve = 'long' if C['outfit'] in ('coat', 'suit', 'suit_f') else 'short'
    # her left arm is on screen-left in a back view: use the mirrored 'R' spec there
    armA = chars.draw_arm(C, S_L, _mirror_spec(P['R']), t, sleeve, handmode='back')
    armB = chars.draw_arm(C, S_R, _mirror_spec(P['L']), t, sleeve, handmode='back')
    o = [sq + legs_back(C) + sqe]
    o.append(f'<g transform="translate(0,{bob:.2f}) rotate({sway - C.get("lean", 0):.2f} 540 1000)">')
    o.append(sq + torso_back(C, t) + armA + armB + neck_back(C) + sqe)
    if C['outfit'] in ('nurse', 'coat'):
        o.append(sq + '<path d="M 476 704 Q 540 736 604 704" fill="none" stroke="#3b4668" stroke-width="11" stroke-linecap="round"/>' + sqe)
    head = ""
    if C['hair'] == 'messy_m':
        head += ears_back(C)
    head += hair_back(C)
    if C.get('cap'):
        head += chars.nurse_cap(back=True)
    if C.get('glasses'):
        head += f'<path d="M 400 470 L 384 476 M 680 470 L 696 476" stroke="{C["glasses"]}" stroke-width="4" stroke-linecap="round"/>'
    o.append(f'<g transform="translate(0,{hy})">{head}</g>')
    o.append('</g>')
    return "".join(o)


# ================================================================== SIDE VIEW (faces screen-right)
FACE_SIDE_F = ("M 540 236 C 610 236 652 290 654 360 C 655 400 652 428 656 448 C 660 470 668 494 676 514 "
               "C 679 522 672 528 662 530 C 664 540 664 548 658 552 C 664 558 664 568 656 574 C 654 590 644 604 628 610 "
               "C 604 618 578 614 560 604 L 556 640 L 520 600 C 470 560 446 480 444 400 C 444 300 480 236 540 236 Z")
FACE_SIDE_M = ("M 540 236 C 612 236 656 290 658 360 C 659 400 656 428 660 448 C 664 472 674 500 682 522 "
               "C 684 530 676 536 664 538 C 666 548 666 556 660 560 C 666 566 666 576 658 582 C 656 600 650 616 636 624 "
               "C 610 632 586 628 566 612 L 564 650 L 524 610 C 474 566 448 480 448 400 C 448 300 484 236 540 236 Z")


def hair_side(C):
    """(behind, front) hair pieces for the profile head."""
    st = C['hair']; L = C['hair_line']; HD = C['hair_d']; HL = C['hair_hl']
    fill = f'fill="url(#hairU)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"'
    beh, fr = [], []
    bang = ("M 600 236 C 640 250 666 300 664 360 C 666 400 664 430 656 452 C 650 430 642 418 636 446 "
            "C 628 418 620 408 610 436 C 604 400 594 368 572 344 Z")
    if st == 'long':
        d = ("M 652 330 C 650 260 600 222 540 222 C 470 222 426 270 418 340 C 412 400 428 470 448 540 "
             "C 466 610 468 700 458 800 C 450 860 438 900 426 944 C 450 928 466 932 480 948 C 490 922 500 914 512 928 "
             "C 522 860 532 780 534 700 C 536 620 542 560 560 520 L 600 470 C 620 440 640 400 652 330 Z")
        beh.append(f'<path d="{d}" {fill}/>')
        beh.append(strands([(520, 250, 440, 420, 452, 900), (560, 256, 470, 470, 480, 920), (600, 276, 500, 500, 506, 910),
                            (480, 270, 432, 440, 446, 840)], HD, 1.6, 0.55))
        beh.insert(0, f'<path d="{lock(574, 400, 584, 700, 44, 10)}" {fill}/>'
                  + strands([(574, 430, 586, 560, 586, 680)], HD, 1.4, 0.6))
        fr.append(f'<path d="{bang}" fill="url(#hairG)" stroke="{L}" stroke-width="{CL}" stroke-linejoin="round"/>')
        fr.append(f'<path d="M 470 300 Q 540 262 616 290" fill="none" stroke="{HL}" stroke-width="12" opacity="0.55" filter="url(#b3)" stroke-linecap="round"/>')
    elif st == 'bob':
        d = ("M 652 330 C 650 260 600 222 540 222 C 456 222 408 290 406 390 C 404 480 410 580 430 664 "
             "Q 480 694 548 680 C 552 620 556 560 566 520 L 600 470 C 620 440 640 400 652 330 Z")
        beh.append(f'<path d="{d}" {fill}/>' + strands([(520, 250, 440, 420, 450, 660), (570, 250, 490, 440, 500, 670)], HD, 1.5, 0.55))
        beh.insert(0, f'<path d="{lock(572, 400, 584, 650, 46, 8)}" {fill}/>')
        fr.append(f'<path d="{bang}" {fill}/>')
        fr.append(f'<path d="M 470 300 Q 540 262 616 290" fill="none" stroke="{HL}" stroke-width="12" opacity="0.5" filter="url(#b3)" stroke-linecap="round"/>')
        fr.append(f'<path d="M 600 290 l 14 -4 l 0 16 Z" fill="{C.get("accent", "#a48bd6")}"/>')
    elif st == 'bun':
        d = ("M 652 330 C 650 260 600 222 540 222 C 466 222 424 280 420 370 C 418 450 440 520 480 566 "
             "L 548 566 C 556 520 580 490 600 466 C 622 440 640 400 652 330 Z")
        beh.append(f'<circle cx="446" cy="270" r="58" {fill}/>'
                   + strands([(410, 250, 446, 220, 486, 260), (406, 286, 446, 262, 488, 296)], HD, 1.6, 0.6))
        beh.append(f'<path d="{d}" {fill}/>' + strands([(620, 300, 540, 260, 470, 280), (600, 360, 520, 320, 470, 330),
                                                        (560, 460, 500, 420, 470, 380)], HD, 1.6, 0.6))
        beh.append(f'<path d="M 480 300 Q 470 270 480 236" fill="none" stroke="{C.get("accent", "#5a6db0")}" stroke-width="10" stroke-linecap="round"/>')
        fr.append(f'<path d="M 604 240 C 650 260 668 320 664 380 C 660 420 650 440 640 452 C 636 410 620 380 590 350 Z" {fill}/>')
    elif st == 'soft_m':
        d = ("M 656 330 C 654 258 602 222 540 222 C 456 222 410 290 410 390 C 410 470 420 560 440 616 L 470 594 "
             "L 486 628 L 510 600 L 532 622 C 540 572 552 530 566 500 L 604 466 C 626 440 646 400 656 330 Z")
        beh.append(f'<path d="{d}" {fill}/>' + strands([(520, 250, 450, 420, 452, 600), (570, 250, 490, 440, 500, 610)], HD, 1.5, 0.55))
        beh.append(strands([(500, 260, 440, 360, 420, 470), (470, 300, 430, 420, 424, 560), (540, 260, 480, 380, 470, 600),
                            (600, 280, 540, 380, 520, 590)], HD, 1.5, 0.6))
        beh.append(f'<path d="M 470 300 Q 540 262 616 290" fill="none" stroke="{HL}" stroke-width="12" opacity="0.5" filter="url(#b3)" stroke-linecap="round"/>')
        beh.insert(0, f'<path d="{lock(574, 400, 584, 580, 48, 8)}" {fill}/>')
        fr.append(f'<path d="{bang}" {fill}/>')
        fr.append(f'<path d="M 470 300 Q 540 262 616 290" fill="none" stroke="{HL}" stroke-width="12" opacity="0.5" filter="url(#b3)" stroke-linecap="round"/>')
    elif st == 'messy_m':
        d = ("M 660 340 C 660 280 630 236 580 222 Q 560 196 528 186 Q 540 206 536 218 Q 500 204 470 214 Q 488 226 488 238 "
             "Q 450 240 424 262 Q 446 268 452 280 Q 420 300 404 336 Q 428 336 436 346 Q 414 372 410 404 Q 432 398 442 404 "
             "Q 430 436 436 466 L 458 470 L 462 520 L 496 520 C 512 500 530 480 548 470 L 604 456 C 630 430 650 390 660 340 Z")
        beh.append(f'<path d="{d}" {fill}/>' + strands([(560, 240, 500, 330, 460, 440), (600, 260, 540, 340, 500, 470)], HD, 1.5, 0.55))
        fr.append(f'<path d="M 600 232 C 644 248 668 296 668 350 Q 660 342 652 344 Q 662 390 656 424 Q 646 404 638 402 Q 640 430 634 452 Q 624 426 614 420 C 606 396 592 366 572 344 Z" {fill}/>')
    return "".join(beh), "".join(fr)


def eye_side(C, E, blink, look):
    male = C['male']
    cx, cy = 626, 474
    sy = 0.78 if (male and not C.get('pretty')) else (0.92 if male else 1.0)
    if E['eyes'] == 'happy':
        return f'<path d="M 604 {cy + 6} Q 620 {cy - 18} 640 {cy + 2}" fill="none" stroke="#2b1822" stroke-width="7" stroke-linecap="round"/>'
    op = E.get('op', 1.0) * blink * sy * E.get('es', 1.0) * (1 - 0.8 * E.get('lid', (0, 0))[0])
    if E['eyes'] == 'closed' or op < 0.2:
        return f'<path d="M 604 {cy + 6} Q 622 {cy + 16} 642 {cy + 2}" fill="none" stroke="#2b1822" stroke-width="6" stroke-linecap="round"/>'
    lk = max(-4, min(4, (look + E.get('look', 0)) * 0.3))
    top = cy - 22 * op; bot = cy + 20 * op
    shape = f"M 606 {f(top + 6)} Q 624 {f(top)} 640 {f(top + 6)} L 636 {f(bot)} Q 622 {f(bot + 4)} 608 {f(bot - 2)} Z"
    return (f'<clipPath id="es"><path d="{shape}"/></clipPath><path d="{shape}" fill="url(#scleraG)"/>'
            f'<g clip-path="url(#es)"><ellipse cx="{f(cx + 4 + lk)}" cy="{cy + 4}" rx="11" ry="{f(24 * op)}" fill="url(#irisG)"/>'
            f'<ellipse cx="{f(cx + 4 + lk)}" cy="{cy + 4}" rx="11" ry="{f(24 * op)}" fill="url(#irisTop)"/>'
            f'<ellipse cx="{f(cx + 5 + lk)}" cy="{cy + 3}" rx="5" ry="{f(11 * op)}" fill="#2a0c04"/>'
            f'<circle cx="{f(cx + lk)}" cy="{f(cy - 8 * op)}" r="4.5" fill="#ffffff"/></g>'
            f'<path d="M 602 {f(top + 10)} Q 622 {f(top - 4)} 642 {f(top + 4)} L 650 {f(top + 2)} L 643 {f(top + 10)} Q 622 {f(top + 4)} 606 {f(top + 14)} Z" fill="#2b1822"/>'
            f'<path d="M 612 {f(bot + 1)} Q 624 {f(bot + 4)} 634 {f(bot - 1)}" fill="none" stroke="#9a5a5c" stroke-width="2" stroke-linecap="round"/>')


def mouth_side(shape):
    if shape in ('open', 'big'):
        s = 1.0 if shape == 'open' else 1.5
        return f'<path d="M {650} 558 L {f(662 + 2 * s)} {f(560 + 2 * s)} L {652} {f(564 + 6 * s)} Z" fill="#a3354b" stroke="#7a2236" stroke-width="1.8" stroke-linejoin="round"/>'
    if shape == 'o':
        return '<ellipse cx="658" cy="563" rx="4" ry="6" fill="#a3354b" stroke="#7a2236" stroke-width="1.8"/>'
    if shape in ('smile', 'smirk'):
        return '<path d="M 644 561 Q 652 566 660 558" fill="none" stroke="#8a3a44" stroke-width="2.6" stroke-linecap="round"/>'
    if shape in ('frown', 'wavy'):
        return '<path d="M 644 566 Q 652 558 660 563" fill="none" stroke="#8a3a44" stroke-width="2.6" stroke-linecap="round"/>'
    return '<path d="M 645 562 L 660 561" fill="none" stroke="#8a3a44" stroke-width="2.6" stroke-linecap="round"/>'


def head_side(C, E, blink, look):
    male = C['male']
    sk, sksh, sksh2, skl = C['skin']
    face = FACE_SIDE_M if (male and not C.get('pretty')) else FACE_SIDE_F
    beh, fr = hair_side(C)
    o = []
    o.append(f'<path d="{face}" fill="url(#skinG)" stroke="{skl}" stroke-width="{CL}" stroke-linejoin="round"/>')
    o.append(f'<clipPath id="fs"><path d="{face}"/></clipPath><g clip-path="url(#fs)">'
             f'<path d="M 470 560 Q 560 640 640 600 L 640 680 L 460 680 Z" fill="{sksh}" opacity="0.7" filter="url(#b8)"/>'
             f'<path d="M 560 300 L 680 300 L 680 440 Q 620 410 560 440 Z" fill="{sksh}" opacity="0.6" filter="url(#b8)"/></g>')
    o.append(beh)
    if C['hair'] in ('messy_m', 'bun'):
        o.append(f'<path d="M 540 446 C 520 432 504 448 506 474 C 508 500 520 516 544 518 C 552 500 552 466 540 446 Z" fill="{sk}" stroke="{skl}" stroke-width="{CL}"/>'
                 f'<path d="M 534 460 C 520 458 516 474 520 490 C 524 500 530 504 538 504" fill="none" stroke="{sksh2}" stroke-width="2.2"/>')
    o.append(f'<ellipse cx="616" cy="530" rx="24" ry="12" fill="#ff8c9e" opacity="{0.4 if not male else 0.22}" filter="url(#b8)"/>')
    o.append(eye_side(C, E, blink, look))
    raise_, inner, lextra = E['brow']
    by = (418 if male else 412) + raise_ + lextra
    brow = f'<path d="M 604 {by + 4 - inner * 0.5} Q 624 {by - 6} 646 {by}" fill="none" stroke="{C["hair_d"]}" stroke-width="{4 if male else 2.8}" stroke-linecap="round"/>'
    o.append(mouth_side(E.get('mouth') or C['mouth']))
    o.append(fr)
    o.append(f'<g opacity="0.72">{brow}</g>')
    if C.get('glasses'):
        o.append(f'<ellipse cx="652" cy="476" rx="6" ry="30" fill="#ffffff" fill-opacity="0.25" stroke="{C["glasses"]}" stroke-width="4"/>'
                 f'<path d="M 648 462 L 556 470" stroke="{C["glasses"]}" stroke-width="4" stroke-linecap="round"/>')
    if C.get('cap'):
        o.append('<g transform="translate(560,236) rotate(-8)">'
                 '<path d="M -74 14 L -60 -36 Q 0 -48 54 -38 L 64 12 Q 0 4 -74 14 Z" fill="url(#capG)" stroke="#8a8494" stroke-width="2.6" stroke-linejoin="round"/>'
                 '<path d="M -68 8 Q 0 -2 60 6" fill="none" stroke="#de8ba5" stroke-width="6"/></g>')
    if E.get('sweat'):
        import chars
        o.append(chars.sweat_svg(600, 360))
    return "".join(o)


def side_view(C, P, E, t, look, blink):
    male = C['male']; nurse = C['outfit'] == 'nurse'; outfit = C['outfit']
    sk, sksh, sksh2, skl = C['skin']
    hy = 48 if male else 30
    bob = 4 * math.sin(t * 2 * math.pi * 0.8)
    o = []
    # ---- legs (far leg first, slightly back) ----
    if male:
        cl = [(552, 1250), (553, 1400), (556, 1540), (558, 1600), (548, 1760), (544, 1960)]; ws = [60, 54, 44, 42, 46, 24]
    else:
        cl = [(550, 1250), (553, 1380), (556, 1500), (556, 1552), (548, 1680), (544, 1874)]; ws = [50, 44, 36, 34, 40, 18]
    foot_y = cl[-1][1]
    o.append('<g transform="translate(560,0) scale(1.22,1) translate(-560,0)">')
    o.append(f'<ellipse cx="560" cy="{foot_y + 50}" rx="150" ry="20" fill="#000" opacity="0.09" filter="url(#b14)"/>')
    y0, y1 = cl[0][1], cl[-1][1]
    for k, dx in (('far', -34), ('near', 22)):
        c2 = [(x + dx * (y - y0) / (y1 - y0) + (-6 if k == 'far' else 4), y) for x, y in cl]
        d = leg_path(c2, ws)
        shade = 0.06 if k == 'far' else 0
        o.append(f'<path d="{d}" fill="{sk}" stroke="{skl}" stroke-width="3.2" stroke-linejoin="round"/>')
        if nurse:
            sock = 1600
            o.append(f'<clipPath id="ss{k}"><path d="{d}"/></clipPath><g clip-path="url(#ss{k})"><rect x="300" y="{sock}" width="500" height="400" fill="#ffffff"/></g>'
                     f'<clipPath id="sr{k}"><rect x="300" y="{sock}" width="500" height="400"/></clipPath>'
                     f'<path d="{d}" fill="none" stroke="#8a8494" stroke-width="3.4" clip-path="url(#sr{k})"/>'
                     f'<path d="M {c2[3][0] - 36} {sock} Q {c2[3][0]} {sock + 8} {c2[3][0] + 36} {sock}" fill="none" stroke="#8a8494" stroke-width="3"/>')
        if C.get('pants'):
            pw = [w_ + 14 for w_ in ws[:-1]] + [ws[-1] + 26]
            pd = leg_path(c2[:-1] + [(c2[-1][0], c2[-1][1] - 14)], pw)
            o.append(f'<path d="{pd}" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>')
        if shade:
            o.append(f'<path d="{d}" fill="#000" opacity="{shade}"/>')
        a = c2[-1]
        if nurse:
            col, line, strap = "#ffffff", "#8a8494", "#de8ba5"
        else:
            col, line, strap = C['shoes']
        s_ = 1.25 if male else 1.0
        o.append(f'<g transform="translate({f(a[0])},{f(a[1] + 4)}) scale({s_})">'
                 f'<path d="M -22 -10 C -28 6 -26 22 -16 28 L 54 28 C 72 28 78 16 70 6 C 60 -4 30 -10 -22 -10 Z" fill="{col}" stroke="{line}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M -16 28 L 54 28 C 70 28 76 22 76 16" fill="none" stroke="{line}" stroke-width="3" opacity="0.6"/>'
                 + ('' if male else f'<path d="M -18 26 L -16 40 L -4 40 L -2 28 Z" fill="{line}" opacity="0.6"/>')
                 + (f'<path d="M -12 -6 Q 10 -14 30 -8" fill="none" stroke="{strap}" stroke-width="5" stroke-linecap="round"/>' if strap else '')
                 + '</g>')
    if C.get('pants'):
        pel = ("M 498 1080 L 608 1080 C 616 1200 610 1320 596 1440 L 504 1440 C 492 1320 490 1200 498 1080 Z" if outfit == 'suit'
               else "M 498 1080 L 608 1080 L 616 1310 Q 552 1330 488 1310 Z")
        o.append(f'<path d="{pel}" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>')
    o.append('</g>')
    # ---- torso ----
    o.append(f'<g transform="translate(0,{bob:.2f})">')
    o.append('<g transform="translate(560,0) scale(1.22,1) translate(-560,0)">')
    if male:
        torso = ("M 556 716 C 514 730 494 760 490 820 C 486 900 494 980 500 1040 L 502 1100 L 604 1100 "
                 "C 606 1040 612 980 616 920 C 626 860 628 800 616 760 C 606 736 590 722 574 716 Z")
    else:
        torso = ("M 552 700 C 520 712 500 740 496 790 C 492 860 506 920 512 980 C 516 1030 512 1060 508 1084 "
                 "L 596 1084 C 600 1040 604 1000 610 966 C 640 950 656 900 654 850 C 652 800 630 740 604 714 Z")
    if outfit == 'gown':
        torso = ("M 556 716 C 514 730 494 760 490 820 C 486 920 488 1100 484 1300 L 476 1500 Q 552 1512 628 1500 "
                 "L 622 1300 C 620 1100 622 940 624 900 C 630 840 626 790 614 760 C 604 736 590 722 574 716 Z")
    if outfit == 'friend' or (outfit == 'scrub' and C.get('pants')):
        torso = torso.replace("C 516 1030 512 1060 508 1084 L 596 1084 C 600 1040 604 1000 610 966",
                              "C 514 1040 508 1090 504 1124 L 604 1124 C 604 1060 604 1000 610 966")
    o.append(f'<path d="{torso}" fill="url(#{"scrubG" if nurse else "topG"})" stroke="{C["top_line"]}" stroke-width="{CL + 1}" stroke-linejoin="round"/>')
    o.append(f'<clipPath id="ts"><path d="{torso}"/></clipPath><g clip-path="url(#ts)">'
             f'<path d="M 500 760 C 490 900 500 1000 506 1100" fill="none" stroke="{C["top_g"][2]}" stroke-width="20" opacity="0.55" filter="url(#b8)"/>'
             + (f'<path d="M 600 900 Q 630 940 650 900" fill="none" stroke="{C["top_g"][2]}" stroke-width="12" opacity="0.5" filter="url(#b8)"/>' if not male else '')
             + ("".join(f'<path d="M {x} {y - 5} l 5 5 l -5 5 l -5 -5 Z" fill="#8fb4d8" opacity="0.7"/>'
                        for y in range(760, 1500, 46) for x in range(486 + (y // 46 % 2) * 23, 640, 46)) if outfit == 'gown' else '')
             + '</g>')
    # skirts / coat
    if nurse:
        sk_ = ("M 508 1084 L 598 1084 C 630 1180 660 1300 672 1410 Q 640 1424 610 1414 Q 580 1426 552 1414 "
               "Q 520 1426 492 1414 Q 466 1424 440 1410 C 456 1300 486 1180 508 1084 Z")
        o.append(f'<path d="{sk_}" fill="url(#scrubG)" stroke="{C["top_line"]}" stroke-width="{CL + 1}" stroke-linejoin="round"/>'
                 + "".join(f'<path d="M {540 + i * 14} 1100 Q {530 + i * 26} 1260 {500 + i * 30} 1414" fill="none" stroke="{C["top_g"][2]}" stroke-width="2.4" opacity="0.8"/>' for i in range(-2, 5))
                 + f'<path d="M 506 1078 L 600 1078 L 602 1104 L 504 1104 Z" fill="#ffffff" stroke="{C["top_line"]}" stroke-width="2.4"/>'
                 + f'<path d="M 504 1090 C 490 1074 470 1076 472 1092 C 474 1106 494 1102 504 1090 Z" fill="#ffffff" stroke="{C["top_line"]}" stroke-width="2.4"/>')
    elif outfit == 'pencil':
        o.append(f'<path d="M 506 1000 L 600 1000 C 614 1160 616 1300 612 1470 L 498 1470 C 494 1300 498 1160 506 1000 Z" fill="url(#botG)" stroke="{C["bottom_line"]}" stroke-width="3.4" stroke-linejoin="round"/>'
                 f'<path d="M 504 996 L 602 996 L 604 1022 L 502 1022 Z" fill="{C["accent"]}" stroke="{C["bottom_line"]}" stroke-width="2.4"/>')
    elif outfit == 'coat':
        coat = ("M 556 712 C 506 726 486 760 484 820 C 480 960 480 1200 470 1520 L 626 1520 C 626 1300 628 1100 630 940 "
                "C 636 860 632 800 618 760 C 606 734 590 720 574 714 Z")
        o.append(f'<path d="{coat}" fill="url(#coatG)" stroke="#8a8fa0" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M 612 740 L 600 860 L 624 1520" fill="none" stroke="#c9cdd8" stroke-width="2.4"/>'
                 f'<path d="M 520 1200 L 598 1200" stroke="#8a8fa0" stroke-width="2.4"/>'
                 f'<path d="M 500 800 C 490 1000 492 1300 486 1510" fill="none" stroke="#dfe3ee" stroke-width="16" opacity="0.8" filter="url(#b8)"/>')
    elif outfit == 'suit':
        cl_ = C['coat_line']
        jk = ("M 556 712 C 506 726 486 760 484 820 C 482 900 492 980 494 1030 C 492 1100 486 1160 484 1204 "
              "L 628 1204 C 626 1140 622 1080 622 1030 C 628 970 636 880 632 820 C 630 790 622 766 614 750 C 604 732 590 720 574 714 Z")
        o.append(f'<path d="M 596 716 L 622 716 L 628 790 L 604 800 Z" fill="#ffffff" stroke="#8a8fa0" stroke-width="2"/>'
                 f'<path d="M 616 742 L 628 742 L 634 820 L 624 826 Z" fill="{C["tie"][0]}" stroke="#8a6a1e" stroke-width="1.8"/>'
                 f'<path d="{jk}" fill="url(#coatG)" stroke="{cl_}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<clipPath id="jks"><path d="{jk}"/></clipPath><g clip-path="url(#jks)" opacity="0.1">'
                 + "".join(f'<path d="M {x} 700 L {x} 1220" stroke="#ffffff" stroke-width="1.2"/>' for x in range(470, 640, 17)) + '</g>'
                 f'<path d="M 596 722 L 612 760 L 600 800 L 622 1000" fill="none" stroke="{C["lapel"][0]}" stroke-width="10" stroke-linejoin="round"/>'
                 f'<path d="M 596 722 L 612 760 L 600 800 L 622 1000" fill="none" stroke="{cl_}" stroke-width="2" stroke-linejoin="round" transform="translate(-5,0)"/>'
                 f'<path d="M 524 1110 L 604 1106 L 606 1130 Q 564 1138 526 1134 Z" fill="url(#coatG)" stroke="{cl_}" stroke-width="2.4"/>'
                 f'<path d="M 500 800 C 492 950 500 1100 490 1196" fill="none" stroke="#000" stroke-width="16" opacity="0.15" filter="url(#b8)"/>')
    elif outfit == 'gown':
        o.append(f'<path d="M 494 840 q -18 -14 -24 4 q 16 6 24 -4 M 494 842 l -14 22" fill="#dceaf8" stroke="{C["top_line"]}" stroke-width="2.2"/>')
    # neck
    if male:
        o.append(f'<path d="M 548 610 L 546 722 L 604 722 L 606 620 Z" fill="{sk}" stroke="{skl}" stroke-width="{CL}"/>')
    else:
        o.append(f'<path d="M 552 590 L 550 708 L 600 708 L 604 600 Z" fill="{sk}" stroke="{skl}" stroke-width="{CL}"/>')
    o.append(f'<path d="M 554 {620 if male else 600} L 604 {640 if male else 620} L 604 {680 if male else 660} L 552 {660 if male else 640} Z" fill="{sksh}" opacity="0.8"/>')
    # collar / neckline from the side
    if outfit in ('nurse', 'scrub', 'pencil', 'coat'):
        o.append(f'<path d="M 600 {712 if not male else 726} L 616 {770 if not male else 784}" stroke="#ffffff" stroke-width="7" stroke-linecap="round"/>'
                 f'<path d="M 598 {708 if not male else 722} L 614 {772 if not male else 786}" stroke="{C["top_line"]}" stroke-width="2"/>')
    if outfit in ('nurse', 'coat'):
        o.append(f'<path d="M 552 {706 if not male else 720} C 600 {700 if not male else 716} 640 {770 if not male else 790} 646 {850 if not male else 880}" '
                 f'fill="none" stroke="#3b4668" stroke-width="10" stroke-linecap="round"/>'
                 f'<circle cx="646" cy="{870 if not male else 900}" r="18" fill="url(#metal)" stroke="#6b7284" stroke-width="2.4"/>')
    o.append('</g>')
    # head
    tilt = 1.2 * math.sin(t * 2 * math.pi * 0.8 + 0.6)
    o.append(f'<g transform="translate(0,{hy}) rotate({tilt:.2f} 560 620)">{head_side(C, E, blink, look)}</g>')
    # near arm
    import chars
    S = (552, 780) if male else (552, 760)
    spec = P['L']
    if spec[0] != 'ik' and spec[0] > 150:          # raised / pointing -> forward in profile
        spec = ((34, -72) if spec[1] < 0 else (-8, -4)) + tuple(spec[2:])
    elif spec[0] == 'ik':
        spec = (94, 92, spec[3])
    else:
        spec = (94, 92) + tuple(spec[2:])
    sleeve = 'long' if outfit in ('coat', 'suit', 'suit_f') else 'short'
    o.append('<g transform="translate(560,0) scale(1.22,1) translate(-560,0)">' + chars.draw_arm(C, S, spec, t, sleeve, handmode='side') + '</g>')
    o.append('</g>')
    return "".join(o)


def render_view(C, view, P, E, t, look, blink):
    if view == 'back':
        return back_view(C, P, E, t)
    return side_view(C, P, E, t, look, blink)
